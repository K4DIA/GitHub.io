#!/usr/bin/env python3
"""
Printed coil form with a shallow helical wire groove.
End spigots are the same OD the end caps expect
(26.67 mm for the BNC caps, 33.40 mm for the SO-239 caps).
"""
import math, json, sys
import numpy as np
import trimesh
from trimesh.creation import cylinder, sweep_polygon
from shapely.geometry import Point

SEG = 160

FORMS = {"BNC": dict(od=26.67), "SO239": dict(od=33.40)}
WIRES = {
    # enamel OD (mm) -> groove radius, pitch. Pitch ~1.3x wire for spacing (better Q, cooler).
    "18AWG": dict(wire_od=1.08, groove_r=0.60, pitch=1.40),
    "16AWG": dict(wire_od=1.35, groove_r=0.75, pitch=1.70),
}
COMMON = dict(length=105.0, wall=2.5, socket=12.0, margin=2.0,
              entry_hole=2.2)      # radial wire hole at each end of the groove


def clean(m):
    """Remove zero-area slivers left by coincident cutter faces, then prove the mesh is a closed volume."""
    m.merge_vertices(); m.update_faces(m.nondegenerate_faces()); m.remove_unreferenced_vertices()
    assert m.is_watertight and m.is_volume and m.is_winding_consistent, "mesh invalid after clean"
    return m


def helix(r, z0, turns, pitch, per_turn=48):
    n = int(turns * per_turn) + 1
    t = np.linspace(0, turns, n)
    a = 2 * math.pi * t
    return np.c_[r * np.cos(a), r * np.sin(a), z0 + pitch * t], a[-1]


def make_form(form, wire):
    p = {**COMMON, **form, **wire}
    od, L = p["od"], p["length"]
    zid = od - 2 * p["wall"]
    body = cylinder(radius=od / 2, height=L, sections=SEG); body.apply_translation([0, 0, L / 2])
    bore = cylinder(radius=zid / 2, height=L + 2, sections=SEG); bore.apply_translation([0, 0, L / 2])

    z0 = p["socket"] + p["margin"] + p["groove_r"]
    z1 = L - p["socket"] - p["margin"] - p["groove_r"]
    turns = math.floor((z1 - z0) / p["pitch"])
    path, a_end = helix(od / 2, z0, turns, p["pitch"])
    groove = sweep_polygon(Point(0, 0).buffer(p["groove_r"], resolution=6), path)

    # radial wire entry holes at groove start (angle 0) and end
    cutters = [bore, groove]
    for ang, z in ((0.0, z0), (a_end, z0 + p["pitch"] * turns)):
        h = cylinder(radius=p["entry_hole"] / 2, height=p["wall"] + 4, sections=32)
        h.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2, [0, 1, 0]))  # along +x
        h.apply_translation([od / 2 - p["wall"] / 2, 0, 0])
        h.apply_transform(trimesh.transformations.rotation_matrix(ang, [0, 0, 1]))
        h.apply_translation([0, 0, z])
        cutters.append(h)

    form_mesh = clean(trimesh.boolean.difference([body] + cutters, engine="manifold"))
    return form_mesh, dict(od=od, id=round(zid, 2), length=L, turns=turns,
                           groove_start_mm=round(z0, 2), groove_end_mm=round(z0 + p["pitch"] * turns, 2),
                           pitch=p["pitch"], groove_r=p["groove_r"], groove_depth=p["groove_r"],
                           min_wall_at_groove=round(p["wall"] - p["groove_r"], 2),
                           wire_needed_m=round(turns * math.pi * (od + p["wire_od"]) / 1000 + 0.15, 2),
                           volume_cm3=round(form_mesh.volume / 1000, 1),
                           mass_g_PETG=round(form_mesh.volume / 1000 * 1.27, 1),
                           faces=len(form_mesh.faces))


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    rep = {}
    for fn_, f in FORMS.items():
        for wn, w in WIRES.items():
            m, info = make_form(f, w)
            fname = f"{out}/coilform_{fn_}_{wn}.stl"
            m.export(fname); info["file"] = fname
            rep[f"{fn_}_{wn}"] = info
    print(json.dumps(rep, indent=2))
