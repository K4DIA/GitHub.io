#!/usr/bin/env python3
"""Shaded preview of an STL with three.js in headless Chromium.
render_preview.py in.stl out.png elev,azim [elev,azim ...]   (degrees; azim 0 looks along -y, elev positive looks down)"""
import sys, os, re, base64, math, json, tempfile
from playwright.sync_api import sync_playwright

R3 = os.environ.get("THREE_DIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "node_modules", "three"))  # npm install three
src, dst = sys.argv[1], sys.argv[2]
views = [tuple(float(x) for x in v.split(",")) for v in sys.argv[3:]] or [(25, -50)]
W = 640; H = 640
data = base64.b64encode(open(src, "rb").read()).decode()
three_src = open(f"{R3}/build/three.module.js").read()
stl_src = re.sub(r"^import\s*\{[^}]*\}\s*from\s*'three';", "", open(f"{R3}/examples/jsm/loaders/STLLoader.js").read(), flags=re.M)
stl_src = stl_src.replace("export { STLLoader };", "")
html = f"""<!doctype html><html><body style="margin:0;background:#fff">
<canvas id=c width={W * len(views)} height={H}></canvas>
<script type="module">
{three_src}
{stl_src}
const stlBin = Uint8Array.from(atob("{data}"), c => c.charCodeAt(0)).buffer;
const geom = new STLLoader().parse(stlBin); geom.computeVertexNormals(); geom.computeBoundingSphere();
const bsph = geom.boundingSphere; const viewList = {json.dumps(views)};
const rndr = new WebGLRenderer({{canvas: document.getElementById('c'), antialias: true, preserveDrawingBuffer: true}});
rndr.setClearColor(0xffffff, 1); rndr.setScissorTest(true);
const scn = new Scene();
const matl = new MeshStandardMaterial({{color: 0xb9c2cf, metalness: 0.1, roughness: 0.55, flatShading: false}});
const mesh = new Mesh(geom, matl); mesh.position.sub(bsph.center); scn.add(mesh);
scn.add(new HemisphereLight(0xffffff, 0x9a9a9a, 1.6)); scn.add(new AmbientLight(0xffffff, 0.5));
const keyL = new DirectionalLight(0xffffff, 1.8); scn.add(keyL);
const fillL = new DirectionalLight(0xffffff, 0.6); scn.add(fillL);
viewList.forEach((v, i) => {{
  const el = v[0] * Math.PI / 180, az = v[1] * Math.PI / 180, d = bsph.radius * 4.3;
  const cam = new PerspectiveCamera(28, 1, 0.1, d * 4); cam.up.set(0, 0, 1);
  cam.position.set(d * Math.cos(el) * Math.sin(az), -d * Math.cos(el) * Math.cos(az), d * Math.sin(el)); cam.lookAt(0, 0, 0);
  keyL.position.copy(cam.position).add(new Vector3(-d*0.5, 0, d*0.6)); fillL.position.copy(cam.position).add(new Vector3(d*0.8, 0, -d*0.3));
  rndr.setViewport(i * {W}, 0, {W}, {H}); rndr.setScissor(i * {W}, 0, {W}, {H}); rndr.render(scn, cam);
}});
window.done = true;
</script></body></html>"""
tmp = tempfile.NamedTemporaryFile("w", suffix=".html", delete=False, dir=os.path.dirname(R3)); tmp.write(html); tmp.close()
with sync_playwright() as p:
    b = p.chromium.launch(args=["--allow-file-access-from-files", "--use-gl=swiftshader", "--enable-unsafe-swiftshader"])
    pg = b.new_page(viewport={"width": W * len(views), "height": H}, device_scale_factor=2)
    errs = []; pg.on("console", lambda m: errs.append(m.text)); pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto("file://" + tmp.name)
    try: pg.wait_for_function("window.done === true", timeout=60000)
    except Exception: print("\n".join(errs)); raise
    pg.locator("#c").screenshot(path=dst); b.close()
os.unlink(tmp.name)
