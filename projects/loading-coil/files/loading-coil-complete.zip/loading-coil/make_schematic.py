#!/usr/bin/env python3
"""Rev B fixed loading coil, SO-239 version: section, electrical, inductance table. Dimensions above, callout ladder below."""
import sys
INK = "#1d1b17"; LEAD = "#444"; EXT = "#888"
FORM = "#e3c89a"; FORML = "#8a6d3b"; CAP = "#aab7c7"; CAPL = "#56657a"; BRASS = "#d4b24f"; BRL = "#8a7020"; WIRE = "#b87333"
FORM_L = 105.0; SOCK = 12.0; FACE = 7.0; GROOVE0 = 14.7; GROOVE_L = 75.6; PITCH = 1.40; TURNS = 54; WIRE_D = 1.08
FORM_R = 33.4/2; BORE_R = 28.4/2; CAP_R = 39.4/2; CONN = 16.0
S = 5.0; OX, OY = 300, 430
def X(z): return OX + z*S
def Y(r): return OY - r*S
o = []; W, H = 1500, 1150
o.append(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" font-family="Helvetica, Arial, sans-serif" font-size="13" fill="{INK}">')
o.append('<rect width="100%" height="100%" fill="#fff"/>')
o.append('<text x="24" y="34" font-size="20" font-weight="bold">Fixed loading coil, printed grooved form, series inline (rev B)</text>')
o.append('<text x="24" y="54" fill="#444">Section through the axis, SO-239 version (form OD 33.4). The BNC version (OD 26.7) is the same construction at a smaller scale; values in the table.</text>')
def rect(z0, r0, z1, r1, fill, stroke=INK, sw=1.0): o.append(f'<rect x="{X(min(z0,z1)):.1f}" y="{Y(max(r0,r1)):.1f}" width="{abs(z1-z0)*S:.1f}" height="{abs(r1-r0)*S:.1f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
def both(z0, r0, z1, r1, fill, stroke=INK): rect(z0, r0, z1, r1, fill, stroke); rect(z0, -r0, z1, -r1, fill, stroke)
def line(z0, r0, z1, r1, stroke=INK, sw=1.0, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ''
    o.append(f'<line x1="{X(z0):.1f}" y1="{Y(r0):.1f}" x2="{X(z1):.1f}" y2="{Y(r1):.1f}" stroke="{stroke}" stroke-width="{sw}"{d}/>')
# caps: face plates and socket walls over each spigot
both(-FACE, 0, 0, CAP_R, CAP, CAPL); both(0, FORM_R + 0.2, SOCK, CAP_R, CAP, CAPL)
both(FORM_L, 0, FORM_L + FACE, CAP_R, CAP, CAPL); both(FORM_L - SOCK, FORM_R + 0.2, FORM_L, CAP_R, CAP, CAPL)
# connectors
both(-FACE - CONN, 0, -FACE, 7.9, BRASS, BRL); rect(-FACE - CONN, 12.7, -FACE - CONN + 1.6, -12.7, "#c9ccd0", "#666")
both(FORM_L + FACE, 0, FORM_L + FACE + CONN, 7.9, BRASS, BRL); rect(FORM_L + FACE + CONN - 1.6, 12.7, FORM_L + FACE + CONN, -12.7, "#c9ccd0", "#666")
# form
both(0, BORE_R, FORM_L, FORM_R, FORM, FORML)
# winding, enamelled: all turns filled
for i in range(TURNS):
    z = GROOVE0 + i*PITCH + PITCH/2
    for sg in (1, -1): o.append(f'<circle cx="{X(z):.1f}" cy="{Y(sg*(FORM_R + WIRE_D/2 - 0.3)):.1f}" r="{WIRE_D/2*S:.1f}" fill="{WIRE}" stroke="{WIRE}" stroke-width="0.6"/>')
# entry holes and tails
for z, zc in ((GROOVE0, -FACE), (GROOVE0 + GROOVE_L, FORM_L + FACE)):
    rect(z - 1.1, FORM_R + 0.1, z + 1.1, BORE_R - 0.1, "#fff", FORML)
    line(z, FORM_R, z, BORE_R - 1, WIRE, 1.2); line(z, BORE_R - 1, zc, 0, WIRE, 1.2)
line(-FACE - CONN - 10, 0, FORM_L + FACE + CONN + 10, 0, "#999", 0.7, "10 4")
# dims above
def ext_up(z, r, py): o.append(f'<line x1="{X(z):.1f}" y1="{Y(r):.1f}" x2="{X(z):.1f}" y2="{py}" stroke="{EXT}" stroke-width="0.7"/>')
def dim_h(z0, z1, ypx, text):
    o.append(f'<line x1="{X(z0):.1f}" y1="{ypx}" x2="{X(z1):.1f}" y2="{ypx}" stroke="{INK}" stroke-width="0.9"/>')
    for z, sg in ((z0, 1), (z1, -1)): o.append(f'<path d="M{X(z):.1f},{ypx} l{6*sg},-3 l0,6 z" fill="{INK}"/>')
    o.append(f'<text x="{(X(z0)+X(z1))/2:.1f}" y="{ypx - 5}" text-anchor="middle" font-size="12">{text}</text>')
y1 = Y(CAP_R) - 34; y2 = y1 - 30; y3 = y2 - 30; y4 = y3 - 30
for z in (GROOVE0, GROOVE0 + GROOVE_L): ext_up(z, FORM_R + WIRE_D, y1 - 6)
dim_h(GROOVE0, GROOVE0 + GROOVE_L, y1, "75.6 groove: 54 turns at 1.40 (18 AWG) or 44 at 1.70 (16 AWG)")
for z in (0, SOCK, FORM_L - SOCK, FORM_L): ext_up(z, CAP_R, y2 - 6)
dim_h(0, SOCK, y2, "12 socket"); dim_h(SOCK, FORM_L - SOCK, y2, "81 exposed"); dim_h(FORM_L - SOCK, FORM_L, y2, "12")
for z in (-FACE, FORM_L + FACE): ext_up(z, CAP_R, y3 - 6)
dim_h(-FACE, FORM_L + FACE, y3, "119 cap to cap; form 105, faces 7")
for z in (-FACE - CONN, FORM_L + FACE + CONN): ext_up(z, 12.7, y4 - 6)
dim_h(-FACE - CONN, FORM_L + FACE + CONN, y4, "about 151 overall with SO-239s, 140 with BNCs")
# ladder below, rightmost first
RX = X(FORM_L + FACE + CONN) + 40; BOT = Y(-CAP_R) + 26
rows = [
    (FORM_L + FACE + CONN/2, -7.9, "SO-239 square flange: four #4 self-tapping screws into 2.6 mm blind pilots, or M3 inserts"),
    (FORM_L - SOCK/2, -CAP_R, "cap socket: bore 33.80 over the 33.4 spigot, 0.4 mm clearance, a friction fit"),
    (GROOVE0 + GROOVE_L, -(BORE_R - 0.5), "2.2 mm entry hole at each end of the groove: the tail runs into the bore to the center-pin tail"),
    (GROOVE0 + GROOVE_L/2, -(FORM_R + WIRE_D), "half-round groove, 0.6 deep: the wire snaps in and the groove sets the spacing"),
    (FORM_L/2, -BORE_R, "hollow bore, wall 2.5, 1.9 under the groove: keeps plastic out of the field"),
    (-FACE - CONN/2, -7.9, "connector shells float: a conductor tying the two shells together would be a shorted turn"),
]
for i, (z, r, text) in enumerate(rows):
    yrow = BOT + 16 + i*24
    o.append(f'<line x1="{X(z):.1f}" y1="{Y(r):.1f}" x2="{X(z):.1f}" y2="{yrow}" stroke="{LEAD}" stroke-width="0.9"/><line x1="{X(z):.1f}" y1="{yrow}" x2="{RX - 8}" y2="{yrow}" stroke="{LEAD}" stroke-width="0.9"/>')
    o.append(f'<circle cx="{X(z):.1f}" cy="{Y(r):.1f}" r="2.4" fill="{LEAD}"/><text x="{RX}" y="{yrow + 4}" font-size="11.5">{text}</text>')
# electrical
EY = 790
o.append(f'<text x="24" y="{EY - 50}" font-size="15" font-weight="bold">Electrical: pure series inductance, center conductor only</text>')
x = 120
o.append(f'<text x="{x}" y="{EY - 10}">collapsible whip</text><line x1="{x}" y1="{EY}" x2="{x + 160}" y2="{EY}" stroke="{INK}" stroke-width="1.5"/>')
x += 160
for k, lab in enumerate(["L1", "L2, optional", "L3, optional"]):
    o.append(f'<circle cx="{x}" cy="{EY}" r="5" fill="#fff" stroke="{INK}" stroke-width="1.5"/>'); x += 5
    path = f'M{x},{EY}'
    for i in range(10): path += ' a7,7 0 0 1 14,0'
    o.append(f'<path d="{path}" fill="none" stroke="{INK}" stroke-width="1.5"' + (' stroke-dasharray="4 3"' if k else '') + '/>')
    o.append(f'<text x="{x + 70}" y="{EY - 14}" text-anchor="middle" font-size="12">{lab}</text>'); x += 140
    o.append(f'<circle cx="{x + 5}" cy="{EY}" r="5" fill="#fff" stroke="{INK}" stroke-width="1.5"/>'); x += 10
    if k < 2:
        o.append(f'<rect x="{x}" y="{EY - 8}" width="40" height="16" fill="#eee" stroke="{INK}"/><text x="{x + 20}" y="{EY + 26}" text-anchor="middle" font-size="10.5">male-male adapter</text>'); x += 40
o.append(f'<line x1="{x}" y1="{EY}" x2="{x + 160}" y2="{EY}" stroke="{INK}" stroke-width="1.5"/><text x="{x + 170}" y="{EY + 4}">antenna mount, radio</text>')
o.append(f'<text x="120" y="{EY + 56}" font-size="11.5">Open circles are the female connectors on each cap. Every unit is female both ends, so stacking two or three takes a PL-259 double-male or BNC male-male between them.</text>')
o.append(f'<text x="120" y="{EY + 74}" font-size="11.5">Tune by extending or collapsing the whip; add units for lower bands.</text>')
# table
TY = 930
o.append(f'<text x="24" y="{TY - 30}" font-size="15" font-weight="bold">Estimated inductance, Wheeler formula, within about 10 percent</text>')
cols = [("Version", 120), ("Form", 260), ("Wire / pitch", 380), ("Full groove", 540), ("40 t", 700), ("30 t", 800), ("20 t", 900), ("Wire needed", 1000)]
for name, cx in cols: o.append(f'<text x="{cx}" y="{TY}" font-weight="bold" font-size="12">{name}</text>')
o.append(f'<line x1="110" y1="{TY + 8}" x2="1140" y2="{TY + 8}" stroke="{INK}" stroke-width="0.8"/>')
rows_t = [("BNC", "OD 26.7", "18 AWG / 1.40", "54 t: 25 uH", "18 uH", "13 uH", "8 uH", "4.9 m"), ("BNC", "OD 26.7", "16 AWG / 1.70", "44 t: 17 uH", "15 uH", "11 uH", "7 uH", "4.0 m"),
          ("SO-239", "OD 33.4", "18 AWG / 1.40", "54 t: 38 uH", "26 uH", "18 uH", "11 uH", "6.0 m"), ("SO-239", "OD 33.4", "16 AWG / 1.70", "44 t: 25 uH", "23 uH", "16 uH", "10 uH", "5.0 m")]
for i, r in enumerate(rows_t):
    for (name, cx), v in zip(cols, r): o.append(f'<text x="{cx}" y="{TY + 30 + i*22}" font-size="12">{v}</text>')
o.append(f'<text x="120" y="{TY + 30 + 4*22 + 8}" font-size="11" fill="#444">Partial-fill values assume you wind N turns from one end and leave the rest of the groove empty. 100 W SSB and CW in PETG; see the README for duty-cycle notes.</text>')
o.append('</svg>')
open(sys.argv[1], 'w', encoding='utf-8').write('\n'.join(o)); print('ok')
