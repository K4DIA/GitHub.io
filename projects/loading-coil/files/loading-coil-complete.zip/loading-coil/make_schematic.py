#!/usr/bin/env python3
"""Draws schematic.svg: mechanical cross-section (SO-239 version, dimensioned) + electrical schematic."""

W, H = 1200, 1000
out = []
A = out.append
A(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" font-family="Helvetica, Arial, sans-serif" font-size="13">')
A('<rect width="100%" height="100%" fill="white"/>')
A('<text x="24" y="34" font-size="22" font-weight="bold">Whip Loading Coil, fully printed grooved form, series inline, no taps (rev B)</text>')
A('<text x="24" y="54" fill="#444">Cross-section shown is the SO-239 version (form OD 33.4). BNC version (form OD 26.7) is identical in construction; values in the table.</text>')

# ---------- mechanical cross-section (scale: 3 px per mm) ----------
S = 3.0
ox, oy = 330, 130          # origin: left end of the form, top of drawing region
tube_len = 105.0; tube_od = 33.4; tube_id = 28.4
wall_t = (tube_od - tube_id) / 2
face = 7.0; sock = 12.0; cap_wall = 3.0
cap_od = tube_od + 2 * cap_wall
cy = oy + 120                                  # centerline y (px)

def X(mm): return ox + mm * S
def Y(mm): return cy - mm * S                   # mm offset from axis -> px

# form walls (two rectangles)
for sgn in (1, -1):
    y_out = Y(sgn * tube_od / 2); y_in = Y(sgn * tube_id / 2)
    A(f'<rect x="{X(0)}" y="{min(y_out,y_in)}" width="{tube_len*S}" height="{abs(y_out-y_in)}" fill="#bfc5cc" stroke="#333"/>')

# end caps: outer sleeve + face, left and right
for side in ("L", "R"):
    x0 = X(-face) if side == "L" else X(tube_len)
    xf = x0 if side == "L" else X(tube_len + face) - face * S   # face rect left edge
    # face plate
    A(f'<rect x="{xf}" y="{Y(cap_od/2)}" width="{face*S}" height="{cap_od*S}" fill="#6d7a88" stroke="#222"/>')
    # sleeve walls over tube
    xs = X(0) if side == "L" else X(tube_len - sock)
    for sgn in (1, -1):
        A(f'<rect x="{xs}" y="{Y(sgn*cap_od/2) if sgn>0 else Y(-tube_od/2)}" width="{sock*S}" height="{cap_wall*S}" fill="#6d7a88" stroke="#222"/>')
    # connector body through-hole in face (white gap)
    A(f'<rect x="{xf}" y="{Y(16.5/2)}" width="{face*S}" height="{16.5*S}" fill="white" stroke="#222"/>')
    # SO-239 connector: flange + body + solder tail
    xc = xf - 3 * S if side == "L" else xf + face * S          # flange outside the face
    A(f'<rect x="{xc}" y="{Y(25.4/2)}" width="{3*S}" height="{25.4*S}" fill="#c9a84a" stroke="#333"/>')
    xb = xc - 13 * S if side == "L" else xc + 3 * S
    A(f'<rect x="{xb}" y="{Y(15.9/2)}" width="{13*S}" height="{15.9*S}" fill="#d8c27a" stroke="#333"/>')
    # center pin + tail into the bore
    xp0 = xb if side == "L" else xc
    xp1 = X(10) if side == "L" else X(tube_len - 10)
    A(f'<line x1="{xp0}" y1="{cy}" x2="{xp1}" y2="{cy}" stroke="#333" stroke-width="3"/>')
    A(f'<circle cx="{xp1}" cy="{cy}" r="3" fill="#333"/>')
    # mounting screw (one shown, blind into face)
    xs0 = xc if side == "L" else xc + 3 * S
    xs1 = xs0 + (face - 1.5) * S if side == "L" else xs0 - (face - 1.5) * S
    A(f'<line x1="{xs0}" y1="{Y(18.24/2)}" x2="{xs1}" y2="{Y(18.24/2)}" stroke="#222" stroke-width="2" stroke-dasharray="3 2"/>')

# winding: turns drawn as small circles on top and bottom of tube between the sockets
pitch = 1.35; x = sock + 1.5; turns = 0
while x + pitch / 2 <= tube_len - sock - 1.5:
    for sgn in (1, -1):
        A(f'<circle cx="{X(x)}" cy="{Y(sgn*(tube_od/2 + 0.68))}" r="{0.68*S}" fill="#c76b2a" stroke="#7a3d12" stroke-width="0.6"/>')
    x += pitch; turns += 1

# wire entry: through tube wall at each end, down to the center tail
for side in ("L", "R"):
    xe = X(sock + 1.5) if side == "L" else X(tube_len - sock - 1.5)
    xt = X(10) if side == "L" else X(tube_len - 10)
    A(f'<path d="M {xe} {Y(tube_od/2+1.4)} L {xe} {Y(tube_id/2 - 1)} L {xt} {cy}" fill="none" stroke="#c76b2a" stroke-width="2.5"/>')
    # drilled hole marker
    A(f'<rect x="{xe-2}" y="{Y(tube_od/2)}" width="4" height="{wall_t*S}" fill="white" stroke="#333" stroke-width="0.7"/>')

# ---------- dimensions ----------
def dim(x1, x2, y, text, above=True):
    A(f'<line x1="{x1}" y1="{y}" x2="{x2}" y2="{y}" stroke="#1a4fa0" stroke-width="1"/>')
    for xx in (x1, x2):
        A(f'<line x1="{xx}" y1="{y-5}" x2="{xx}" y2="{y+5}" stroke="#1a4fa0"/>')
    ty = y - 6 if above else y + 16
    A(f'<text x="{(x1+x2)/2}" y="{ty}" text-anchor="middle" fill="#1a4fa0">{text}</text>')

def vdim(x, y1, y2, text):
    A(f'<line x1="{x}" y1="{y1}" x2="{x}" y2="{y2}" stroke="#1a4fa0" stroke-width="1"/>')
    for yy in (y1, y2):
        A(f'<line x1="{x-5}" y1="{yy}" x2="{x+5}" y2="{yy}" stroke="#1a4fa0"/>')
    if x < 300: A(f'<text x="{x-8}" y="{(y1+y2)/2+4}" fill="#1a4fa0" text-anchor="end">{text}</text>')
    else: A(f'<text x="{x+8}" y="{(y1+y2)/2+4}" fill="#1a4fa0">{text}</text>')

top = Y(cap_od / 2)
dim(X(0), X(tube_len), top - 44, f"printed coil form 105 mm (4.13 in), printed standing up")
dim(X(sock), X(tube_len - sock), top - 22, f"grooved winding area 75.6 mm: 54 turns @ 1.40 mm pitch (18 AWG) or 44 turns @ 1.70 (16 AWG)")
dim(X(-face), X(tube_len + face), Y(-cap_od / 2) + 30, "body length cap-to-cap 119 mm (4.69 in)", above=False)
dim(X(-face - 16), X(tube_len + face + 16), Y(-cap_od / 2) + 56, "overall incl. SO-239s approx. 151 mm (5.9 in); form wall 2.5, groove 0.6 deep (1.9 mm wall under groove)", above=False)
vdim(X(-face - 16 - 28), Y(cap_od / 2), Y(-cap_od / 2), "cap OD 39.4")
vdim(X(tube_len + face + 16 + 40), Y(tube_od / 2), Y(-tube_od / 2), "form OD 33.4 (spigot fits cap socket)")
A(f'<text x="{X(tube_len + face + 16 + 40)+8}" y="{cy+22}" fill="#1a4fa0">form ID 28.4 (wall 2.5)</text>')
dim(X(0), X(sock), Y(-cap_od / 2) + 8, "socket 12", above=False)
dim(X(-face), X(0), top - 2, "face 7")

# callouts
A(f'<text x="{X(sock+1.5)}" y="{Y(-cap_od/2)+90}" fill="#7a3d12">Wire entry: 2.2 mm radial hole molded into the form at the start and end of the groove;</text>')
A(f'<text x="{X(sock+1.5)}" y="{Y(-cap_od/2)+106}" fill="#7a3d12">wire runs INTO the bore and solders to the center-pin tail. Groove is a shallow half-round the wire snaps into.</text>')
A(f'<line x1="{X(sock+1.5)}" y1="{Y(-cap_od/2)+78}" x2="{X(sock+1.5)}" y2="{Y(tube_od/2+1.4)}" stroke="#7a3d12" stroke-width="0.8" stroke-dasharray="3 3"/>')
A(f'<text x="{X(tube_len+face+6)}" y="{Y(18.24/2)-10}" fill="#222">#4 self-tap into blind 2.6 mm pilots</text>')
A(f'<text x="{X(tube_len+face+6)}" y="{Y(18.24/2)+4}" fill="#222">(or M3 heat-set inserts, 4.0 mm hole)</text>')
A(f'<text x="{X(-face-16)}" y="{Y(-cap_od/2)+130}" fill="#222">SO-239 flange 25.4 sq, holes 18.24 sq</text>')
A(f'<text x="{X(-face-16)}" y="{Y(-cap_od/2)+146}" fill="#222">body 15.9 through 16.5 hole</text>')

# ---------- electrical schematic ----------
ey = 610
A(f'<text x="24" y="{ey-58}" font-size="18" font-weight="bold">Electrical: pure series inductance, center conductor only</text>')
def inductor(x, y, n=6, label=""):
    d = "M %d %d " % (x, y)
    for i in range(n):
        d += f"a 9 9 0 0 1 18 0 "
    A(f'<path d="{d}" fill="none" stroke="#222" stroke-width="2.5"/>')
    A(f'<text x="{x+9*n}" y="{y-16}" text-anchor="middle" font-weight="bold">{label}</text>')
    return x + 18 * n

x = 150
A(f'<text x="{x}" y="{ey+5}" text-anchor="end">Collapsible whip</text>')
A(f'<line x1="{x+6}" y1="{ey}" x2="{x+60}" y2="{ey}" stroke="#222" stroke-width="2.5"/>')
x += 60
for i, (lab, dash) in enumerate([("L1", False), ("L2 (optional)", True), ("L3 (optional)", True)]):
    # connector dots at each end of the coil = SO-239 / BNC junctions
    A(f'<circle cx="{x}" cy="{ey}" r="5" fill="white" stroke="#222" stroke-width="2"/>')
    x += 10
    A(f'<line x1="{x-5}" y1="{ey}" x2="{x+20}" y2="{ey}" stroke="#222" stroke-width="2.5"/>')
    x += 20
    x2 = inductor(x, ey, 6, lab)
    if dash:
        A(f'<rect x="{x-32}" y="{ey-42}" width="{x2-x+64}" height="60" fill="none" stroke="#999" stroke-dasharray="5 4"/>')
    x = x2
    A(f'<line x1="{x}" y1="{ey}" x2="{x+25}" y2="{ey}" stroke="#222" stroke-width="2.5"/>')
    x += 25
    A(f'<circle cx="{x}" cy="{ey}" r="5" fill="white" stroke="#222" stroke-width="2"/>')
    x += 5
    # male-male adapter between units
    A(f'<rect x="{x+2}" y="{ey-8}" width="30" height="16" fill="#eee" stroke="#222"/>')
    A(f'<text x="{x+17}" y="{ey+32}" text-anchor="middle" fill="#555" font-size="11">M-M adapter</text>')
    x += 34
A(f'<line x1="{x}" y1="{ey}" x2="{x+60}" y2="{ey}" stroke="#222" stroke-width="2.5"/>')
A(f'<text x="{x+66}" y="{ey+5}">Antenna mount / radio (center)</text>')

notes = [
    "Shells (threads) of the two connectors are NOT bonded to each other and NOT connected to the coil.",
    "A conductor tying shell to shell would run parallel to the coil and act as a shorted turn; leave the shells floating.",
    "Each unit is female-female, so stacking 2 or 3 needs a double-male adapter between them (PL-259 M-M or BNC M-M).",
    "Tune by extending or collapsing the whip; add units for lower bands. Taps can be added later via the pilot-hole pattern or a side screw.",
]
for i, t in enumerate(notes):
    A(f'<text x="24" y="{ey+70+i*20}" fill="#333">&#8226; {t}</text>')

# ---------- values table ----------
ty = ey + 175
A(f'<text x="150" y="{ey+50}" fill="#555" font-size="11">open circles = female connector (SO-239 or BNC) on each cap</text>')
A(f'<text x="24" y="{ty}" font-size="18" font-weight="bold">Estimated inductance (Wheeler) for the grooved forms</text>')
rows = [
    ("Version", "Form", "Wire / pitch", "full groove", "40 t", "30 t", "20 t", "", "wire needed"),
    ("BNC", "OD 26.7", "18 AWG / 1.40", "54 t: 25 uH", "18 uH", "13 uH", "8 uH", "", "4.9 m"),
    ("BNC", "OD 26.7", "16 AWG / 1.70", "44 t: 17 uH", "15 uH", "11 uH", "7 uH", "", "4.0 m"),
    ("SO-239", "OD 33.4", "18 AWG / 1.40", "54 t: 38 uH", "26 uH", "18 uH", "11 uH", "", "6.0 m"),
    ("SO-239", "OD 33.4", "16 AWG / 1.70", "44 t: 25 uH", "23 uH", "16 uH", "10 uH", "", "5.0 m"),
]
colx = [24, 100, 200, 330, 450, 530, 610, 690, 720]
for r, row in enumerate(rows):
    yy = ty + 26 + r * 22
    if r == 0:
        A(f'<rect x="20" y="{yy-16}" width="860" height="22" fill="#e8edf3"/>')
    for c, cell in enumerate(row):
        A(f'<text x="{colx[c]}" y="{yy}" font-weight="{"bold" if r==0 else "normal"}">{cell}</text>')
A(f'<text x="24" y="{ty+26+len(rows)*22+8}" fill="#555" font-size="12">Partial-fill values assume you wind N turns starting at one end and leave the rest of the groove empty. Accuracy about +/-10 %. 100 W SSB/CW fine; see README for duty-cycle notes.</text>')

A('</svg>')
open("schematic.svg", "w").write("\n".join(out))
print("turns drawn:", turns)
