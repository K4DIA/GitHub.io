# Whip Loading Coils, fully 3D-printed

Base-loading coils that sit between an antenna mount and a telescoping whip, electrically lengthening the whip for 40, 20 and 15 m. Two designs share the same end cap and the same grooved-form construction:

- **Rev B, fixed.** Grooved form, two end caps, female connector both ends. Tune with the whip. BNC or SO-239.
- **Rev C, tunable.** Same base, plus a sliding sleeve with five spring-loaded ball contacts that ride the valley between turns. One revolution of the sleeve is one turn of coil. SO-239.

Stack one to three units with male-male adapters. Operating use, band tables, load and wind limits, and guying are in `OPERATING-MANUAL.pdf`. This file covers building.

## Package contents

| File | Purpose |
|---|---|
| `endcap_BNC_x2.stl` | End cap, 26.7 mm socket, 4-hole BNC bulkhead. Print 2 per fixed coil. |
| `endcap_SO239_x2.stl` | End cap, 33.4 mm socket, 1 in square-flange SO-239. Print 2 per fixed coil, 1 per tunable unit. |
| `coilform_BNC_18AWG.stl`, `coilform_BNC_16AWG.stl` | Rev B form, OD 26.7, for the BNC caps. One per coil, pick the one for your wire. |
| `coilform_SO239_18AWG.stl`, `coilform_SO239_16AWG.stl` | Rev B form, OD 33.4, for the SO-239 caps. One per coil. |
| `tuner_form_SO239.stl` | Rev C form: 2.0 mm pitch, 48 turns, bearing land on top. One per tunable unit. |
| `tuner_sleeve_SO239.stl` | Rev C sleeve with five contact stations and SO-239 face. One per tunable unit. |
| `guy_collar_12.7mm.stl` | Split collar for guying at the whip base, 1/2 in bore. |
| `step/*.step` | Native STEP (AP214) of every rev B and rev C part, built as B-rep solids with true cylinders and swept helical grooves, plus `loading_coil_all_parts.step` with all nine in one file. Rev D STEP files are in `revD/`. Use these for CAD edits; the STLs are for printing. Threads are not modeled; every threaded hole is at tap-drill size. |
| `make_step.py` | CadQuery generator for the STEP files, same dimension tables as the STL generators. |
| `endcap.scad` | OpenSCAD source for the end caps, same geometry as the STLs. |
| `make_caps.py`, `make_form.py`, `make_tuner.py`, `make_guy_collar.py` | Parametric generators for every STL. Each one proves its output is a closed, printable volume before writing it. |
| `qa_check.py` | Reloads every STL and checks mesh validity, inverted faces, volume against the matching STEP solid, and part-to-part fit. Run it after changing any parameter. |
| `schematic.svg` / `.png` | Rev B: dimensioned section, electrical, inductance table. |
| `tuner_schematic.svg` / `.png` | Rev C: section, station detail, electrical. |
| `OPERATING-MANUAL.pdf` / `.md`, `chart_*.png`, `manual.css` | Operating and deployment manual with its charts and build scripts. |
| `ASSEMBLY-MANUAL.pdf`, `assembly-manual-src/` | Rev D assembly manual, picture per step from the STLs with the hardware in place, and the scripts that render and lay it out. |
| `make_schematic.py`, `make_tuner_schematic.py`, `make_revD_schematic.py`, `make_top_section.py`, `make_hub_drawing.py`, `make_manual_charts.py` | Drawing and chart generators. `make_top_section.py revD/revD_dims.json out.svg` draws the housing-top section and `make_foot_drawing.py revD/revD_dims.json out.svg` the leg-foot section, both from the dimension file, with callouts kept outside the parts. The hub machining drawing is generated from the same parameters as its STEP. |
| `BOM.md`, `BOM.csv` | Rev D bill of materials: every printed part and every piece of hardware, with sources and rough prices. |
| `revD/` | Rev D tripod-hub unit, all printed: hub, housing, threaded collar, form, swivel cap and leg foot as STEP and STL, schematic, foot section, dimensions, tip-over table, insert and ballast sheet, and `assembly/` with the exploded, assembled and step figures. `machined_alt/` has the hub as a 6061 part with its drawing. See the rev D section. |
| `preview_caps.png`, `preview_step.png` | Renders of the end caps and of three STEP parts. |

All STLs are exported in print orientation. No supports on any part.

## Design notes

**End caps are sockets, not plugs.** A 1 in square SO-239 flange is 35.9 mm across the corners, wider than a 33.4 mm form. The cap slips over the form (OD 39.4) so the flange sits entirely on the 7 mm face. The same applies to the BNC cap at its smaller scale.

**Connector screws go into blind pilots.** The SO-239 hole pattern (18.24 mm) lands over the form wall once the form is inside the cap, so nuts are impossible. #4 self-tapping screws into 2.6 mm blind pilots in the face hold fine in PETG; set `pilot_dia` to 4.0 for M3 heat-set inserts instead. BNC: #2-56 or M2.5 into 2.1 mm pilots.

**Wire enters through the form wall, not the cap face.** The SO-239 flange covers every point of the cap face that is over the bore. A 2.2 mm radial hole is molded into the form at each end of the groove; the tail goes in there and down to the connector center-pin tail. The BNC cap has an optional 3.2 mm face hole as well, since its flange leaves room.

**Form ODs match Schedule 40 pipe** (26.67 and 33.40 mm), so a PVC tube can substitute for a printed form in a pinch if you cut your own wire holes.

**Stacking needs adapters.** Every unit is female both ends; use a PL-259 double-male or BNC male-male between units.

**Connector shells float.** A conductor tying the two shells together runs parallel to the winding and acts as a shorted turn.

**BNC bulkheads vary by maker.** The 0.380 in hole pattern is common (UG-290, Amphenol 31-10), but flange and hole sizes differ. Measure before printing; the pattern is one parameter in `make_caps.py`.

## The grooved form

- Shallow half-round helical groove, not a thread. Rev B: 0.6 mm deep at 1.40 mm pitch for 18 AWG (1.08 mm enamel OD) or 0.75 deep at 1.70 mm pitch for 16 AWG (1.35 mm). The wire sits about half its diameter in the groove and snaps in; the groove holds it and sets the spacing.
- Pitch is about 1.3x wire diameter on purpose. Spaced turns lower self-capacitance and turn-to-turn heating, so the coil runs cooler with higher Q. The cost is about 15% less inductance per unit length than close-wound, and the form is long enough to absorb that.
- Wall 2.5 mm, 1.9 mm (18 AWG) or 1.75 mm (16 AWG) under the groove. Hollow bore keeps plastic out of the field.
- Rev B groove occupies 75.6 mm (54 turns at 1.40) or 74.8 mm (44 turns at 1.70). The 14 mm plain spigot at each end is what the cap socket grips.
- Winding fewer turns than the groove holds is fine: start at one end, stop where you need, cut. Empty groove does nothing.

### 100 W on a plastic form

At 100 W the RF current through a base-loading coil is around 2 A. 16 or 18 AWG at HF has an effective resistance of a fraction of an ohm over this length, so dissipation is low single-digit watts spread over 75 to 100 mm of form. PETG (softens at 75 to 80 C) handles that at SSB and CW duty cycles. For FT8, RTTY, or long key-down at 100 W, print in ASA or polycarbonate, or hold power to 50 W. Keep the coil out of a closed car in summer. The thermal weak point is the solder joint at the connector tail, not the winding; leave enough slack that the wire is not under tension when the cap is pushed home.

Dielectric loss in PETG and ASA is acceptable at HF for a loading coil. Never use carbon-fiber or other conductive filaments.

## Rev B fixed coil

### Connector fit

| | BNC cap | SO-239 cap |
|---|---|---|
| Form | OD 26.7, ID 21.7, wall 2.5 | OD 33.4, ID 28.4, wall 2.5 |
| Socket bore | 27.07 (0.4 mm diametral clearance) | 33.80 |
| Cap OD / height | 32.7 / 19 mm | 39.4 / 19 mm |
| Connector body hole | 9.8 mm (body 9.5) | 16.5 mm (body 15.9) |
| Flange | 12.7 sq, corners r 9.0 (cap r 16.3) | 25.4 sq, corners r 18.0 (cap r 19.7) |
| Mount holes | 4 x 2.1 mm blind, 9.65 sq | 4 x 2.6 mm blind, 18.24 sq |
| Wire hole in face | 3.2 mm at r 8.5 (optional) | none, use the form entry hole |
| Mass, 100% PETG | about 11 g each | about 14 g each |

Socket bore is 0.4 mm over the spigot. Tight: raise `tube_clearance` in `make_caps.py` to 0.6. Loose: drop to 0.2. Print one cap and one form end first.

### Stack-up

Form 105 mm; socket 12 mm each end; 81 mm exposed between caps; faces 7 mm; 119 mm cap to cap; about 151 mm overall with SO-239s, 140 mm with BNCs.

### Print settings

- PETG, or ASA for outdoor UV. ABS works. PLA creeps in a hot car.
- Caps: face down, socket up, 0.2 mm layers, 4 perimeters, 5 top/bottom layers, 40 to 60% infill. The face is where the screws bite; perimeters matter more than infill.
- Form: standing on end, 0.12 to 0.16 mm layers so the groove prints as a smooth half-round rather than a staircase, 3 perimeters, 20% infill, brim.

### Bill of materials, per coil

- 1 printed form, 2 printed caps
- 2 bulkhead connectors: BNC 4-hole female, or SO-239 square flange
- 8 screws: #2-56 x 1/4 in or M2.5 x 6 (BNC); #4 x 3/8 in self-tapping, or M3 x 6 with heat-set inserts (SO-239)
- 16 or 18 AWG enameled magnet wire, 4.0 to 6.0 m by version (table below)
- CA or epoxy for the caps (optional, the socket is a friction fit)
- Clear coat, tape, or heat-shrink over the winding (optional)
- PL-259 double-male or BNC male-male adapter between stacked units

### Assembly

1. Clean stringing out of the groove and the two entry holes (2 mm drill by hand).
2. Feed 60 mm of wire into the first entry hole, wind into the groove under tension so each turn snaps in, feed the far tail into the second entry hole. The groove ends exactly at each hole.
3. Strip the enamel from the last 10 mm of each tail; tin.
4. Solder each tail to the center-pin cup of its connector.
5. Screw the connectors to the caps, connector outside, tail inside.
6. Push the caps onto the form, taking up slack in the tails. Glue if desired.
7. Secure the winding with clear coat, heat-shrink, or tape.

### Coil values, Wheeler formula, within about 10%

| Version | Wire / pitch | Full groove | 40 t | 30 t | 20 t | Wire needed |
|---|---|---|---|---|---|---|
| BNC, OD 26.7 | 18 AWG / 1.40 | 54 t: 25 uH | 18 uH | 13 uH | 8 uH | 4.9 m |
| BNC, OD 26.7 | 16 AWG / 1.70 | 44 t: 17 uH | 15 uH | 11 uH | 7 uH | 4.0 m |
| SO-239, OD 33.4 | 18 AWG / 1.40 | 54 t: 38 uH | 26 uH | 18 uH | 11 uH | 6.0 m |
| SO-239, OD 33.4 | 16 AWG / 1.70 | 44 t: 25 uH | 23 uH | 16 uH | 10 uH | 5.0 m |

Different pitch, wall, or length: change `pitch`, `groove_r`, `wall`, or `length` in `make_form.py`, re-run it, then run `qa_check.py`.

## Rev C tunable unit

### How it works

The base is a rev B SO-239 cap on a longer form. The top end of the coil floats. The whip connector is on a sleeve that slides over the form; five spring-loaded brass balls near the bottom of the sleeve press into the valley between turns. Twist the sleeve and the balls track the helix like a nut on a thread, one turn per revolution. Turns below the balls are the antenna; turns above are dead. Active turns are the ones visible below the sleeve, so a setting is repeatable by count.

### Design decisions

- **Bare wire.** 18 AWG bare tinned copper (1.02 mm), about 5.5 m. The groove sets the spacing, and the balls need copper.
- **2.0 mm pitch, 100 mm coil.** Wider than rev B so the balls seat in a real valley. 48 turns, 24 uH full, 3 uH at 10 turns. For 40 m with a short whip, stack a fixed rev B underneath.
- **Five identical stations at 72 degrees,** each 0.4 mm further along the axis so all five sit in the same helical valley at once. The ring starts 10 mm above the sleeve bottom so the bosses stay above the print bed.
- **All five conductive, bused together.** Five parallel contact points at about 5 N each; any one failing is invisible electrically, and the tap is defined by a turn count rather than by where a single finger happens to touch.
- **Fixed-depth stations.** The stem bottoms on a shoulder, the cap bottoms on the stem. Pressure is set by geometry; nothing to adjust, nothing to over-tighten, and any station can be opened for cleaning with the sleeve on the form. A 1 mm printed lip keeps the ball captive when the sleeve is off. Seated between two turns, the ball sits 0.2 mm below the wire crests and 0.5 mm short of the lip, so it rides on copper, never on plastic; the valley-to-crest detent is 0.2 mm.
- **Bearing land.** 40 mm smooth cylinder at crest diameter above the coil, so the sleeve rides on at least 40 mm of form at every tap. This is what keeps the whip steady.
- **Shells float** at both connectors.

### Station hardware, five per sleeve, all tire-valve parts

The boss is printed with a 7.0 mm bore and tapped **.305-32 UNEF right-hand** (ISO 4570 "8V1", the Schrader stem external thread, 7.7 mm x 0.794 mm). Taps are sold as tire valve stem taps; a 5/16-32 UNEF tap also works, slightly loose. Everything that screws into it is a tire-shop part, metal, and replaceable.

| Item | Spec | Note |
|---|---|---|
| Ball | 5/32 in (3.97 mm) brass | Conductive, no rust. |
| Spring housing | Brass valve stem threaded .305-32 along its body (all-brass clamp-in stems such as TR416 or TR418 type), cut to 18 to 20 mm | 10 mm threads into the boss and bottoms on the chamber shoulder; the rest is exposed for the nut and cap, so cut longer if your cap is tall. Check the stem first: the cap must thread all the way down the body. Hacksaw, deburr, remove the valve core. |
| Spring | Phosphor bronze or beryllium copper, 4.0 mm OD, 0.55 mm wire, 25 mm free, compression | The spring is in the RF path, so material matters: see below. Fits the 5.3 mm stem bore. Sits at about 20 mm in place with an 18 mm stem, about 5 N per ball, 25 N total. Stainless 302 is acceptable at 50 W. Music wire, never. |
| Lock nut | The stem's own knurled nut | Clamps the bus-wire ring terminal against the boss face. |
| Cap | Metal Schrader valve cap, brass or nickel-plated | Sets the preload by bottoming on the stem. Not anodized aluminum; anodizing is an insulator. |
| Terminal | Ring terminal, 5/16 in stud, 18 to 22 AWG | Bus all five. |

Electrical path: ball, spring, cap, stem threads, lock nut, ring terminal, bus wire, sleeve connector center pin.

**Why the spring material matters.** At 100 W on 40 m about 2 A of RF flows through the five springs in parallel. Steel music wire is magnetic, so its skin depth at 14 MHz is about 5 um and a 12-coil spring presents about 4 ohms at RF: 3.4 W of heat for the set, inside plastic bosses that soften at 80 C. Phosphor bronze or beryllium copper springs present about 0.2 ohms each, 0.2 W for the set. Stainless 302 lands at 0.65 W, fine at 50 W. The springs' inductance (about 90 nH each, 18 nH for five) is equivalent to 0.04 turn of coil and does not affect tuning.

Sleeve connector: SO-239 square flange, four #4 self-tapping screws into blind pilots, same pattern as the base cap.

### Sizes

- Form 161 mm: 14 mm spigot, 7 mm gap, 100 mm coil, 40 mm land. Crest OD 34.24.
- Sleeve 169 mm, OD 40.7, bore 34.74. Printed bosses 65 to 68 mm across; about 85 mm across the valve caps.
- Overall with connectors: 220 mm at turn 1, 316 mm at turn 48. Printed mass about 150 g plus hardware and wire.
- At turn 1 the sleeve bottom clears the base cap by 0.1 mm; every turn is reachable. Connector tail pocket inside the sleeve is 13 mm at the lowest tap.

### Print settings

- Form: standing, 0.12 to 0.16 mm layers, 3 perimeters, brim.
- Sleeve: open end down, 0.16 to 0.2 mm layers, 4 perimeters (stations and connector face take screw loads), brim. The bosses are squares on the diagonal, so the undersides are 45 degrees and print without support.
- Clean the five 3.4 mm lip holes with a 3.3 mm drill by hand so the balls move freely. Tap the five 7.0 mm bores .305-32, backing the tap out every half turn. Clean the bore; it rides on the wire crests with 0.25 mm radial clearance, so stringing matters.

### Assembly

1. Base: wind the form as for rev B. Feed the tail into the bottom entry hole, wind into the groove, feed the far tail into the top entry hole and leave it; it connects to nothing. Solder the bottom tail to the base SO-239 tail, screw the connector to the base cap, push the cap onto the spigot. Glue this joint once the fit is confirmed; it carries the whip's bending load.
2. Sleeve: screw the SO-239 to the face. At each station: lock nut and ring terminal onto the stem first, nut loose; thread the stem in until it bottoms; drop in the ball; drop the spring into the stem; screw the metal cap on until it bottoms; snug the lock nut against the boss face. Loop the bus wire through the five terminals, run the tail through the side hole into the pocket and solder it to the connector center pin, reaching in from the open end before the sleeve goes on the form.
3. Slide the sleeve onto the form from the top and twist it on. It clicks into the first valley.
4. Before step 3: line the sleeve bore above the station ring with self-adhesive copper tape and solder a lead from it to the bus. This shorts the dead turns the way a screwdriver antenna's mast does. Without it the open dead turns above the tap can resonate on their own and put jumps in the SWR as the sleeve moves.

### Operating notes

- Twist, never shove. The valley is shallow by design; a hard axial push can skip a turn, twisting cannot.
- One full revolution is one turn. The bosses are the grip. The sleeve picks the band; the whip picks the frequency. One turn is 94 kHz on 40 m and 625 kHz on 20 m, so on 20 m and up a single turn is wider than the band and the whip does the fine work. Numbers in the operating manual.
- Noisy contact: unscrew one valve cap, tip out spring and ball, wipe them and the wire crests with isopropyl, reassemble. Nothing else moves.

## Rev D tripod-hub tunable unit, 3/8-24 whip

The rev C layout put the whip on the moving part. Rev D turns it around. A one-piece printed hub carries the tripod legs and the radial bolt. The printed housing comes up through the hub from below, hangs from a printed collar threaded onto its top above the boss face, and carries the whip at its top and the five balls at its bottom. The coil form screws up into the housing from below and is turned by hand between the legs. Tuning moves nothing that is loaded. Built for the Chameleon CHA SS17: 17 ft, ten sections, 27 in collapsed, 0.63 in (16.0 mm) base, 0.9 lb, standard 3/8-24 stud. Any 17 ft stainless whip with the same base diameter fits; a different base diameter is one parameter, `whip.base_od` in `make_revD.py`.

Every part is printed except the legs, which are bought 1/2 in aluminum tube. Files are in `revD/`: `revD_tripod_hub_PRINT`, `revD_sleeve_hub` (the housing), `revD_collar`, `revD_form`, `revD_swivel_cap`, `revD_leg_foot` (print three), each as STEP and STL; `revD_all_parts.step`; `revD_schematic.svg/.png`; `revD_leg_foot_DRAWING.png`; `assembly/` (exploded, assembled and parts views, the housing-top section, the collar, one station, the swivel cap, the leg end, the insert procedure and the wiring diagram); `PRINTED-HUB.md` (inserts and ballast); `revD_dims.json` and `tipover.json`. The generators `make_revD.py` and `make_tipover.py` at the top of the package produce them. `revD/machined_alt/` holds the same hub as a machined 6061 part (STEP in AP214 and AP203, `revD_tripod_hub_DRAWING.pdf`, `TRIPOD-HUB-MACHINING.md`) for anyone who wants metal; nothing else in the package depends on it. Rev B and rev C stay as they are.

### How it works

- **Tripod hub** (printed, 98 x 29 body with a 40 deg chamfer on the bottom edge, 52 x 36 boss with a rib for the set-screw insert, 41 mm bore straight through, 177 cm3, about 180 g in PA12 or 225 g in PETG). Three leg holes in the chamfer face, each square to it, so the chamfer is the leg seat and the holes point in and up, clear of the bore; each takes a 3/8-16 brass heat-set insert. Three 1/4-20 insert holes on top: one is the ground bolt for the radials and the coax shield, the other two are spares. An M5 insert in a rib on the boss for the set screw, 11 mm of wall for a 9.5 mm insert. K4DIA recessed 0.8 mm into the top face in each of the three sectors.
- **Housing** (printed, 284 mm, OD 40.7, 156 cm3). From the top: 14 mm of external thread at 3.0 mm pitch for the collar, a 34 mm bore that captures the whip's base section, a 3 mm ledge, and a 3/8-24 brass coupling nut captive in a hex pocket. The whip's bending goes from its base through the housing wall into 65 mm of hub bore; the stud only holds it down. Below that, 218 mm of bore for the form, five ball stations at the bottom rim, copper-tape lining above them. A groove 24 mm below the top takes the set screw, which only stops rotation.
- **Collar** (printed, 52 mm OD, 12 mm tall, 8 flutes, 9 cm3, internal thread at 3.0 mm pitch, four turns engaged). It screws onto the housing from above and sits on the boss face, so it carries the housing, the whip and the form. Print it flat; the thread needs no support. K4DIA is recessed 1.2 mm into the outside of the tube on the band visible below the hub, 11 mm letters reading up the tube; the recess floor follows the cylinder so the depth is uniform.
- **Form** (249 mm). 30 mm bearing land on top, 80 turns of bare 18 AWG at 2.0 mm (42.8 uH full), a 44 mm fluted grip, a 25.4 mm journal with a brass ring. The bottom wire runs down a molded channel to the ring.
- **Swivel cap** (39 mm). Spins on the journal; two ball stations on the brass ring are the electrical joint; two M3 screw tips in a groove retain it. SO-239 on the foot. The coax hangs still while the form turns.
- **Legs.** Three 1/2 in x 0.058 wall 6061 tubes, 750 mm, with a 3/8-16 stud epoxied into the top end. They screw straight into the chamfer face at 40 deg: 575 mm of height, 520 mm foot radius.
- **Leg feet** (printed, three). A 46 mm cup, 70 tall, with a 12.9 mm socket angled 40 deg so the base sits flat, a cross hole for an M3 through the tube, a 36 x 26 ballast pocket underneath on a 1/4-20 insert, and a full-height ear with a 9 mm hole for a tent stake. Ballast is 1-1/4 in fender washers or lead on a 1/4-20 bolt whose head is the foot; a lead slug can also go up the tube before the foot goes on. Section in `revD_leg_foot_DRAWING.png`.

Electrical path: coax center, swivel SO-239, two balls, brass ring, coil bottom, active turns, five balls, bus wire, inside bolt, coupling nut, whip. Coax shield and radials together on one 1/4-20 bolt in the hub top, ring terminals stacked under its head. The hub and legs are plastic and aluminum that carry no current; the ground side of the antenna is the radials, and the hub only holds the bolt.

Active turns are the ones below the housing rim. One revolution of the form is one turn, 2 mm of travel. Fully in, one turn is active; fully out, 80 turns and 197 mm of form hang below the housing rim. The housing rim is 209 mm below the hub body, so with the form fully out the connector is about 460 mm below the hub; 750 mm legs at 40 deg give 575 mm.

### Loads

Whip bending: whip base, housing top, hub bore, body, legs. The 3/8-24 stud carries tension only. The SS17's 16 mm stainless base is good for 45 N m (tube) to 80 N m (solid); fully extended it puts 8 N m on the base at 20 mph and 18 N m at 30 mph, and at 0.41 kg its weight adds under 1 N m at 5 deg of lean. Bearing stress on the PETG whip bore at 30 mph is about 14 MPa against 50 allowable; the hub bore wall sees under 5 MPa in PA12 against 48 at yield. The printed hub is 40 times less stiff than aluminum, so the whip sways more in gusts; it does not break. Tripod stability comes first: with 1.7 kg of hardware on a 520 mm foot radius the free-standing tripod tips at about 13 mph, 17 mph with 425 g of ballast in every foot. The stake ears are what hold it above that; ballast is for the days you do not want to drive stakes.

### Bands, 17 ft whip (5.18 m)

| Band | Needs | Active turns | One turn moves resonance | Whip sensitivity | Efficiency, 15 ohm ground |
|---|---|---|---|---|---|
| 80 m | 40.4 uH | 76 | 25 kHz | 3 kHz per cm | 7% |
| 60 m | 17.4 uH | 37 | 73 kHz | 5 kHz per cm | 15% |
| 40 m | 8.8 uH | 21 | 163 kHz | 7 kHz per cm | 25% |
| 30 m | 3.1 uH | 10 | 380 kHz | 13 kHz per cm | 43% |
| 20 m | none | 1, form fully in | | | 61% |
| 17 to 10 m | none | 1 | collapse the whip to a quarter wave: 4.14, 3.54, 3.01, 2.64 m | | |

### Hardware, rev D

The full list with sources and prices is `BOM.md` at the top of the package. Summary:

| Item | Qty | Spec |
|---|---|---|
| Printed parts | 8 | Hub, housing, collar, form, swivel cap, three feet. MJF PA12 at a print service or PETG/ASA at home; hub and feet at 6 walls and 40% infill minimum. |
| Heat-set inserts, hub | 7 | 3 x 3/8-16 x 1/2 in, 0.469 in OD, 15/32 hole (HI-316-WH, Zoro 1GUA1) in the leg holes; 3 x 1/4-20 x 1/2 in, 0.315 in OD, 5/16 hole (HI-420-WH, Zoro G3434347) on top; 1 x M5 x 9.5 long, 6.4 OD, 6.4 hole (ruthex or CNC Kitchen type) in the boss rib. Set with a soldering iron at 200 C. |
| Heat-set inserts, feet | 3 | 1/4-20, one in each ballast pocket ceiling. |
| Ground bolt | 1 | 1/4-20 x 3/4 in stainless with two washers and a nut: radials and coax shield on ring terminals under the head. |
| Ballast | 3 sets | 1/4-20 x 1-1/2 in hex bolt with 1-1/4 in fender washers to fill the 36 x 26 pocket (about 135 g), or lead cast into the pocket (about 300 g), or a 150 mm lead slug in each tube (about 125 g). Bolt head is the foot; a 1/4-20 rubber bumper screws in instead for indoor floors. |
| Foot pins | 3 | M3 x 20 screw and nut through the foot cross hole and the tube; drill the tube in place. |
| Stakes | 3 | 8 mm tent stakes through the foot ears. |
| Coupling nut | 1 | Brass 3/8-24, 9/16 in AF, 1-1/8 in long, in the housing's hex pocket. |
| Inside bolt | 1 | Brass 3/8-24 x 1/2 in with a 3/8 in ring terminal for the bus and lining. |
| Set screw | 1 | M5 x 16, nylon or brass tipped, into the M5 insert through the boss rib. |
| Ball stations | 7 | 5 in the housing rim, 2 in the swivel cap. 5/32 in brass ball, PB or BeCu spring 4.0 x 0.55 x 25, brass stem .305-32 cut to 18 to 20 mm, stem nut, metal cap, ring terminal. |
| Brass ring | 1 | K&S 1 in OD x 0.014 wall brass tube, cut 8 mm, onto the journal recess. |
| Retaining screws | 2 | M3 x 10 self-tapping, through the swivel cap. |
| SO-239 | 1 | Square flange on the swivel cap foot, 4 x #4 self-tapping. One screw also takes a ring terminal for the shield wire to the hub. |
| Legs | 3 | 1/2 in OD x 0.058 wall 6061-T6 round tube (ID 0.384 in, about 80 g each), 750 mm, from McMaster-Carr, OnlineMetals or Speedy Metals. Epoxy a 3/8-16 x 1-1/2 in stud (or a bolt with the head cut off) 1 in into the top end, 1/2 in showing. A 2 in stud bottoms in the 17 mm hole before the tube seats. A 3/8 rod slides into this ID; 0.065 wall does not take the stud. |
| Wire | 1 | Bare tinned 18 AWG, about 9.5 m. |
| Copper tape | 1 | Self-adhesive, to line the housing bore above the stations. |

### Assembly, rev D

1. Housing: tap the five station bores .305-32. Line the bore above the station ring with copper tape, leaving the top 30 mm clear. Drop the coupling nut into the hex pocket from inside; screw in the inside bolt with the ring terminal, trapping a lead from the lining. Build the five stations as for rev C, bus their lock-nut terminals, run the bus through the side hole to the inside bolt.
2. Hub: set the three 3/8-16 inserts in the chamfer face, the three 1/4-20 on top and the M5 in the boss, each pressed square to its face with the iron and left to cool. Ground bolt into one top insert.
2a. Legs: epoxy a 3/8-16 x 1-1/2 in stud 1 in into the top of each tube, 1/2 in showing. Slide the bottom end into a foot socket, drill 3.4 through the foot cross hole and the tube, pin with an M3. Drop a lead slug up the tube first if you are using one. Ballast on its bolt into the foot insert. Screw the legs into the hub by hand.
3. Feed the housing up through the hub bore from below until its threaded top stands above the boss. Screw the collar onto it from above until the collar sits on the boss face; the collar carries the load. Set screw in until it touches the groove, then a quarter turn.
4. Form: wind 80 turns from the bottom entry of the groove, leaving 150 mm of tail at the bottom; tuck the top tail into the bore. Brass ring onto the journal recess, tail down the channel through the grip to the ring, solder.
5. Swivel cap: tap the two station bores. SO-239 to the foot with a ring terminal under one screw for the shield wire; lead from its tail out through the side hole; build the two stations on that lead. Cap onto the journal, M3 screws in to the groove and a quarter turn back.
6. Feed the form, land first, up into the housing from below and twist it in. Whip base into the housing top, stud tight. Shield wire from the swivel cap and the radials on ring terminals under the ground bolt head.

### Operating

- Grip the fluted collar and turn. Clockwise from below screws the form up: fewer active turns, higher band. Hold the swivel cap with the other hand so it does not drag the coax.
- Count active turns below the housing rim to repeat a setting; mark the form.
- The hub, the legs, the radials and the whip never move during tuning.
- Stake the feet through the ears above about 12 mph, or 15 mph with full ballast.

## Future revisions

- One male end on the fixed unit to eliminate adapters.
- Weather lip on the cap for a heat-shrink sleeve over the winding.
- Integrate one cap into the form, two parts instead of three, once the socket fit is dialed in.
- Rev B tap points: a row of 3 mm holes along the winding with a short clip lead, for a fixed unit that needs occasional re-banding without a sleeve.

## Verification

`qa_check.py` reloads every STL and checks, in order:

- Each mesh is watertight, a closed volume, consistently wound, and has nothing below the print bed. Every STL in the package, rev D included.
- No inverted faces (a point just outside every face is outside the solid), on every mesh small enough to ray-test.
- Mesh volume within 1% of the B-rep STEP solid of the same part. This is the check that catches a phantom shell left behind by a bad boolean, which the watertight test cannot see.
- Cap socket bore over form spigot, both sizes: 0.39 mm diametral (design 0.4).
- Sleeve bore over the bearing land and over the wire crests: 0.49 mm.
- SO-239 flange corner (r 17.96) inside the cap face (r 19.70) by 1.7 mm.

Rev D, against the STEP solids: the form and swivel cap inside the housing at both ends of travel, the housing in the hub bore, the set screw on the housing groove, the leg insert holes at least 2 mm from the bore and the top, the bore wall solid through the body, and the foot: a 1/2 in pin down the socket, an 8.5 mm stake through the ear, a 35 mm stack into the pocket, the insert hole clear, and the walls between socket, insert and pocket.

The generators additionally verify, at build time, that the five sleeve stations land on the form helix (within 0.001 mm), that the sleeve bottom clears the base cap at turn 1, and that the connector tail pocket is at least 13 mm.

Revision history:

- 2026-11-04: assembly manual rebuilt as a picture-per-step book rendered from the STLs (24 pages, landscape), generator in `assembly-manual-src/`. Housing-top and leg-foot drawings redrawn with callouts kept outside the parts.
- 2026-11-04: rev D housing now enters the hub from below and hangs from a separate printed collar threaded onto its top (3.0 mm pitch, four turns engaged) instead of a collar formed on the housing, so the housing prints without a flange and the whip bore deepens to 34 mm. Housing 284 mm, set screw M5 x 16 at 24 mm below the top. Assembly figures added in `revD/assembly/`. BOM updated: collar, tap, bus wire, whip and radials listed.
- 2026-10-21, rev A: end caps sized to real Schedule 40 pipe and real connector flanges.
- 2026-10-21, rev B: printed grooved form replaces pipe; molded wire-entry holes.
- 2026-10-21, rev C: tunable sleeve with five ball-contact stations. Coil raised 7 mm above the spigot so the sleeve reaches turn 1. Sliver faces from coincident cutter geometry removed from the caps and sleeve; every generator now proves its exported STL is watertight.
- 2026-10-21, rev C stations changed from M5 inserts to tapped .305-32 Schrader-stem housings, 13 mm boss, ring at 10 mm.
- 2026-11-03: documentation QA. Manual per-turn figure corrected to 0.5 to 0.6 uH; efficiency comparison column labeled as lossless quarter wave; README consolidated.
- 2026-11-03: rev D added: coil form turned from below, swivel SO-239 feed, 80-turn coil for 80 to 30 m on a 17 ft whip. Interference checked by boolean at both ends of travel.
- 2026-11-04: QA of the all-printed build. Found and fixed: 1/4-20 insert holes in the hub were 12 mm deep for a 12.7 mm insert (now 15); the foot insert hole was 10 deep (now 14, foot 70 tall); the boss wall was 5.4 mm for a 9.5 mm M5 insert (rib added, 11.4 mm); the called-out 2 in leg stud and 2 in ballast bolt both bottomed in their holes (now 1-1/2 in); insert part numbers replaced with verified ones (HI-316-WH, HI-420-WH). Added to `qa_check.py`: hole depths against insert and fastener lengths, and the leg-hole and foot-socket axes read from the B-rep faces (both 40 deg).
- 2026-11-04: rev D made all-printed. The hub is now the printed part with brass heat-set inserts and one ground bolt; the machined hub moved to `revD/machined_alt/` as an option. Printed leg feet added: angled socket, ballast pocket on a 1/4-20 insert, stake ear. Tip-over figure corrected: the lever arm for a tripod is half the foot radius, not the foot radius, so the free-standing limit is 13 mph, 17 mph with ballast; stakes above that. K4DIA stays in the hub top and the housing.
- 2026-11-04: callsign added: K4DIA engraved into the hub top face (x3, 0.5 deep) and recessed into the housing (1.2 deep, uniform floor). Both are in the STEP and STL; `engrave` parameters in `make_revD.py` set the text, size and depth.
- 2026-11-04: drawing QA against the STEP. Found: leg holes on the 76 mm hub broke into the bore (confirmed by the JLC viewer), the called-out spot-face would have cut the bore wall, 3 in bar could not clean up to 76, and the section label was wrong. Hub redesigned with a 40 deg chamfer seat and leg holes square to it, pointing in and up; 86 x 23 body; 3-1/2 in stock; finish changed to conductive chem film. Every drawing callout now measured against the STEP by script.
- 2026-11-04: machining drawing added for the hub (`revD_tripod_hub_DRAWING.pdf`): CNC quoting services treat the STEP as geometry only and take the thread specification from a drawing.
- 2026-11-04: rev D hub cut down to 76 x 22 with a 50 x 36 boss, 250 g instead of 680; legs changed to 1/2 in rod or tube on 3/8-16 ends, no printed leg parts.
- 2026-11-04: rev D locked to the Chameleon CHA SS17 (16.0 mm base, 0.41 kg); second leg plug added for 1 in aluminum tube; package rebuilt clean.
- 2026-11-04: rev D tripod reduced to one machined piece: body with three angled 1/2-13 leg holes, three 1/4-20 radial screws, boss with a set screw, 41 mm through bore. The housing now drops in from above and hangs from a collar on the boss; the whip-base bore moved into the housing top inside the aluminum, and the hub became the ground side with the whip insulated by the housing wall. Verified by boolean: housing in bore, set screw on groove, leg holes inside the body, form travel.
- 2026-11-03: full QA of all three builds against the STEP solids. Rev D leg hinge holes did not line up (plate cross hole 9 mm from the rim, adapter tab hole 15 mm above its collar); both now set from one parameter at 11 mm and proven by passing a 6.5 mm pin through both solids. Check added to `qa_check.py`.
- 2026-11-03: rev D structure moved to a machined aluminum tripod plate. The whip base is captured in a bored boss so the 3/8-24 stud carries tension only; the printed hub hangs from the plate on a stud and is no longer structural. Plate thread sized at 29 mm so both studs engage with 2 mm between them.
- 2026-11-03: spring changed from music wire to phosphor bronze or BeCu, 0.55 mm wire, after working the RF loss: steel springs would dissipate about 3.4 W at 100 W. Copper-tape lining of the sleeve made standard. Per-turn tuning steps and whip sensitivity added to the manual.
- 2026-11-03: full package QA against the STEP solids. Boolean interference tests, cap on form, sleeve on form and on wire at the first, second and last tap, all zero. Station geometry re-derived by hand: seated ball 0.2 mm below the crests, 0.5 mm short of the lip, spring at about 20 mm and 4 N (documents had said 19.5 mm and 4 to 6 N). Stem spec widened to 18 to 20 mm with a check that the cap threads the full body.
- 2026-11-03: STEP export added. Comparing STL volumes against the STEP solids exposed a phantom 2 mm disc across the connector hole in both end caps, left by overlapping cutters that had been merged before the boolean. Cap generator fixed, caps regenerated, volume-vs-STEP and inverted-face checks added to `qa_check.py`.
