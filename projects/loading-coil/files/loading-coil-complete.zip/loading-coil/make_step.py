#!/usr/bin/env python3
"""
Native STEP (AP214) export of every part, built as B-rep solids in CadQuery.
Same dimensions as the STL generators; the helical grooves are true swept solids.

Outputs (in step/):
  endcap_BNC.step, endcap_SO239.step
  coilform_BNC_18AWG.step, coilform_BNC_16AWG.step, coilform_SO239_18AWG.step, coilform_SO239_16AWG.step
  tuner_form_SO239.step, tuner_sleeve_SO239.step
  guy_collar_12.7mm.step
  loading_coil_all_parts.step   (every part in one file, laid out side by side)
"""
import math, os, sys
import cadquery as cq

OUT = sys.argv[1] if len(sys.argv) > 1 else "step"
os.makedirs(OUT, exist_ok=True)

# ---------------- end caps (same table as make_caps.py) ----------------
CAPS = {
    "BNC":   dict(tube_od=26.67, body_hole=9.8,  hole_pitch=9.65,  pilot_dia=2.1, face_wire=(8.5, 3.2)),
    "SO239": dict(tube_od=33.40, body_hole=16.5, hole_pitch=18.24, pilot_dia=2.6, face_wire=None),
}
CAP = dict(wall=3.0, face=7.0, socket_depth=12.0, tube_clearance=0.4, pilot_depth=5.5)


def endcap(v):
    p = {**CAP, **v}
    cap_od = p["tube_od"] + 2 * p["wall"]; H = p["face"] + p["socket_depth"]
    # build face-down (print orientation): outer face on z=0, socket opening at z=H
    s = cq.Workplane("XY").circle(cap_od / 2).extrude(H)
    s = s.cut(cq.Workplane("XY").workplane(offset=p["face"]).circle((p["tube_od"] + p["tube_clearance"]) / 2).extrude(p["socket_depth"]))
    s = s.cut(cq.Workplane("XY").circle(p["body_hole"] / 2).extrude(H))
    off = p["hole_pitch"] / 2
    s = s.cut(cq.Workplane("XY").pushPoints([(sx * off, sy * off) for sx in (-1, 1) for sy in (-1, 1)])
              .circle(p["pilot_dia"] / 2).extrude(p["pilot_depth"]))
    if p["face_wire"]:
        r, d = p["face_wire"]
        s = s.cut(cq.Workplane("XY").center(r, 0).circle(d / 2).extrude(H))
    return s


# ---------------- helical groove helper ----------------
def groove_solid(r_surface, groove_r, z0, turns, pitch):
    """Half-round groove: a circle of radius groove_r centered on the form surface, swept along a helix."""
    height = pitch * turns
    helix = cq.Wire.makeHelix(pitch=pitch, height=height, radius=r_surface, center=cq.Vector(0, 0, z0))
    # profile circle in the XZ plane at the helix start (angle 0 -> point (r_surface, 0, z0))
    profile = cq.Workplane("XZ", origin=(r_surface, 0, z0)).circle(groove_r)
    return profile.sweep(cq.Workplane().add(helix), isFrenet=True)


def radial_hole(d, od, wall, ang_rad, z):
    """Cylinder through the wall along the radial direction at angle ang (rad), height z."""
    h = cq.Workplane("YZ", origin=(od / 2 - wall - 1.5, 0, z)).circle(d / 2).extrude(wall + 3)
    return h.rotate((0, 0, 0), (0, 0, 1), math.degrees(ang_rad))


# ---------------- rev B forms (same table as make_form.py) ----------------
FORMS = {"BNC": 26.67, "SO239": 33.40}
WIRES = {"18AWG": dict(groove_r=0.60, pitch=1.40), "16AWG": dict(groove_r=0.75, pitch=1.70)}
FORM = dict(length=105.0, wall=2.5, socket=12.0, margin=2.0, entry_hole=2.2)


def coilform(od, w):
    p = {**FORM, **w}
    L = p["length"]
    s = cq.Workplane("XY").circle(od / 2).circle((od - 2 * p["wall"]) / 2).extrude(L)
    z0 = p["socket"] + p["margin"] + p["groove_r"]
    z1 = L - p["socket"] - p["margin"] - p["groove_r"]
    turns = math.floor((z1 - z0) / p["pitch"])
    s = s.cut(groove_solid(od / 2, p["groove_r"], z0, turns, p["pitch"]))
    a_end = 2 * math.pi * turns
    s = s.cut(radial_hole(p["entry_hole"], od, p["wall"], 0.0, z0))
    s = s.cut(radial_hole(p["entry_hole"], od, p["wall"], a_end, z0 + p["pitch"] * turns))
    return s, turns


# ---------------- rev C tuner (same table as make_tuner.py) ----------------
T = dict(od=33.40, wall=2.5, spigot=14.0, gap=7.0, coil_len=100.0, land=40.0,
         pitch=2.0, groove_r=0.60, wire_od=1.02, entry_hole=2.2,
         sleeve_wall=3.0, bore_clear=0.5, face=7.0, tail_pocket=12.0, station_z=10.0, n_stations=5,
         lip=1.0, lip_hole=3.4, chamber_d=4.4, chamber_len=4.0, tap_d=7.0, tap_len=10.0, boss_side=13.0,
         conn_hole=16.5, conn_pitch=18.24, pilot_d=2.6, pilot_depth=5.5, bus_hole=3.0)


def tuner_form():
    od = T["od"]; crest_od = od + 2 * (T["wire_od"] - T["groove_r"])
    z_coil0 = T["spigot"] + T["gap"]; L = z_coil0 + T["coil_len"] + T["land"]
    s = cq.Workplane("XY").circle(od / 2).extrude(z_coil0 + T["coil_len"])
    s = s.union(cq.Workplane("XY").workplane(offset=z_coil0 + T["coil_len"]).circle(crest_od / 2).extrude(T["land"]))
    s = s.cut(cq.Workplane("XY").circle((od - 2 * T["wall"]) / 2).extrude(L))
    z0 = z_coil0 + T["groove_r"] + 0.5
    turns = math.floor((T["coil_len"] - 2 * T["groove_r"] - 1.0) / T["pitch"])
    s = s.cut(groove_solid(od / 2, T["groove_r"], z0, turns, T["pitch"]))
    s = s.cut(radial_hole(T["entry_hole"], od, T["wall"], 0.0, z0))
    s = s.cut(radial_hole(T["entry_hole"], od, T["wall"], 2 * math.pi * turns, z0 + T["pitch"] * turns))
    return s, dict(length=L, crest_od=crest_od, turns=turns, z_first=z0)


def tuner_sleeve(fi):
    bore_d = fi["crest_od"] + T["bore_clear"]; sleeve_od = bore_d + 2 * T["sleeve_wall"]
    bore_depth = fi["length"] - T["station_z"] - 1.0 + T["tail_pocket"]; H = bore_depth + T["face"]
    r0 = bore_d / 2
    boss_len = T["lip"] + T["chamber_len"] + T["tap_len"]; r_out = r0 + boss_len
    inner = r0 + T["sleeve_wall"] - 2.5
    s = cq.Workplane("XY").circle(sleeve_od / 2).extrude(H)
    for k in range(T["n_stations"]):
        ang = 360.0 * k / T["n_stations"] + 180.0 / 160   # same half-facet offset as the STL
        z = T["station_z"] + T["pitch"] * k / T["n_stations"]
        boss = (cq.Workplane("YZ", origin=(inner, 0, z)).rect(T["boss_side"], T["boss_side"]).extrude(r_out - inner)
                .rotate((0, 0, z), (1, 0, z), 45))
        s = s.union(boss.rotate((0, 0, 0), (0, 0, 1), ang))
    # bore and connector features
    s = s.cut(cq.Workplane("XY").circle(bore_d / 2).extrude(bore_depth))
    s = s.cut(cq.Workplane("XY").circle(T["conn_hole"] / 2).extrude(H))
    off = T["conn_pitch"] / 2
    s = s.cut(cq.Workplane("XY").workplane(offset=H - T["pilot_depth"])
              .pushPoints([(sx * off, sy * off) for sx in (-1, 1) for sy in (-1, 1)]).circle(T["pilot_d"] / 2).extrude(T["pilot_depth"]))
    # station bores: lip / ball chamber / tapped bore (modeled at tap drill 7.0; thread .305-32 is cut after printing)
    for k in range(T["n_stations"]):
        ang = 360.0 * k / T["n_stations"] + 180.0 / 160
        z = T["station_z"] + T["pitch"] * k / T["n_stations"]
        lip = cq.Workplane("YZ", origin=(r0 - 1, 0, z)).circle(T["lip_hole"] / 2).extrude(T["lip"] + 1)
        ch = cq.Workplane("YZ", origin=(r0 + T["lip"], 0, z)).circle(T["chamber_d"] / 2).extrude(T["chamber_len"])
        tp = cq.Workplane("YZ", origin=(r0 + T["lip"] + T["chamber_len"], 0, z)).circle(T["tap_d"] / 2).extrude(T["tap_len"] + 2)
        for c in (lip, ch, tp):
            s = s.cut(c.rotate((0, 0, 0), (0, 0, 1), ang))
    # bus-wire hole into the tail pocket
    bw = cq.Workplane("YZ", origin=(r0 - 1, 0, bore_depth - T["tail_pocket"] / 2)).circle(T["bus_hole"] / 2).extrude(T["sleeve_wall"] + 2)
    s = s.cut(bw.rotate((0, 0, 0), (0, 0, 1), 36 + 180.0 / 160))
    return s, dict(height=H, od=sleeve_od)


# ---------------- guy collar (same as make_guy_collar.py) ----------------
def guy_collar(bore=12.7):
    H, OD, SLOT, EYE = 14.0, bore + 14.0, 1.5, 4.0
    s = cq.Workplane("XY").circle(OD / 2).extrude(H)
    for k in range(3):
        ear = cq.Workplane("XY").center(OD / 2 + 3, 0).rect(10, 8).extrude(H).rotate((0, 0, 0), (0, 0, 1), 120 * k + 60)
        s = s.union(ear)
    for sg in (1, -1):
        s = s.union(cq.Workplane("XY").center(OD / 2 + 2.5, sg * (SLOT / 2 + 2.5)).rect(9, 5).extrude(H))
    s = s.cut(cq.Workplane("XY").circle(bore / 2).extrude(H))
    s = s.cut(cq.Workplane("XY").center(OD / 2, 0).rect(OD, SLOT).extrude(H))
    s = s.cut(cq.Workplane("XZ", origin=(OD / 2 + 3.5, 10, H / 2)).circle(1.7).extrude(20))
    for k in range(3):
        s = s.cut(cq.Workplane("XY").center(OD / 2 + 5, 0).circle(EYE / 2).extrude(H).rotate((0, 0, 0), (0, 0, 1), 120 * k + 60))
    return s


def check(name, wp):
    sol = wp.val()
    assert sol.isValid(), f"{name}: invalid solid"
    bb = sol.BoundingBox()
    print(f"{name:26s} valid  bbox {bb.xlen:6.2f} x {bb.ylen:6.2f} x {bb.zlen:6.2f}  vol {sol.Volume()/1000:6.1f} cm3")
    return sol


if __name__ == "__main__":
    parts = {}
    for n, v in CAPS.items():
        parts[f"endcap_{n}"] = endcap(v)
    for fn, od in FORMS.items():
        for wn, w in WIRES.items():
            parts[f"coilform_{fn}_{wn}"], _ = coilform(od, w)
    tf, fi = tuner_form(); parts["tuner_form_SO239"] = tf
    ts, _ = tuner_sleeve(fi); parts["tuner_sleeve_SO239"] = ts
    parts["guy_collar_12.7mm"] = guy_collar()

    assembly = cq.Assembly(name="loading_coil_parts")
    x = 0.0
    for name, wp in parts.items():
        sol = check(name, wp)
        cq.exporters.export(wp, f"{OUT}/{name}.step")
        bb = sol.BoundingBox()
        assembly.add(wp, name=name, loc=cq.Location(cq.Vector(x - bb.xmin, 0, 0)))
        x += bb.xlen + 15
    assembly.save(f"{OUT}/loading_coil_all_parts.step")
    print("wrote", len(parts) + 1, "STEP files to", OUT)
