#!/usr/bin/env python3
"""
Rev C: screwdriver-style tunable coil (SO-239 base, SO-239 whip on sleeve).

Parts generated:
  tuner_form_SO239.stl   grooved form, 2.0 mm pitch, 100 mm coil, 40 mm bearing land on top
  tuner_sleeve_SO239.stl sleeve with 5 ball-plunger stations and SO-239 face on top

Base end cap is the existing endcap_SO239_x2.stl (print one).
Hardware per station (all tire-valve parts, .305-32 UNEF RH, ISO 4570 "8V1"):
  5/32" (3.97 mm) brass ball; phosphor bronze or BeCu spring, 4.0 mm OD x 0.55 wire x 25 mm free (in the RF path, not steel);
  brass Schrader tubeless valve stem cut to 14 mm (the spring housing); the stem's knurled lock nut
  (clamps the bus-wire ring terminal); a brass or nickel-plated metal valve cap (sets the preload).
The boss is printed with a 7.0 mm bore and tapped .305-32 (a "tire valve stem tap"; 5/16-32 UNEF
also works, slightly loose).
"""
import math, json, sys
import numpy as np
import trimesh
from trimesh.creation import cylinder, box, sweep_polygon
from trimesh.transformations import rotation_matrix as R, translation_matrix as T
from shapely.geometry import Point

SEG = 160
P = dict(
    # form
    od=33.40, wall=2.5, spigot=14.0, gap=7.0, coil_len=100.0, land=40.0,
    pitch=2.0, groove_r=0.60, wire_od=1.02,          # bare tinned 18 AWG
    entry_hole=2.2,
    # sleeve
    sleeve_wall=3.0, bore_clear=0.5, face=7.0, tail_pocket=12.0,
    station_z=10.0, n_stations=5,      # boss half-diagonal is 9.19, so bosses stay above the bed
    lip=1.0, lip_hole=3.4, ball=3.97, chamber_d=4.4, chamber_len=4.0,
    tap_d=7.0, tap_len=10.0, boss_side=13.0,          # 7.0 bore tapped .305-32; stem threads in 10 mm and bottoms on the chamber shoulder
    stem_len=18.0, spring_free=25.0, cap_depth=0.5,   # for the report only
    conn_hole=16.5, conn_pitch=18.24, pilot_d=2.6, pilot_depth=5.5,
    bus_hole=3.0,
)


def clean(m):
    """Remove zero-area slivers left by coincident cutter faces, then prove the mesh is a closed volume."""
    m.merge_vertices(); m.update_faces(m.nondegenerate_faces()); m.remove_unreferenced_vertices()
    assert m.is_watertight and m.is_volume and m.is_winding_consistent, "mesh invalid after clean"
    return m


def helix(r, z0, turns, pitch, per_turn=48):
    n = int(turns * per_turn) + 1
    t = np.linspace(0, turns, n); a = 2 * math.pi * t
    return np.c_[r * np.cos(a), r * np.sin(a), z0 + pitch * t], a[-1]


def cyl(d, h, z0=0):
    c = cylinder(radius=d / 2, height=h, sections=SEG); c.apply_translation([0, 0, z0 + h / 2]); return c


def make_form():
    od = P["od"]; crest_od = od + 2 * (P["wire_od"] - P["groove_r"])
    z_coil0 = P["spigot"] + P["gap"]
    L = z_coil0 + P["coil_len"] + P["land"]
    body = trimesh.boolean.union([cyl(od, z_coil0 + P["coil_len"] + 1), cyl(crest_od, P["land"], z0=z_coil0 + P["coil_len"])], engine="manifold")
    bore = cyl(od - 2 * P["wall"], L + 2, z0=-1)
    z0 = z_coil0 + P["groove_r"] + 0.5
    turns = math.floor((P["coil_len"] - 2 * P["groove_r"] - 1.0) / P["pitch"])
    path, a_end = helix(od / 2, z0, turns, P["pitch"])
    groove = sweep_polygon(Point(0, 0).buffer(P["groove_r"], resolution=6), path)
    cutters = [bore, groove]
    for ang, z in ((0.0, z0), (a_end, z0 + P["pitch"] * turns)):
        h = cylinder(radius=P["entry_hole"] / 2, height=P["wall"] + 4, sections=32)
        h.apply_transform(R(math.pi / 2, [0, 1, 0])); h.apply_translation([od / 2 - P["wall"] / 2, 0, 0])
        h.apply_transform(R(ang, [0, 0, 1])); h.apply_translation([0, 0, z])
        cutters.append(h)
    m = clean(trimesh.boolean.difference([body] + cutters, engine="manifold"))
    return m, dict(length=L, crest_od=round(crest_od, 2), turns=turns, z_first_turn=round(z0, 2),
                   z_last_turn=round(z0 + P["pitch"] * turns, 2), land_from=z_coil0 + P["coil_len"],
                   wire_m=round(turns * math.pi * (od + P["wire_od"]) / 1000 + 0.3, 2))


def make_sleeve(form_info):
    crest_od = form_info["crest_od"]
    bore_d = crest_od + P["bore_clear"]
    sleeve_od = bore_d + 2 * P["sleeve_wall"]
    bore_depth = form_info["length"] - P["station_z"] - 1.0 + P["tail_pocket"]   # covers form top + tail pocket when tapped at turn 1
    H = bore_depth + P["face"]
    r0 = bore_d / 2
    body = cyl(sleeve_od, H)

    # 5 diamond bosses, staggered along the helix (left/right hand must match form: angle increases with z)
    boss_len = P["lip"] + P["chamber_len"] + P["tap_len"]
    r_out = r0 + boss_len
    adds, cuts = [body], []
    for k in range(P["n_stations"]):
        ang = 2 * math.pi * k / P["n_stations"] + math.pi / SEG   # half a facet off, so boss edges never coincide with cylinder facet edges
        z = P["station_z"] + P["pitch"] * k / P["n_stations"]
        # diamond boss: square prism along +x, rotated 45 deg about x so a vertex points down (printable)
        b = box(extents=[r_out - (r0 + P["sleeve_wall"] - 2.5), P["boss_side"], P["boss_side"]])
        b.apply_transform(R(math.pi / 4, [1, 0, 0]))
        b.apply_translation([(r_out + r0 + P["sleeve_wall"] - 2.5) / 2, 0, 0])
        # station cutters along +x
        lip = cylinder(radius=P["lip_hole"] / 2, height=P["lip"] + 2, sections=40)   # section counts differ so coaxial cutter edges never coincide; lip.apply_transform(R(math.pi / 2, [0, 1, 0])); lip.apply_translation([r0 - 1 + (P["lip"] + 2) / 2, 0, 0])
        ch = cylinder(radius=P["chamber_d"] / 2, height=P["chamber_len"] + 0.01, sections=36); ch.apply_transform(R(math.pi / 2, [0, 1, 0])); ch.apply_translation([r0 + P["lip"] + P["chamber_len"] / 2, 0, 0])
        ins = cylinder(radius=P["tap_d"] / 2, height=P["tap_len"] + 2, sections=48); ins.apply_transform(R(math.pi / 2, [0, 1, 0])); ins.apply_translation([r0 + P["lip"] + P["chamber_len"] + (P["tap_len"] + 2) / 2, 0, 0])
        for part in (b,):
            part.apply_transform(R(ang, [0, 0, 1])); part.apply_translation([0, 0, z]); adds.append(part)
        for part in (lip, ch, ins):
            part.apply_transform(R(ang, [0, 0, 1])); part.apply_translation([0, 0, z]); cuts.append(part)

    shell = trimesh.boolean.union(adds, engine="manifold")
    # bore from the bottom
    cuts.append(cyl(bore_d, bore_depth + 0.01, z0=-0.01))
    # connector through-hole + pilots in the top face
    cuts.append(cyl(P["conn_hole"], P["face"] + 3, z0=bore_depth - 2))   # starts inside the bore void, no coincident faces
    for sx in (-1, 1):
        for sy in (-1, 1):
            c = cyl(P["pilot_d"], P["pilot_depth"] + 0.01, z0=H - P["pilot_depth"]); c.apply_translation([sx * P["conn_pitch"] / 2, sy * P["conn_pitch"] / 2, 0]); cuts.append(c)
    # bus-wire hole through the side wall into the tail pocket (between stations, angle 36 deg)
    bw = cylinder(radius=P["bus_hole"] / 2, height=P["sleeve_wall"] + 4, sections=24); bw.apply_transform(R(math.pi / 2, [0, 1, 0]))
    bw.apply_translation([r0 + P["sleeve_wall"] / 2, 0, 0]); bw.apply_transform(R(math.pi / 5 + math.pi / SEG, [0, 0, 1])); bw.apply_translation([0, 0, bore_depth - P["tail_pocket"] / 2]); cuts.append(bw)

    m = clean(trimesh.boolean.difference([shell] + cuts, engine="manifold"))
    assert m.bounds[0][2] >= -1e-6, "sleeve geometry extends below the print bed"
    ball_protrusion = P["ball"] / 2 - math.sqrt((P["ball"] / 2) ** 2 - (P["lip_hole"] / 2) ** 2)
    ball_top = P["lip"] - ball_protrusion + P["ball"]                       # radial, from the bore surface
    spring_compressed = P["lip"] + P["chamber_len"] + P["stem_len"] + P["cap_depth"] - ball_top
    return m, dict(height=round(H, 2), bore_d=round(bore_d, 2), bore_depth=round(bore_depth, 2),
                   sleeve_od=round(sleeve_od, 2), boss_tip_radius=round(r_out, 2),
                   ball_protrusion_into_bore=round(ball_protrusion, 2),
                   lip_limited_reach_below_crest=round(ball_protrusion - P["bore_clear"] / 2, 2),   # seated ball stops 0.2 below crest on the wires, well short of this
                   spring_compressed_len=round(spring_compressed, 2), spring_free_len=P["spring_free"],
                   spring_deflection=round(P["spring_free"] - spring_compressed, 2),
                   stem_exposed_mm=round(P["stem_len"] - P["tap_len"], 2),
                   stations=[dict(angle_deg=round(72 * k + 180 / SEG, 2), z=round(P["station_z"] + P["pitch"] * k / 5, 2)) for k in range(5)])


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    form, fi = make_form(); form.export(f"{out}/tuner_form_SO239.stl")
    sleeve, si = make_sleeve(fi)
    # print orientation: open end down, face up (bosses are diamonds, self-supporting)
    sleeve.export(f"{out}/tuner_sleeve_SO239.stl")
    fi["mass_g_PETG"] = round(form.volume / 1000 * 1.27, 1); si["mass_g_PETG"] = round(sleeve.volume / 1000 * 1.27, 1)
    cap_top = 12.0  # base cap socket height over the spigot
    si["sleeve_bottom_at_turn1"] = round(fi["z_first_turn"] - P["station_z"], 2)
    si["clears_base_cap"] = si["sleeve_bottom_at_turn1"] >= cap_top
    conn = 16.0; base = 7.0 + conn
    si["overall_turn1_mm"] = round(base + si["sleeve_bottom_at_turn1"] + si["height"] + conn, 1)
    si["overall_turn_last_mm"] = round(base + fi["z_last_turn"] - P["station_z"] + si["height"] + conn, 1)
    si["tail_pocket_at_turn1"] = round(si["sleeve_bottom_at_turn1"] + si["bore_depth"] - fi["length"], 2)
    for fn in ("tuner_form_SO239.stl", "tuner_sleeve_SO239.stl"):
        assert trimesh.load(f"{out}/{fn}").is_watertight, fn
    print(json.dumps(dict(form=fi, sleeve=si), indent=2))
