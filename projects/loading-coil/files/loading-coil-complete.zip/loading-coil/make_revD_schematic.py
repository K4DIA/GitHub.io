#!/usr/bin/env python3
"""revD_schematic.svg: tripod-hub tunable coil, assembly section, swivel detail, electrical."""
import json
d = json.load(open("revD/revD_dims.json")); fi, hi, P = d["form"], d["hub"], d["params"]
W, H = 1300, 1230
o = []; A = o.append
A(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" font-family="Helvetica, Arial, sans-serif" font-size="13">')
A('<rect width="100%" height="100%" fill="white"/>')
A('<text x="24" y="34" font-size="22" font-weight="bold">Tripod-Hub Tunable Loading Coil, 3/8-24 whip, swivel feed (rev D)</text>')
A('<text x="24" y="72" fill="#444">The coil form screws up into the hub from below; the feed swivels at the form bottom.</text>')
A('<text x="24" y="54" fill="#444">A one-piece printed hub, 98 mm across, carries three 1/2 in aluminum legs on brass inserts and the ground bolt. The housing drops in from above, hangs from its collar, and carries the whip and the balls.</text>')

S = 1.5; cx = 720; ytop = 200
def Y(z_hub): return ytop + (hi["height"] - z_hub) * S          # hub z=0 at the rim, increases upward
def X(r): return cx + r * S
def rect(r0, r1, z0, z1, fill, sw=1, stroke="#222"):
    A(f'<rect x="{min(X(r0),X(r1))}" y="{min(Y(z0),Y(z1))}" width="{abs(X(r1)-X(r0))}" height="{abs(Y(z1)-Y(z0))}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')

Hh = hi["height"]; rb = hi["bore_d"] / 2; ro = hi["od"] / 2
# hub walls, top plate, nut boss
for s in (1, -1): rect(s * rb, s * ro, 0, hi["interior"], "#8fa3b8")
t = P["tripod_print"]; zt = hi["z_hub_top"]; zb = hi["z_hub_bottom"]; zbody = zb + t["body_t"]
ti = d["tripod_print"]; Rb = t["body_dia"] / 2; ca = t["chamfer_a"]; ch = ti["chamfer_rise"]
for s_ in (1, -1):   # body with the bottom chamfer, as a section polygon each side of the bore
    pts = [(s_ * (hi["od"] / 2 + 0.15), zb), (s_ * (Rb - ca), zb), (s_ * Rb, zb + ch), (s_ * Rb, zbody), (s_ * (hi["od"] / 2 + 0.15), zbody)]
    A('<polygon points="' + " ".join(f"{X(x)},{Y(z)}" for x, z in pts) + '" fill="#c7cdd4" stroke="#222" stroke-width="1"/>')
rect(-t["boss_od"] / 2, t["boss_od"] / 2, zbody, zt, "#c7cdd4")                     # boss
rect(-hi["od"] / 2 - 0.15, hi["od"] / 2 + 0.15, zb - 1, zt + 1, "white", 0.6)       # through bore
for s_ in (1, -1): rect(s_ * rb, s_ * ro, hi["interior"], zt + P["collar_t"], "#8fa3b8")   # housing top block walls (section)
rect(-ro, ro, hi["interior"], Hh, "#8fa3b8")                                        # top block
rect(-P["collar_od"] / 2, P["collar_od"] / 2, zt, Hh, "#6d7a88")                   # collar on the boss
rect(-7.3, 7.3, hi["interior"], hi["interior"] + P["nut_len"], "#c9a84a", 0.8)      # coupling nut
rect(-4.9, 4.9, hi["interior"] + P["nut_len"], Hh - P["whip_bore_depth"], "white", 0.6)
rect(-(P["whip"]["base_od"] + 0.25) / 2, (P["whip"]["base_od"] + 0.25) / 2, Hh - P["whip_bore_depth"], Hh + 1, "white", 0.6)
rect(-8, 8, Hh - P["whip_bore_depth"], Hh + 30, "#555")                            # whip base
rect(-4.7, 4.7, Hh - P["whip_bore_depth"] - 16, Hh - P["whip_bore_depth"], "#999", 0.8)   # whip stud into the nut
# set screw through the boss, radial screw on top, angled leg hole
zss = Hh - P["setscrew_below_top"]
rect(t["boss_od"] / 2 - 1, t["boss_od"] / 2 + 8, zss - 3, zss + 3, "#8a8f96", 0.8)
A(f'<text x="{X(t["boss_od"]/2+11)}" y="{Y(zss)+4}" fill="#222">M5 nylon-tip set screw into the housing groove: stops rotation only;</text>')
A(f'<text x="{X(t["boss_od"]/2+11)}" y="{Y(zss)+20}" fill="#222">the collar carries the weight</text>')
rect(t["radial_r"] - 2.5, t["radial_r"] + 2.5, zbody - 14, zbody + 1, "white", 0.6)
A(f'<text x="{X(t["body_dia"]/2+6)}" y="{Y(zbody-12)}" fill="#222">1/4-20 insert on top: ground bolt for radials and the coax shield;</text>')
A(f'<text x="{X(t["body_dia"]/2+6)}" y="{Y(zbody-12)+16}" fill="#222">the housing wall insulates the whip from it.</text>')
import math as _m
la = _m.radians(t["leg_angle"]); x0 = -ti["seat_r"]; z0 = zb + ti["seat_z"]
A(f'<line x1="{X(x0)}" y1="{Y(z0)}" x2="{X(x0 + t["leg_depth"]*_m.sin(la))}" y2="{Y(z0 + t["leg_depth"]*_m.cos(la))}" stroke="#222" stroke-width="{t["leg_tap_drill"]*S}" stroke-opacity="0.25"/>')
A(f'<line x1="{X(x0)}" y1="{Y(z0)}" x2="{X(x0 - 180*_m.sin(la))}" y2="{Y(z0 - 180*_m.cos(la))}" stroke="#444" stroke-width="5"/>')
A(f'<text x="{X(-t["body_dia"]/2 + 10)}" y="{Y(zb - 215)}" text-anchor="end" fill="#222">3 x 3/8-16 brass inserts in the chamfer face, square to it, {t["leg_angle"]:.0f} deg out</text>')
A(f'<text x="{X(-t["body_dia"]/2 + 10)}" y="{Y(zb - 215)+16}" text-anchor="end" fill="#222">1/2 in aluminum tube legs, 3/8-16 stud epoxied in; printed feet with ballast pockets and stake ears</text>')
A(f'<text x="{X(t["boss_od"]/2+6)}" y="{Y(Hh+26)}" fill="#222">whip base captured 22 mm in the housing top, inside the hub boss</text>')
A(f'<text x="{X(t["boss_od"]/2+6)}" y="{Y(Hh+26)+16}" fill="#222">3/8-24 coupling nut below it, captive in the housing; bus wire to its inside bolt</text>')
# stations at the rim (section shows top and bottom)
zs = hi["z_stations"]
for s in (1, -1):
    rect(s * (ro - 0.5), s * (rb + 15), zs - 6.5, zs + 6.5, "#8fa3b8")
    rect(s * (rb + 5), s * (rb + 23), zs - 3.85, zs + 3.85, "#c9a84a", 0.8)
    rect(s * (rb + 15), s * (rb + 18.5), zs - 5.5, zs + 5.5, "#b08d3a", 0.8)
    rect(s * (rb + 19), s * (rb + 25), zs - 4.8, zs + 4.8, "#8a8f96", 0.8)
    A(f'<circle cx="{X(s*(rb-0.3+1.6))}" cy="{Y(zs)}" r="{1.98*S}" fill="#e3c25c" stroke="#333" stroke-width="0.8"/>')
A(f'<text x="{X(rb+27)}" y="{Y(zs)+4}" fill="#222">5 ball stations at the rim (.305-32 stems, PB/BeCu springs)</text>')
# copper lining above the stations
for s in (1, -1): rect(s * (rb - 0.4), s * rb, zs + 8, hi["interior"] - 2, "#c76b2a", 0.5)
A(f'<text x="{X(ro+6)}" y="{Y(hi["interior"]*0.55)}" fill="#7a3d12">copper tape lining inside the hub above the stations:</text>')
A(f'<text x="{X(ro+6)}" y="{Y(hi["interior"]*0.55)+16}" fill="#7a3d12">shorts the dead turns, bused to the inside bolt of the nut</text>')

# form at a mid tap (balls between turns 21 and 22: 40 m)
n_active = 21; dz = zs - (fi["z_first_turn"] + 2.0 * (n_active + 0.5))
def fz(z): return z + dz
rf = P["od"] / 2; rbore = rf - P["wall"]
for s in (1, -1):
    rect(s * rbore, s * rf, fz(fi["z_grip"][1]), fz(fi["z_land"]), "#bfc5cc")
    rect(s * rbore, s * fi["crest_od"] / 2, fz(fi["z_land"]), fz(fi["length"]), "#bfc5cc")
rect(-rbore, rbore, fz(fi["z_grip"][1]), fz(fi["z_grip"][1] + 3), "#bfc5cc")
rect(-P["grip_od"] / 2, P["grip_od"] / 2, fz(fi["z_grip"][0]), fz(fi["z_grip"][1]), "#9aa5b1")
rect(-P["journal_od"] / 2, P["journal_od"] / 2, fz(0), fz(fi["z_grip"][0]), "#bfc5cc")
rect(-P["journal_od"] / 2 - 0.3, P["journal_od"] / 2 + 0.3, fz(P["ring_band"][0]), fz(P["ring_band"][1]), "#d8a24a", 0.6)   # brass ring
# winding
z = fi["z_first_turn"]; k = 0
while k < P["turns"]:
    active = k < n_active
    for s in (1, -1):
        A(f'<circle cx="{X(s*(rf+0.42))}" cy="{Y(fz(z))}" r="{0.51*S}" fill="{"#c76b2a" if active else "white"}" stroke="#7a3d12" stroke-width="0.5"/>')
    z += 2.0; k += 1
# bottom wire channel to the ring
A(f'<path d="M {X(rf+0.9)} {Y(fz(fi["z_first_turn"]))} L {X(rf+0.9)} {Y(fz(fi["z_grip"][1]))} L {X(P["grip_od"]/2-3)} {Y(fz(fi["z_grip"][1]))} L {X(P["grip_od"]/2-3)} {Y(fz(fi["z_grip"][0]))} L {X(P["journal_od"]/2+0.5)} {Y(fz(P["ring_band"][1]))}" fill="none" stroke="#c76b2a" stroke-width="2"/>')
# swivel cap
cz = -17
rc = P["cap_bore"] / 2; rco = rc + P["cap_wall"]
for s in (1, -1): rect(s * rc, s * rco, fz(cz + P["cap_floor"]), fz(22), "#8fa3b8")
rect(-P["cap_face_od"] / 2, P["cap_face_od"] / 2, fz(cz), fz(cz + P["cap_floor"]), "#8fa3b8")
rect(-8.25, 8.25, fz(cz - 0.5), fz(cz + P["cap_floor"]), "white")
rect(-12.7, 12.7, fz(cz - 3), fz(cz), "#c9a84a"); rect(-7.95, 7.95, fz(cz - 16), fz(cz - 3), "#d8c27a")
A(f'<line x1="{X(0)}" y1="{Y(fz(cz-16))}" x2="{X(0)}" y2="{Y(fz(cz+P["cap_floor"]+6))}" stroke="#333" stroke-width="3"/>')
zst = 22 - d["swivel"]["z_stations_from_rim"]
for s in (1, -1):
    rect(s * (rco - 0.5), s * (rc + 15), fz(zst - 6.5), fz(zst + 6.5), "#8fa3b8")
    rect(s * (rc + 5), s * (rc + 23), fz(zst - 3.85), fz(zst + 3.85), "#c9a84a", 0.8)
    rect(s * (rc + 19), s * (rc + 25), fz(zst - 4.8), fz(zst + 4.8), "#8a8f96", 0.8)
    A(f'<circle cx="{X(s*(rc-0.3+1.6))}" cy="{Y(fz(zst))}" r="{1.98*S}" fill="#e3c25c" stroke="#333" stroke-width="0.8"/>')
A(f'<text x="{X(rc+27)}" y="{Y(fz(zst))+4}" fill="#222">2 ball stations on the brass ring: the swivel joint.</text>')
A(f'<text x="{X(rc+27)}" y="{Y(fz(zst))+20}" fill="#222">Two M3 screw tips in the journal groove retain the cap.</text>')
A(f'<text x="{X(rc+27)}" y="{Y(fz(zst))+36}" fill="#222">SO-239 on the cap floor, tail bused to the two stems through the side hole.</text>')
A(f'<text x="{X(rc+27)}" y="{Y(fz(zst))+52}" fill="#222">The coax hangs still while the form turns.</text>')
A(f'<text x="{X(P["grip_od"]/2+4)}" y="{Y(fz(29))+4}" fill="#222">fluted grip: twist here, 1 turn per revolution, up = fewer active turns = higher band</text>')
A(f'<text x="{X(ro+6)}" y="{Y(fz(fi["z_land"]+15))+4}" fill="#222">bearing land, 30 mm, rides the housing bore</text>')

# dimensions
def vdim(x, z0, z1, text, anchor="start"):
    A(f'<line x1="{x}" y1="{Y(z0)}" x2="{x}" y2="{Y(z1)}" stroke="#1a4fa0"/>')
    for zz in (z0, z1): A(f'<line x1="{x-5}" y1="{Y(zz)}" x2="{x+5}" y2="{Y(zz)}" stroke="#1a4fa0"/>')
    A(f'<text x="{x+(8 if anchor=="start" else -8)}" y="{(Y(z0)+Y(z1))/2+4}" fill="#1a4fa0" text-anchor="{anchor}">{text}</text>')
vdim(X(-ro - 230), 0, Hh, f"housing {Hh:.0f} mm, OD {hi['od']:.1f}; printed hub {hi['z_hub_bottom']:.0f} to {hi['z_hub_top']:.0f}", "end")
vdim(X(-ro - 175), fz(0), fz(fi["length"]), f"form {fi['length']:.0f} mm (journal 22, grip 15, coil {fi['coil_len']:.0f}, land 30)", "end")
vdim(X(-ro - 10), fz(cz - 16), fz(22), "swivel cap 39 + SO-239", "end")
A(f'<text x="24" y="{Y(-160)}" fill="#1a4fa0">Shown at 21 active turns (40 m with a 17 ft whip). Travel: form fully in, 1 turn active, grip 2 mm under the rim; fully out, 80 turns, 197 mm of form below the rim.</text>')
A(f'<text x="24" y="{Y(-160)+18}" fill="#1a4fa0">Below the hub body: 209 mm of housing, then up to 197 mm of form, swivel cap and connector. 1/2 in legs of 750 mm at 40 deg give 575 mm of height.</text>')

# electrical
ey = 1110
A(f'<text x="24" y="{ey-50}" font-size="18" font-weight="bold">Electrical</text>')
x = 230
A(f'<text x="{x-6}" y="{ey+5}" text-anchor="end">Coax (radials at the mount)</text>')
A(f'<line x1="{x}" y1="{ey}" x2="{x+40}" y2="{ey}" stroke="#222" stroke-width="2.5"/>'); x += 40
A(f'<circle cx="{x}" cy="{ey}" r="5" fill="white" stroke="#222" stroke-width="2"/>'); A(f'<text x="{x}" y="{ey+26}" text-anchor="middle" font-size="11" fill="#555">SO-239</text>'); x += 5
A(f'<line x1="{x}" y1="{ey}" x2="{x+30}" y2="{ey}" stroke="#222" stroke-width="2.5"/>'); x += 30
A(f'<rect x="{x}" y="{ey-8}" width="40" height="16" fill="#eee" stroke="#222"/>'); A(f'<text x="{x+20}" y="{ey+42}" text-anchor="middle" font-size="11" fill="#555">swivel: 2 balls on the brass ring</text>'); x += 40
A(f'<line x1="{x}" y1="{ey}" x2="{x+30}" y2="{ey}" stroke="#222" stroke-width="2.5"/>'); x += 30
ix = x; nt = 16; tap = 7
A(f'<path d="M {ix} {ey} ' + "a 9 9 0 0 1 18 0 " * nt + '" fill="none" stroke="#222" stroke-width="2.5"/>')
A(f'<text x="{ix+18*tap/2}" y="{ey+26}" text-anchor="middle" font-size="11" fill="#555">active, below the hub</text>')
A(f'<text x="{ix+18*(tap+(nt-tap)/2)}" y="{ey+42}" text-anchor="middle" font-size="11" fill="#555">dead, inside the hub, shorted by the lining</text>')
tx = ix + 18 * tap
A(f'<polygon points="{tx-5},{ey-16} {tx+5},{ey-16} {tx},{ey-6}" fill="#222"/>')
A(f'<path d="M {tx} {ey-16} L {tx} {ey-44} L {ix+18*nt+60} {ey-44} L {ix+18*nt+60} {ey}" fill="none" stroke="#222" stroke-width="2.5"/>')
A(f'<text x="{tx}" y="{ey-52}" text-anchor="middle" font-size="12">5 balls at the hub rim, bus wire</text>')
x = ix + 18 * nt + 60
A(f'<line x1="{x}" y1="{ey}" x2="{x+30}" y2="{ey}" stroke="#222" stroke-width="2.5"/>'); x += 30
A(f'<rect x="{x}" y="{ey-8}" width="40" height="16" fill="#eee" stroke="#222"/>'); A(f'<text x="{x+20}" y="{ey+26}" text-anchor="middle" font-size="11" fill="#555">3/8-24 nut</text>'); x += 40
A(f'<line x1="{x}" y1="{ey}" x2="{x+40}" y2="{ey}" stroke="#222" stroke-width="2.5"/>')
A(f'<text x="{x+46}" y="{ey+5}">17 ft whip</text>')
A(f'<text x="24" y="{ey+60}" fill="#333">&#8226; Nothing slides electrically except balls on copper: five at the tap, two at the swivel. Coax shield and radials meet on one bolt in the hub top; the hub and legs carry no current.</text>')
A(f'<text x="24" y="{ey+80}" fill="#333">&#8226; 17 ft whip: 80 m 76 turns, 60 m 37, 40 m 21, 30 m 10, 20 m whip alone (form fully in). 17 to 10 m: collapse the whip to a quarter wave.</text>')
A('</svg>')
open("revD/revD_schematic.svg", "w").write("\n".join(o))
