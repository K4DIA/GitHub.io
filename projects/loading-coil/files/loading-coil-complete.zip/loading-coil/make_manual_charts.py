#!/usr/bin/env python3
import math, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.alpha": 0.25})
C = {"40 m": "#1f5fa8", "20 m": "#c76b2a", "15 m": "#3a8f4a"}

def L_req(f, h, a=0.005):
    lam = 299.79 / f; bh = 2 * math.pi * h / lam
    if bh >= math.pi / 2: return 0.0
    return 60 * (math.log(2 * h / a) - 1) / math.tan(bh) / (2 * math.pi * f * 1e6) * 1e6
def L_revC(n): d = 1.36; l = n * 2.0 / 25.4; return d * d * n * n / (18 * d + 40 * l)
bands = {"40 m": 7.15, "20 m": 14.2, "15 m": 21.2}
h = np.linspace(1.0, 3.5, 200)

# ---- chart 1: required inductance vs whip length ----
fig, ax = plt.subplots(figsize=(7.2, 4.2))
ax.axhspan(0, L_revC(48), color="#e8eef5", label="rev C alone (0 to 24 uH)")
ax.axhspan(L_revC(48), L_revC(48) + 25, color="#f6ecd9", label="rev C + fixed rev B 25 uH (24 to 49 uH)")
for b, f in bands.items():
    ax.plot(h, [L_req(f, x) for x in h], color=C[b], lw=2, label=f"{b} ({f} MHz)")
ax.set_xlabel("whip length above the coil (m)"); ax.set_ylabel("base-loading inductance required (uH)")
ax.set_ylim(0, 50); ax.set_xlim(1.0, 3.5); ax.legend(loc="upper right", frameon=False)
ax.set_title("Inductance needed to resonate a short whip, coil at the base")
fig.tight_layout(); fig.savefig("chart_inductance.png", dpi=160)

# ---- chart 2: rev C turns vs whip length ----
fig, ax = plt.subplots(figsize=(7.2, 4.2))
def turns(L):
    for n in range(1, 49):
        if L_revC(n) >= L: return n
    return np.nan
for b, f in bands.items():
    ax.plot(h, [turns(L_req(f, x)) for x in h], color=C[b], lw=2, label=f"{b}, rev C alone")
f = bands["40 m"]
ax.plot(h, [turns(max(L_req(f, x) - 25.0, 0.3)) for x in h], color=C["40 m"], lw=2, ls="--", label="40 m, rev C over a fixed 25 uH rev B")
ax.axhline(48, color="#888", lw=1, ls=":"); ax.text(1.02, 46, "rev C full (48 turns)", color="#666", fontsize=9)
ax.set_xlabel("whip length above the coil (m)"); ax.set_ylabel("active turns on rev C (count below the sleeve)")
ax.set_ylim(0, 52); ax.set_xlim(1.0, 3.5); ax.legend(loc="center right", frameon=False)
ax.set_title("Starting point for the sleeve, then trim with the whip")
fig.tight_layout(); fig.savefig("chart_turns.png", dpi=160)

# ---- chart 3: bending moment at the coil base vs wind, with limits ----
fig, ax = plt.subplots(figsize=(7.2, 4.2))
v = np.linspace(0, 60, 200); rho = 1.225
for hw, ls in ((1.5, "-"), (2.5, "--"), (3.5, ":")):
    q = 0.5 * rho * (v * 0.447) ** 2
    M = q * 1.2 * hw * 0.008 * (hw / 2 + 0.30) + q * 1.2 * 0.30 * 0.045 * 0.15
    ax.plot(v, M, color="#333", lw=2, ls=ls, label=f"{hw} m whip, unguyed")
ax.axhline(3.0, color="#b23a3a", lw=1.5); ax.text(1, 3.3, "UHF connector joints, working limit 3 N m", color="#b23a3a", fontsize=9)
ax.axhline(12.9, color="#c76b2a", lw=1.5); ax.text(1, 13.3, "printed form at the groove, working limit 12.9 N m (SF 3)", color="#c76b2a", fontsize=9)
ax.set_xlabel("steady wind (mph)"); ax.set_ylabel("bending moment at the coil base (N m)")
ax.set_ylim(0, 20); ax.set_xlim(0, 60); ax.legend(loc="upper left", frameon=False)
ax.set_title("Unguyed wind load vs what the stack can take")
fig.tight_layout(); fig.savefig("chart_wind.png", dpi=160)
print("ok")
