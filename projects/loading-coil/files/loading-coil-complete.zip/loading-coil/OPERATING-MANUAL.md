---
title: "Tunable Whip Loading Coil, Operating and Deployment Manual"
subtitle: "Rev C tunable unit with rev B fixed units, 40 to 15 m on a short whip. Rev D tripod-hub unit, 80 to 30 m on a 17 ft whip. Portable and fixed-station use."
date: "November 2026"
---

# 1. What this is and what it is not

A base-loading coil that sits between the antenna mount and a telescoping whip, electrically lengthening the whip so a 1 to 3.5 m radiator resonates on 40, 20, or 15 m. The rev C unit tunes by twisting a sleeve (one turn of coil per revolution). Fixed rev B units stack underneath when more inductance is needed. Build details, print settings and the bill of materials are in README.md; this manual covers use.

It is a portable and fixed-station antenna component. It is not a mobile antenna for a moving vehicle: the UHF connector joints and printed form are not rated for highway wind or road shock, see Section 5.

All numbers below are calculated, not measured. Expect the real coil to land within about 15% of the predicted inductance. That is why the whip telescopes.

# 2. Which band, which whip, how many turns

## 2.1 The physics in one paragraph

A whip shorter than a quarter wave looks capacitive at the feedpoint. The coil cancels that capacitance. The shorter the whip relative to the wavelength, the more inductance it takes, and the less of the input power is radiated versus burned in the coil and the ground connection. On 15 m a 2.5 m whip is already 70% of a quarter wave and needs almost nothing. On 40 m the same whip is 15% of a quarter wave and needs about 20 uH, which is most of what rev C has.

## 2.2 Inductance required (base loading, 5 mm average whip radius)

![](chart_inductance.png)

| Whip above coil | 40 m (7.15 MHz) | 20 m (14.2 MHz) | 15 m (21.2 MHz) |
|---|---|---|---|
| 1.2 m | 38 uH | 9.3 uH | 3.9 uH |
| 1.5 m | 32 uH | 7.6 uH | 3.1 uH |
| 2.0 m | 25 uH | 5.6 uH | 2.1 uH |
| 2.5 m | 20 uH | 4.3 uH | 1.3 uH |
| 3.0 m | 17 uH | 3.3 uH | 0.7 uH |
| 3.5 m | 14 uH | 2.5 uH | none, whip is a quarter wave |

Rev C alone: 0 to 24 uH (48 turns). Rev B fixed, SO-239 form, 16 AWG full groove: 25 uH. Rev B fixed, 18 AWG full groove: 38 uH. A 38 uH rev B alone also covers 40 m with a 1.2 m whip; the tables below use the 25 uH unit.

## 2.3 Rev C sleeve setting, starting point

![](chart_turns.png)

Count the turns exposed below the sleeve.

| Whip | 40 m | 20 m | 15 m |
|---|---|---|---|
| 1.2 m | rev C over rev B 25 uH: 29 turns | 22 turns | 12 turns |
| 1.5 m | rev C over rev B 25 uH: 17 turns | 19 turns | 10 turns |
| 2.0 m | rev C alone, full (marginal), or rev C over rev B 25 uH: 3 turns | 15 turns | 8 turns |
| 2.5 m | rev C alone: 41 turns | 13 turns | 6 turns |
| 3.0 m | rev C alone: 36 turns | 10 turns | 4 turns |
| 3.5 m | rev C alone: 31 turns | 9 turns | 1 to 2 turns |

Procedure: set the sleeve to the table value, extend the whip fully, check SWR with an analyzer or the rig's meter at low power. Resonance too low: collapse the whip a section, or back the sleeve off two turns. Too high: the other way. One turn of rev C is worth about 0.5 uH near the bottom of the coil and 0.6 uH near the top, so the sleeve is the coarse control and the whip is the fine control. Record the turn count and whip sections per band on the sleeve with a paint pen.

## 2.4 What to expect for efficiency

Radiation resistance of a short whip against coil and ground loss, with a modest radial field (about 15 ohms ground loss) and a coil Q around 150:

| Whip 2.5 m | R radiation | R coil | R ground | Efficiency | vs. a lossless quarter wave |
|---|---|---|---|---|---|
| 40 m | 1.4 ohm | 6 ohm | 15 ohm | about 6% | about -12 dB |
| 20 m | 5.5 ohm | 2.6 ohm | 15 ohm | about 24% | about -6 dB |
| 15 m | 12 ohm | 1.2 ohm | 15 ohm | about 43% | about -4 dB |

The ground connection dominates. Four to eight radials of 3 to 5 m on the ground, or a counterpoise clipped to the mount, is worth more than anything you can do to the coil. On 40 m with a 1.5 m whip, efficiency drops to roughly 2%; it works, but plan on CW or digital.

Feedpoint impedance with the coil tuned will sit around 20 to 30 ohms on 40 m (SWR about 2:1 without a matching network), closer to 50 on 15 m. A short piece of coax and the rig's internal tuner handles it.

## 2.5 Voltage and power

At 100 W on 40 m, the RF current through the coil is about 2 A and the voltage across it is in the order of 2 kV RMS. The whip tip is higher. Nothing in the coil is stressed by this (turn to turn is about 50 V), but:

- Do not touch the whip, sleeve connector, or bus wire while transmitting. RF burns.
- Keep the whip tip clear of people and anything grounded.
- 100 W SSB and CW are fine with PETG. For FT8 or RTTY at 100 W, print in ASA or polycarbonate or hold power to 50 W. The hot spot is the solder joint at the base connector tail, not the winding.

## 2.6 Tuning behavior: what is coarse and what is fine

The sleeve is a band selector; the whip is the frequency dial. The balls seat between two adjacent turns, so the tap moves in whole-turn steps and there is no stable position in between. One turn is about 0.5 uH, and what that does to resonance depends on how much inductance the band needs:

| Band, 2.5 m whip | Turns | One turn moves resonance by | Whip movement that does the same | Whip sensitivity |
|---|---|---|---|---|
| 40 m | 41 | 94 kHz (1.3%) | 7.5 cm | 13 kHz per cm |
| 30 m | 22 | 250 kHz (2.5%) | 13 cm | 19 kHz per cm |
| 20 m | 12 | 625 kHz (4.4%) | 21 cm | 30 kHz per cm |
| 17 m | 8 | 1.05 MHz (5.9%) | 25 cm | 43 kHz per cm |
| 15 m | 5 | 1.6 MHz (7.4%) | 26 cm | 63 kHz per cm |

On 40 m a turn is a third of the band, so the sleeve alone gets within reach of any frequency and the whip finishes. On 20 m and above a single turn is wider than the band: set the turns from the table in 2.3, then do all the tuning with the whip. A 2:1 SWR window on a loaded whip is roughly 60 kHz wide on 40 m and 300 kHz on 20 m, which puts the whip within about 2 cm of correct on 40 m and 5 cm on 20 m. Telescoping sections hold that.

What keeps it from being finicky is not fine resolution; it is that nothing drifts. The five balls sit in a detent, so wind, vibration and handling do not move the tap. Five contacts at 5 N each on bare tinned wire give a contact resistance in the milliohm range that does not wander the way a single sprung finger on enamel scrapings does. The dead turns above the tap are shorted by the copper lining, so they cannot resonate on their own and put a jump in the SWR between settings. Set turns, extend the whip, read the SWR once, trim, done; the setting repeats by count next time.

# 3. Stacking units

- Units are female both ends. Use a PL-259 double-male barrel between units.
- Put fixed rev B units at the bottom, rev C on top, whip on rev C. The tunable element should be the one nearest the radiator so the sleeve is reachable.
- Each barrel joint is a hinge for bending loads. Two units unguyed is the practical limit. Three units: guy, always.
- The coil stack itself radiates very little; treat radiator length as the whip length only when using the tables.

# 4. Loads: what the top of this can carry

## 4.1 Weakest link

The chain from mount to whip tip, with working limits (ultimate divided by a safety factor of 3) in bending:

| Element | Working moment | Notes |
|---|---|---|
| UHF connector joints (SO-239 in printed cap, PL-259 barrels, 3/8-24 adapter on the whip) | about 3 N m | Governing. Four #4 screws into PETG and a thin brass coupling nut. |
| Form spigot in base cap, glued | about 12 N m | 14 mm engagement, CA or epoxy. Unglued, treat as 3 N m. |
| Printed form at the groove (PETG, layer lines across the load) | 12.9 N m | 1.9 mm wall under the groove. Ultimate about 39 N m. |
| Sleeve on the bearing land | over 25 N m | Not limiting. |

So: design to 3 N m at the coil base for anything unguyed. That is the number the rest of this section is built on.

## 4.2 Static top load

Vertical, plumb: compression is not a limit; the form takes over 1 kN. The limit is bending from lean or from the whip not being straight. With a 2.5 m whip (center of mass about 1.55 m above the coil base) and a 3 N m working limit:

| Lean off plumb | Maximum top mass (whip plus anything on it) |
|---|---|
| 3 degrees | 3.7 kg |
| 5 degrees | 2.2 kg |
| 10 degrees | 1.1 kg |

Keep whip plus accessories under 0.5 kg unguyed, under 1 kg guyed. Typical 2.5 m telescoping whips weigh 150 to 400 g. Do not hang a capacity hat heavier than 100 g on the whip tip without guying.

## 4.3 Wind

![](chart_wind.png)

Steady wind only, no gust factor, whip 8 mm average diameter, coil stack 300 mm long and 45 mm across (rev C alone is 220 to 316 mm):

| Steady wind | 1.5 m whip | 2.5 m whip | 3.5 m whip |
|---|---|---|---|
| 20 mph | 0.9 N m | 1.9 N m | 3.4 N m |
| 30 mph | 1.9 N m | 4.4 N m | 7.6 N m |
| 40 mph | 3.4 N m | 7.8 N m | 13.5 N m |
| 50 mph | 5.4 N m | 12.1 N m | 21 N m |

Against the 3 N m working limit:

- 1.5 m whip: unguyed to about 35 mph steady, call it 25 mph with gusts.
- 2.5 m whip: unguyed to about 25 mph steady, call it 15 mph with gusts.
- 3.5 m whip: unguyed to about 18 mph steady. Guy it whenever it is up.
- Any whip, any coil: not on a moving vehicle. At 60 mph a 1.5 m whip alone puts 8 N m on the connectors, and road shock multiplies that.

## 4.4 Guying

Where: at the base of the whip, directly above the rev C sleeve connector. One set of three guys there removes every bit of whip wind load from the coil stack and the connectors, and the telescoping whip above the collar is self-supporting to 3.5 m in any wind you would operate in. Do not guy from the sleeve (it rotates for tuning) and do not guy from a connector body.

How:

- Printed collar `guy_collar_12.7mm.stl` clamps on the whip base. Measure your whip base diameter and regenerate with `python3 make_guy_collar.py <mm>` if it is not 1/2 inch. Collar is non-conductive; it sits on the radiator and must not have a metal loop around it.
- Three guys at 120 degrees, 2 to 3 mm Dacron or similar non-conductive, non-stretch line. Nylon paracord stretches and lets the whip walk in gusts. No wire, no metal fittings on the collar end.
- Anchor at 45 degrees from the mast (anchor radius equal to collar height above ground). Steeper than 60 degrees does little; flatter than 30 degrees pulls the mast down harder than it holds it up.
- Tension by hand only, equal on all three, enough to take the slack out. Over-tensioning a guy set on a 12 mm whip base bends the whip.
- Trip hazard: flag the guys.

If the mount itself is a spike, tripod, or clamp on a railing, guy the mast top as well. The coil stack should never be the structural member holding up anything but the whip.

Tuning with guys: set the sleeve first, then attach guys, then fine-tune with the whip sections (the collar is on the fixed base section, so extending the upper sections does not disturb it). Re-check SWR after guying; the lines and anchors change the surroundings slightly.

# 5. Operating limits, one page

| Item | Limit |
|---|---|
| Bands | 40 m, 20 m, 15 m with whips 1.2 to 3.5 m; 17, 12, 10 m fall out of the 15 m settings with fewer turns. 80 m: not with this coil. |
| Power | 100 W SSB/CW. 50 W continuous duty (digital) in PETG; 100 W in ASA or PC. |
| Top mass | 0.5 kg unguyed, 1 kg guyed. |
| Wind, unguyed | 25 mph steady with a 1.5 m whip, 15 mph with a 2.5 m whip. Guy above that or for any extended deployment. |
| Vehicle | Stationary only. |
| Stacking | Two units unguyed, three with guys. Rev C always on top. |
| Temperature | PETG softens at 75 to 80 C. Do not leave in a closed car in summer. |
| Tuning | Twist the sleeve, never shove it. One revolution = one turn. Sleeve for band, whip for frequency. |
| Springs | Phosphor bronze or beryllium copper only. Stainless at 50 W or less. Never steel music wire; it heats at RF. |
| Maintenance | If SWR becomes erratic, unscrew one valve cap, tip out spring and ball, wipe them and the wire crests with isopropyl, reassemble to bottom. Stems, springs, balls and caps are tire-valve parts (.305-32); carry spares. Check that the base cap glue joint has no play. |

# 6. Rev D: tripod-hub unit with a 17 ft whip

Rev D keeps the same coil, ball contacts and electrical idea as rev C and changes what moves. A one-piece printed hub carries three screw-in aluminum tripod legs and the ground bolt where the radials and the coax shield meet. The printed housing drops into the hub from above and hangs from its collar; it carries the whip at the top and the five balls at the bottom. Each leg ends in a printed foot with a ballast pocket and a stake ear. The coil form screws up into the housing from below; you turn it by the fluted grip between the legs. The feed is an SO-239 on a swivel cap at the bottom of the form, so the coax never twists. Nothing loaded moves when you tune.

## 6.1 Bands and settings, Chameleon CHA SS17 (17 ft, 5.18 m) fully extended

| Band | Active turns below the rim | One turn moves resonance | Whip sensitivity | Efficiency, 15 ohm ground |
|---|---|---|---|---|
| 80 m | 76 | 25 kHz | 3 kHz per cm | 7% |
| 60 m | 37 | 73 kHz | 5 kHz per cm | 15% |
| 40 m | 21 | 163 kHz | 7 kHz per cm | 25% |
| 30 m | 10 | 380 kHz | 13 kHz per cm | 43% |
| 20 m | 1, form fully in | | | 61% |
| 17, 15, 12, 10 m | 1, form fully in | collapse the whip to 4.14, 3.54, 3.01, 2.64 m | | |

On 80 m one turn is a tenth of the band, so the form alone lands in-band and the whip trims. On 40 m and above, set the turns from the table and tune with the whip. 20 m is the whip alone as a quarter wave.

Procedure: form fully in (one turn showing), whip fully extended. Unscrew the form down until the right number of turns shows below the rim; one revolution is one turn. Check SWR at low power. Too low: collapse a whip section or screw the form up a turn. Too high: the other way. Hold the swivel cap with your free hand while turning so it does not drag the coax.

## 6.2 Loads

- Whip bending goes from the whip base into a 22 mm bore in the housing top, which sits inside 65 mm of hub bore, not through the stud. The hub is plastic and flexes a little; the whip sways more in gusts than it would on metal, and nothing is near breaking. The limit is the whip's own base section, 45 N m for a 16 mm tube, 80 N m solid. A 17 ft whip fully extended puts 8 N m on the base at 20 mph and 18 N m at 30 mph.
- Tripod stability governs before the whip does. With 750 mm legs at 40 deg (520 mm foot radius) and about 1.7 kg of hardware, the free-standing tripod tips at about 13 mph. Ballast in the feet raises that a few miles an hour; stakes through the foot ears take it to the whip's own limit. Nothing on the tripod needs touching to tune.
- Above 30 mph collapse the top whip sections; 60 m and 80 m still work with a shorter whip at more turns.
- The printed parts carry only the form's own weight and the coax. The whip itself weighs 0.9 lb; its weight is not a factor, wind is.

| Ballast per foot | Tips at | What |
|---|---|---|
| 0 g | 12.9 mph | no ballast |
| 135 g | 14.4 mph | 1-1/4 in fender washers filling the pocket |
| 127 g | 14.3 mph | 150 mm lead slug in each tube |
| 299 g | 16.0 mph | lead cast or stacked in the pocket |
| 426 g | 17.1 mph | pocket and tube both |

A tripod tips about the line between two feet, so the hardware's weight works on half the foot radius and only the upwind foot's ballast counts. That is why ballast is worth less than it feels and a stake is worth more.

## 6.3 Setting up

1. Screw the three 1/2 in legs, feet already pinned on, into the hub (750 mm legs at 40 deg give 575 mm of height; the connector hangs about 460 mm below the hub on 80 m). Drop the housing in from the top; set screw a quarter turn past touching.
2. Whip base into the housing top, stud tight. Screw the form up into the housing until one turn shows.
3. Coax to the SO-239 under the swivel cap. Shield wire from the swivel cap and the radials together under the ground bolt on the hub top; radials spread on the ground.
4. Stake the feet through the ears above about 12 mph, or whenever you walk away from it. Tune.

## 6.4 Limits, rev D

| Item | Limit |
|---|---|
| Bands | 80 to 30 m with the coil, 20 to 10 m with the whip alone. |
| Power | 100 W SSB/CW, 50 W continuous duty in PETG, same as rev C. |
| Wind, fully extended whip | 13 mph free-standing, 17 mph with full ballast; 25 mph with staked feet; collapse above that. |
| Springs | Phosphor bronze or BeCu only, seven of them. |
| Tuning | Twist the grip. One revolution is one turn. Hold the swivel cap. |

# 7. Assumptions behind the numbers

- Loading inductance: X = Z0 cot(bh), Z0 = 60[ln(2h/a) - 1], a = 5 mm average whip radius (6 mm for the 17 ft whip). Standard short-monopole approximation; ignores coil self-capacitance and the coil's own small contribution to radiator length. Expect to be within 15%.
- Coil inductance: Wheeler single-layer formula, coil diameter 34.5 mm, pitch 2.0 mm. Rev D coil 80 turns, 42.8 uH full.
- Radiation resistance: 10 (bh)^2 ohms over a ground plane. Coil Q 150 (bare wire, spaced, on PETG). Ground loss 15 ohms, a reasonable number for 4 to 8 radials on average soil.
- Structure: PETG flexural strength across layers taken as 30 MPa, working stress 10 MPa. Section modulus of the form at the groove 1294 mm^3. UHF connector working moment 3 N m estimated from #4 screw pull-out in PETG; treat as approximate and conservative.
- Wind: F = 0.5 rho v^2 Cd A, rho 1.225 kg/m^3, Cd 1.2 for a cylinder, no gust factor. For a site with real gusts, multiply by 1.5 to 2 before comparing with the limits. 17 ft whip taken as 10 mm average diameter.
- Rev D hub: printed PA12 or PETG; whip base bearing on the PETG bore 14 MPa at 30 mph against about 50 allowable, backed by 65 mm of hub bore at under 5 MPa. Tripod tip-over: hardware 1.7 kg (printed parts, tube legs, feet, whip, hardware) on a 0.52 m foot radius, tipping line through two feet, wind on the whip, hub, housing and form at their centroids. `make_tipover.py` in `revD/` does the arithmetic.
