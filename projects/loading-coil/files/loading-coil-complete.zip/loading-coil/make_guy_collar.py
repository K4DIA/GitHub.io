#!/usr/bin/env python3
"""Split guy collar that clamps on the whip base just above the sleeve connector.
Default bore 12.7 mm (1/2 in). MEASURE YOUR WHIP BASE and change BORE before printing."""
import math, sys, trimesh
from trimesh.creation import cylinder, box
from trimesh.transformations import rotation_matrix as R
BORE = float(sys.argv[1]) if len(sys.argv) > 1 else 12.7
H, OD, SLOT, EYE = 14.0, BORE + 14.0, 1.5, 4.0
def cyl(d, h, z=0, x=0, y=0): c = cylinder(radius=d/2, height=h, sections=96); c.apply_translation([x, y, z + h/2]); return c
body = cyl(OD, H)
adds = [body]
# three guy ears at 120 deg, with 4 mm eye
for k in range(3):
    ear = box(extents=[10, 8, H]); ear.apply_translation([OD/2 + 3, 0, H/2])
    ear.apply_transform(R(2*math.pi*k/3 + math.pi/3, [0,0,1])); adds.append(ear)
# clamp ears either side of the slot (at angle 0)
for s in (1, -1):
    ce = box(extents=[9, 5, H]); ce.apply_translation([OD/2 + 2.5, s*(SLOT/2 + 2.5), H/2]); adds.append(ce)
shell = trimesh.boolean.union(adds, engine="manifold")
cuts = [cyl(BORE, H + 2, z=-1)]
slot = box(extents=[OD, SLOT, H + 2]); slot.apply_translation([OD/2, 0, H/2]); cuts.append(slot)
screw = cylinder(radius=1.7, height=20, sections=32); screw.apply_transform(R(math.pi/2, [1,0,0])); screw.apply_translation([OD/2 + 3.5, 0, H/2]); cuts.append(screw)
for k in range(3):
    e = cyl(EYE, H + 2, z=-1, x=OD/2 + 5); e.apply_transform(R(2*math.pi*k/3 + math.pi/3, [0,0,1])); cuts.append(e)
m = trimesh.boolean.difference([shell] + cuts, engine="manifold")
assert m.is_watertight
m.export(f"guy_collar_{BORE:g}mm.stl"); print("ok", m.bounds[1] - m.bounds[0])
