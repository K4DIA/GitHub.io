#!/usr/bin/env python3
"""Rev C tunable loading coil: section, contact station, electrical. Horizontal layout, dimensions outside the part,
callouts in rows above and below with leaders that do not cross. Writes an SVG."""
import sys

INK = "#1d1b17"; LEAD = "#444"; DIM = "#1d1b17"; EXT = "#888"
FORM = "#e3c89a"; FORML = "#8a6d3b"; SLV = "#c9d0d9"; SLVL = "#5a6472"; CAP = "#aab7c7"; CAPL = "#56657a"; BRASS = "#d4b24f"; BRL = "#8a7020"; WIRE = "#b87333"; BALL = "#d4b24f"; STEEL = "#9a9a9a"

# geometry (mm), z along the axis from the form's base end, r radial
SPIGOT, GAP, COIL, LAND = 14.0, 7.0, 100.0, 40.0
FORM_L = SPIGOT + GAP + COIL + LAND          # 161
FORM_R = 33.4 / 2; CREST_R = 34.24 / 2; BORE_R = 28.4 / 2
PITCH, TURNS, WIRE_D = 2.0, 48, 1.02
SLV_L, SLV_RO, SLV_RI = 169.0, 40.7 / 2, 34.74 / 2
CAP_RO, CAP_H, CAP_SOCK, CAP_FACE = 39.4 / 2, 19.0, 12.0, 7.0
ACTIVE = 20
Z_COIL0 = SPIGOT + GAP                       # 21
Z_BALL = Z_COIL0 + ACTIVE * PITCH            # 61
Z_SLV0 = Z_BALL - 10.0                       # sleeve bottom, stations 10 mm above it
Z_SLV1 = Z_SLV0 + SLV_L                      # 220
BOSS_W, BOSS_OUT = 13.0, 13.0                # boss square, how far the boss stands out from the sleeve OD
CONN = 16.0                                  # SO-239 body length outside each face

S = 4.0                                      # px per mm
OX, OY = 160, 470                            # px of z=0 on the axis
def X(z): return OX + z * S
def Y(r): return OY - r * S                  # r positive = up on the page

o = []
W, H = 1820, 1420
o.append(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" font-family="Helvetica, Arial, sans-serif" font-size="13" fill="{INK}">')
o.append('<rect width="100%" height="100%" fill="#fff"/>')
o.append(f'<text x="24" y="34" font-size="20" font-weight="bold">Tunable loading coil, five ball contacts on a sliding sleeve (rev C)</text>')
o.append(f'<text x="24" y="54" fill="#444">Section through the axis, shown at 20 active turns. SO-239 both ends. Twist the sleeve: the balls ride the valley between turns like a nut on a thread, one turn per revolution.</text>')

def rect(z0, r0, z1, r1, fill, stroke=INK, sw=1.0, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ''
    o.append(f'<rect x="{X(min(z0,z1)):.1f}" y="{Y(max(r0,r1)):.1f}" width="{abs(z1-z0)*S:.1f}" height="{abs(r1-r0)*S:.1f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{d}/>')
def both(z0, r0, z1, r1, fill, stroke=INK):  # mirrored above and below the axis
    rect(z0, r0, z1, r1, fill, stroke); rect(z0, -r0, z1, -r1, fill, stroke)
def line(z0, r0, z1, r1, stroke=INK, sw=1.0, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ''
    o.append(f'<line x1="{X(z0):.1f}" y1="{Y(r0):.1f}" x2="{X(z1):.1f}" y2="{Y(r1):.1f}" stroke="{stroke}" stroke-width="{sw}"{d}/>')

# ---------- the part ----------
# base cap: socket over the spigot, face at z = -CAP_FACE .. 0, socket wall z 0..12
both(-CAP_FACE, 0, 0, CAP_RO, CAP, CAPL)
both(0, FORM_R + 0.2, CAP_SOCK, CAP_RO, CAP, CAPL)
# SO-239 on the base cap face (body outside, to the left)
both(-CAP_FACE - CONN, 0, -CAP_FACE, 7.9, BRASS, BRL)
rect(-CAP_FACE - CONN, 12.7, -CAP_FACE - CONN + 1.6, -12.7, "#c9ccd0", "#666")   # flange
# form wall (hollow), spigot to the end
both(0, BORE_R, FORM_L, FORM_R, FORM, FORML)
# land at crest diameter
both(Z_COIL0 + COIL, FORM_R, FORM_L, CREST_R, FORM, FORML)
# wire turns: little circles on the groove; active ones filled, dead ones open
for i in range(TURNS):
    z = Z_COIL0 + i * PITCH + PITCH / 2
    filled = i < ACTIVE
    for sgn in (1, -1):
        o.append(f'<circle cx="{X(z):.1f}" cy="{Y(sgn*(FORM_R + WIRE_D/2 - 0.3)):.1f}" r="{WIRE_D/2*S:.1f}" fill="{WIRE if filled else "#fff"}" stroke="{WIRE}" stroke-width="0.8"/>')
# sleeve: tube from Z_SLV0 to Z_SLV1, with the connector face closing the top end
both(Z_SLV0, SLV_RI, Z_SLV1, SLV_RO, SLV, SLVL)
rect(Z_SLV1, SLV_RO, Z_SLV1 + CAP_FACE, -SLV_RO, SLV, SLVL)      # face, 7 thick, full width
# SO-239 on the sleeve face (body outside, to the right)
both(Z_SLV1 + CAP_FACE, 0, Z_SLV1 + CAP_FACE + CONN, 7.9, BRASS, BRL)
rect(Z_SLV1 + CAP_FACE + CONN - 1.6, 12.7, Z_SLV1 + CAP_FACE + CONN, -12.7, "#c9ccd0", "#666")
# two stations in the section plane (one above, one below): boss on the sleeve OD, stem, ball, spring, cap
def station(sgn):
    zc = Z_BALL
    rect(zc - BOSS_W/2, sgn*SLV_RO, zc + BOSS_W/2, sgn*(SLV_RO + BOSS_OUT), SLV, SLVL)                   # boss
    rect(zc - 2.2, sgn*(SLV_RI - 1.0), zc + 2.2, sgn*(SLV_RO + BOSS_OUT), "#fff", SLVL)                 # bore through boss and lip hole
    rect(zc - 3.85, sgn*(SLV_RO + BOSS_OUT - 10), zc + 3.85, sgn*(SLV_RO + BOSS_OUT + 9), BRASS, BRL)   # stem, 10 in, 9 out
    rect(zc - 2.65, sgn*(SLV_RO + BOSS_OUT - 10), zc + 2.65, sgn*(SLV_RO + BOSS_OUT + 9), "#fff", BRL)  # stem bore
    o.append(f'<circle cx="{X(zc):.1f}" cy="{Y(sgn*(SLV_RI - 0.2 + 2.0)):.1f}" r="{1.98*S:.1f}" fill="{BALL}" stroke="{BRL}" stroke-width="0.8"/>')  # ball, seated on the wire
    # spring: zigzag from the ball to the cap floor
    r0 = SLV_RI + 4.0; r1 = SLV_RO + BOSS_OUT + 7.5
    pts = []
    n = 10
    for i in range(n + 1):
        r = r0 + (r1 - r0) * i / n; pts.append((zc + (1.6 if i % 2 else -1.6), sgn * r))
    o.append('<polyline points="' + ' '.join(f'{X(z):.1f},{Y(r):.1f}' for z, r in pts) + f'" fill="none" stroke="{BRL}" stroke-width="1"/>')
    rect(zc - 5.6, sgn*(SLV_RO + BOSS_OUT), zc + 5.6, sgn*(SLV_RO + BOSS_OUT + 3), BRASS, BRL)         # knurled nut on the boss face
    rect(zc - 7.0, sgn*(SLV_RO + BOSS_OUT + 3), zc + 7.0, sgn*(SLV_RO + BOSS_OUT + 4), WIRE, "#7a4a20") # ring terminal under the nut
    rect(zc - 4.6, sgn*(SLV_RO + BOSS_OUT + 4.5), zc + 4.6, sgn*(SLV_RO + BOSS_OUT + 13), "#c9ccd0", "#666")  # metal valve cap
station(1); station(-1)
# wire tails: base tail from the first turn into the bore to the base SO-239 pin; top tail into the bore and left
line(Z_COIL0, FORM_R, Z_COIL0 - 1, BORE_R - 1, WIRE, 1.2); line(Z_COIL0 - 1, BORE_R - 1, -CAP_FACE, 0, WIRE, 1.2)
line(Z_COIL0 + COIL, FORM_R, Z_COIL0 + COIL - 1, BORE_R - 1, WIRE, 1.2); line(Z_COIL0 + COIL - 1, BORE_R - 1, Z_COIL0 + COIL - 10, BORE_R - 4, WIRE, 1.2)
# bus wire: from the station terminal along the sleeve outside to the face, through the side hole, to the sleeve SO-239 pin
line(Z_BALL + 7, SLV_RO + BOSS_OUT + 3.5, Z_SLV1 - 6, SLV_RO + 2.5, "#c0392b", 1.3)
line(Z_SLV1 - 6, SLV_RO + 2.5, Z_SLV1 - 6, SLV_RI - 2, "#c0392b", 1.3); line(Z_SLV1 - 6, SLV_RI - 2, Z_SLV1 + CAP_FACE, 0, "#c0392b", 1.3)
# centreline
line(-CAP_FACE - CONN - 10, 0, Z_SLV1 + CAP_FACE + CONN + 10, 0, "#999", 0.7, "10 4")

# ---------- dimensions, all above the part ----------
def ext_up(z, r_from, px_to): o.append(f'<line x1="{X(z):.1f}" y1="{Y(r_from):.1f}" x2="{X(z):.1f}" y2="{px_to}" stroke="{EXT}" stroke-width="0.7"/>')
def dim_h(z0, z1, ypx, text, size=12):
    o.append(f'<line x1="{X(z0):.1f}" y1="{ypx}" x2="{X(z1):.1f}" y2="{ypx}" stroke="{DIM}" stroke-width="0.9"/>')
    for z, sg in ((z0, 1), (z1, -1)): o.append(f'<path d="M{X(z):.1f},{ypx} l{6*sg},-3 l0,6 z" fill="{DIM}"/>')
    o.append(f'<text x="{(X(z0)+X(z1))/2:.1f}" y="{ypx - 5}" text-anchor="middle" font-size="{size}">{text}</text>')
TOP_R = SLV_RO + BOSS_OUT + 13
y1 = Y(TOP_R) - 30     # active turns
y2 = y1 - 30           # form chain
y3 = y2 - 30           # sleeve
y4 = y3 - 30           # overall
for z in (Z_COIL0, Z_BALL): ext_up(z, FORM_R + WIRE_D if z < Z_SLV0 else TOP_R, y1 - 6)
dim_h(Z_COIL0, Z_BALL, y1, "20 active turns, visible below the sleeve")
for z in (0, SPIGOT, Z_COIL0 + COIL, FORM_L): ext_up(z, CAP_RO if z <= SPIGOT else (SLV_RO if z < Z_SLV1 else CREST_R), y2 - 6)
dim_h(0, SPIGOT, y2, "14"); dim_h(SPIGOT, Z_COIL0, y2, "7"); dim_h(Z_COIL0, Z_COIL0 + COIL, y2, "100 coil, 48 turns at 2.0 pitch"); dim_h(Z_COIL0 + COIL, FORM_L, y2, "40 land")
for z in (Z_SLV0, Z_SLV1): ext_up(z, TOP_R if z == Z_SLV0 else SLV_RO, y3 - 6)
dim_h(Z_SLV0, Z_SLV1, y3, "169 sleeve, OD 40.7, bore 34.74")
for z in (-CAP_FACE - CONN, Z_SLV1 + CAP_FACE + CONN): ext_up(z, 12.7, y4 - 6)
dim_h(-CAP_FACE - CONN, Z_SLV1 + CAP_FACE + CONN, y4, "260 overall at this tap: 220 at turn 1, 316 at turn 48")
o.append(f'<text x="{X(FORM_L/2):.1f}" y="{y2 - 20}" text-anchor="middle" font-size="11">form 161: spigot 14, gap 7, coil 100, land 40</text>')

# ---------- callouts below: ladder with orthogonal leaders, rows ordered by target position so nothing crosses ----------
RX = X(Z_SLV1 + CAP_FACE + CONN) + 30
BOT = Y(-TOP_R) + 26
rows = [  # (target z, target r, text); rightmost target first so no vertical crosses another row's horizontal
    (Z_SLV1 + CAP_FACE + CONN/2, -7.9, "SO-239 on the sleeve face; the bus wire enters the side hole and solders to its pin"),
    (Z_COIL0 + COIL + LAND/2, -CREST_R, "bearing land, 40 mm at crest diameter: the sleeve rides on it at every tap"),
    (Z_COIL0 + COIL - 10, -(BORE_R - 4), "top tail pushed into the bore; it connects to nothing"),
    (Z_BALL, -(SLV_RO + BOSS_OUT + 13), "contact station: stem 10 mm into the boss, ball in the valley 0.2 below the crests, spring, cap"),
    (Z_SLV0, -SLV_RO, "sleeve bottom: the active turns are the ones you can see below it"),
    (Z_COIL0, -(FORM_R + WIRE_D), "winding starts here: bare tinned 18 AWG, 1.02 mm, about 5.5 m"),
    (-CAP_FACE - CONN/2, -7.9, "SO-239 on the base cap; the first turn's tail runs into the bore to its pin"),
]
for i, (z, r, text) in enumerate(rows):
    yrow = BOT + 16 + i * 24
    o.append(f'<line x1="{X(z):.1f}" y1="{Y(r):.1f}" x2="{X(z):.1f}" y2="{yrow}" stroke="{LEAD}" stroke-width="0.9"/>')
    o.append(f'<line x1="{X(z):.1f}" y1="{yrow}" x2="{RX - 8}" y2="{yrow}" stroke="{LEAD}" stroke-width="0.9"/>')
    o.append(f'<circle cx="{X(z):.1f}" cy="{Y(r):.1f}" r="2.4" fill="{LEAD}"/>')
    o.append(f'<text x="{RX}" y="{yrow + 4}" font-size="11.5">{text}</text>')

# ---------- row 2: one station exploded, left to right in assembly order ----------
RY = 1050
o.append(f'<text x="24" y="{RY - 110}" font-size="15" font-weight="bold">One contact station, exploded: five on the sleeve, all tire-valve parts</text>')
o.append(f'<text x="24" y="{RY - 90}" fill="#444">Nut and terminal on the stem; stem into the boss until it bottoms on the shoulder; ball; spring; cap on until it bottoms. Nothing to adjust.</text>')
S2 = 5.5
def rr(x, y, w, h, fill, stroke=INK): o.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" fill="{fill}" stroke="{stroke}" stroke-width="1"/>')
items = []
x = 150
# boss block with bore, shoulder and lip hole (section)
bw, bh = 13 * S2, 14 * S2
rr(x, RY - bh/2, bw, bh, SLV, SLVL); rr(x + 2.2 * S2, RY - 7/2*S2, (10) * S2, 7 * S2, "#fff", SLVL); rr(x, RY - 3.4/2*S2, 2.2 * S2, 3.4 * S2, "#fff", SLVL); rr(x + 2.2*S2, RY - 4.4/2*S2, 1.5*S2, 4.4*S2, "#fff", SLVL)
items.append((x + bw/2, "boss, 13 square: lip 1.0, hole 3.4,", "chamber 4.4 x 4, bore 7.0 x 10, tapped .305-32"))
x += bw + 150
o.append(f'<circle cx="{x + 2*S2:.1f}" cy="{RY}" r="{1.98*S2:.1f}" fill="{BALL}" stroke="{BRL}"/>'); items.append((x + 2*S2, "5/32 in brass ball", "")); x += 4*S2 + 150
pts = []; L = 25 * S2
for i in range(13): pts.append((x + L * i / 12, RY + (8 if i % 2 else -8)))
o.append('<polyline points="' + ' '.join(f'{a:.1f},{b:.1f}' for a, b in pts) + f'" fill="none" stroke="{BRL}" stroke-width="1.6"/>'); items.append((x + L/2, "spring 4.0 OD x 0.55 x 25 free, phosphor", "bronze or BeCu; never music wire")); x += L + 120
rr(x, RY - 3.85*S2, 19*S2, 7.7*S2, BRASS, BRL); rr(x, RY - 2.65*S2, 19*S2, 5.3*S2, "#fff", BRL); items.append((x + 9.5*S2, "brass valve stem, .305-32, cut to 19:", "10 into the boss, 9 showing")); x += 19*S2 + 150
rr(x, RY - 5.6*S2, 3*S2, 11.2*S2, BRASS, BRL); items.append((x + 1.5*S2, "stem's own knurled nut", "")); x += 3*S2 + 130
o.append(f'<circle cx="{x + 6*S2:.1f}" cy="{RY}" r="{6*S2:.1f}" fill="none" stroke="{WIRE}" stroke-width="3"/>'); items.append((x + 6*S2, "5/16 ring terminal: bus wire", "")); x += 12*S2 + 110
rr(x, RY - 4.6*S2, 9*S2, 9.2*S2, "#c9ccd0", "#666"); rr(x, RY - 3.5*S2, 1.2*S2, 7*S2, "#fff", "#666"); items.append((x + 4.5*S2, "metal valve cap, brass or nickel;", "anodised aluminium insulates"))
for i, (cx, t1, t2) in enumerate(items):
    o.append(f'<text x="{cx:.1f}" y="{RY + 60}" text-anchor="middle" font-size="11.5">{t1}</text>')
    if t2: o.append(f'<text x="{cx:.1f}" y="{RY + 75}" text-anchor="middle" font-size="11.5">{t2}</text>')
    o.append(f'<text x="{cx:.1f}" y="{RY - 58}" text-anchor="middle" font-size="12" font-weight="bold">{i+1}</text>')

# ---------- row 3: electrical ----------
EY = 1310
o.append(f'<text x="24" y="{EY - 50}" font-size="15" font-weight="bold">Electrical</text>')
o.append(f'<line x1="120" y1="{EY}" x2="330" y2="{EY}" stroke="{INK}" stroke-width="1.5"/>')
o.append(f'<circle cx="330" cy="{EY}" r="5" fill="#fff" stroke="{INK}" stroke-width="1.5"/>')
o.append(f'<text x="120" y="{EY - 10}">mount, fixed coils or radio</text><text x="330" y="{EY + 22}" text-anchor="middle" font-size="11">SO-239, base cap</text>')
# coil: active turns solid, dead turns dashed
cx0 = 340; n_act, n_dead = 12, 8; w = 14
path = f'M{cx0},{EY}'
for i in range(n_act): path += f' a{w/2},{w/2} 0 0 1 {w},0'
o.append(f'<path d="{path}" fill="none" stroke="{INK}" stroke-width="1.5"/>')
tap = cx0 + n_act * w
path = f'M{tap},{EY}'
for i in range(n_dead): path += f' a{w/2},{w/2} 0 0 1 {w},0'
o.append(f'<path d="{path}" fill="none" stroke="{INK}" stroke-width="1.5" stroke-dasharray="4 3"/>')
o.append(f'<text x="{cx0 + n_act*w/2:.0f}" y="{EY + 22}" text-anchor="middle" font-size="11">active turns</text><text x="{tap + n_dead*w/2:.0f}" y="{EY + 22}" text-anchor="middle" font-size="11">dead turns, open end</text>')
o.append(f'<line x1="{tap}" y1="{EY}" x2="{tap}" y2="{EY - 36}" stroke="{INK}" stroke-width="1.5"/><path d="M{tap - 4},{EY - 10} l4,8 l4,-8 z" fill="{INK}"/>')
o.append(f'<line x1="{tap}" y1="{EY - 36}" x2="{tap + 260}" y2="{EY - 36}" stroke="{INK}" stroke-width="1.5"/><line x1="{tap + 260}" y1="{EY - 36}" x2="{tap + 260}" y2="{EY}" stroke="{INK}" stroke-width="1.5"/>')
o.append(f'<text x="{tap + 130}" y="{EY - 42}" text-anchor="middle" font-size="11">five balls in parallel, bus wire</text>')
o.append(f'<circle cx="{tap + 260}" cy="{EY}" r="5" fill="#fff" stroke="{INK}" stroke-width="1.5"/><line x1="{tap + 265}" y1="{EY}" x2="{tap + 340}" y2="{EY}" stroke="{INK}" stroke-width="1.5"/>')
o.append(f'<text x="{tap + 260}" y="{EY + 22}" text-anchor="middle" font-size="11">SO-239, sleeve</text><text x="{tap + 348}" y="{EY + 4}">whip</text>')
o.append(f'<text x="{tap + 430}" y="{EY - 30}" font-size="11.5">Current path: base pin, bottom of coil, up the active turns, balls, bus wire, sleeve pin, whip.</text>')
o.append(f'<text x="{tap + 430}" y="{EY - 12}" font-size="11.5">Connector shells float at both ends. Copper tape inside the sleeve shorts the dead turns.</text>')
o.append(f'<text x="{tap + 430}" y="{EY + 6}" font-size="11.5">Inductance, 2.0 pitch: 10 turns 3 uH, 20 t 8.5, 30 t 14, 40 t 20, 48 t 24. Stack a fixed rev B below for 40 m.</text>')
o.append(f'<text x="{tap + 430}" y="{EY + 24}" font-size="11.5">Twist, never push: the valley is shallow; a hard axial shove can skip a turn, twisting cannot.</text>')
o.append('</svg>')
open(sys.argv[1], 'w', encoding='utf-8').write('\n'.join(o)); print('ok')
