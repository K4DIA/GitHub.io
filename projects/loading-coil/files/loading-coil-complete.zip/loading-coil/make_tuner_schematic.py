#!/usr/bin/env python3
"""tuner_schematic.svg: rev C screwdriver-style tunable coil, section + station detail + electrical."""
W, H = 1300, 1230
o = []; A = o.append
A(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" font-family="Helvetica, Arial, sans-serif" font-size="13">')
A('<rect width="100%" height="100%" fill="white"/>')
A('<text x="24" y="34" font-size="22" font-weight="bold">Tunable Loading Coil, screwdriver style, 5 Schrader-stem ball contacts (rev C)</text>')
A('<text x="24" y="54" fill="#444">SO-239 both ends. Twist the sleeve: the balls ride the valley between turns like a nut on a thread, one pitch (2.0 mm, one turn) per revolution.</text>')

S = 3.0                       # px per mm
ox = 110; cy = 300
def X(mm): return ox + mm * S
def Y(mm): return cy - mm * S

# ---- geometry (mm) ----
cap_face, cap_sock, cap_od = 7, 12, 39.4
form_L, form_od, form_id, land0, crest_od = 161, 33.4, 28.4, 121, 34.24
z_t0, z_t1, pitch = 22.1, 118.1, 2.0
tap_turn = 20                 # drawn position: ball on turn 20 from the bottom
z_tap = z_t0 + pitch * tap_turn
sl_od, sl_bore, sl_depth, sl_face, st_z = 40.74, 34.74, 162, 7, 10
sl_z0 = z_tap - st_z          # sleeve bottom
sl_H = sl_depth + sl_face

def rect(x0, x1, y0, y1, fill, stroke="#222", sw=1):
    A(f'<rect x="{min(X(x0),X(x1))}" y="{min(Y(y0),Y(y1))}" width="{abs(X(x1)-X(x0))}" height="{abs(Y(y1)-Y(y0))}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')

# base cap (left), x = axial position, y = radial
rect(-cap_face, 0, -cap_od/2, cap_od/2, "#6d7a88")
rect(0, cap_sock, form_od/2, cap_od/2, "#6d7a88"); rect(0, cap_sock, -cap_od/2, -form_od/2, "#6d7a88")
rect(-cap_face, 0, -16.5/2, 16.5/2, "white")
rect(-cap_face-3, -cap_face, -25.4/2, 25.4/2, "#c9a84a"); rect(-cap_face-16, -cap_face-3, -15.9/2, 15.9/2, "#d8c27a")
# form walls
for s in (1, -1):
    rect(0, land0, s*form_id/2, s*form_od/2, "#bfc5cc")
    rect(land0, form_L, s*form_id/2, s*crest_od/2, "#bfc5cc")
# winding: active turns (below tap) solid copper, dead turns (above) hollow
z = z_t0
while z <= z_t1 + 0.01:
    active = z <= z_tap + 0.01
    for s in (1, -1):
        A(f'<circle cx="{X(z)}" cy="{Y(s*(form_od/2+0.42))}" r="{0.51*S}" fill="{"#c76b2a" if active else "white"}" stroke="#7a3d12" stroke-width="0.7"/>')
    z += pitch
# wire from first turn into bore to base connector tail
A(f'<path d="M {X(z_t0)} {Y(form_od/2)} L {X(z_t0)} {Y(form_id/2-1)} L {X(6)} {cy}" fill="none" stroke="#c76b2a" stroke-width="2.2"/>')
A(f'<line x1="{X(-cap_face-16)}" y1="{cy}" x2="{X(6)}" y2="{cy}" stroke="#333" stroke-width="3"/>')

# sleeve (semi-transparent so form shows through)
for s in (1, -1):
    rect(sl_z0, sl_z0 + sl_depth, s*sl_bore/2, s*sl_od/2, "#8fa3b8", sw=1)
rect(sl_z0 + sl_depth, sl_z0 + sl_H, -sl_od/2, sl_od/2, "#6d7a88")
rect(sl_z0 + sl_depth, sl_z0 + sl_H, -16.5/2, 16.5/2, "white")
# sleeve connector
xf = sl_z0 + sl_H
rect(xf, xf+3, -25.4/2, 25.4/2, "#c9a84a"); rect(xf+3, xf+16, -15.9/2, 15.9/2, "#d8c27a")
A(f'<line x1="{X(xf-10)}" y1="{cy}" x2="{X(xf+16)}" y2="{cy}" stroke="#333" stroke-width="3"/>')
# stations (2 visible in section: top and bottom), diamond boss as a rectangle in section
boss_out = sl_bore/2 + 15.0
for s in (1, -1):
    rect(z_tap - 6.5, z_tap + 6.5, s*sl_od/2, s*boss_out, "#8fa3b8")
    rect(z_tap - 2.2, z_tap + 2.2, s*(sl_bore/2 + 1), s*(sl_bore/2 + 5), "white", sw=0.8)     # ball chamber
    rect(z_tap - 3.5, z_tap + 3.5, s*(sl_bore/2 + 5), s*boss_out, "white", sw=0.8)           # tapped bore .305-32
    rect(z_tap - 3.85, z_tap + 3.85, s*(sl_bore/2 + 5), s*(sl_bore/2 + 23), "#c9a84a", sw=0.8)   # brass stem 18 long
    rect(z_tap - 2.65, z_tap + 2.65, s*(sl_bore/2 + 5), s*(sl_bore/2 + 23), "white", sw=0.6)     # stem bore
    rect(z_tap - 5.5, z_tap + 5.5, s*(sl_bore/2 + 15), s*(sl_bore/2 + 18.5), "#b08d3a", sw=0.8)  # lock nut + terminal
    rect(z_tap - 4.8, z_tap + 4.8, s*(sl_bore/2 + 19), s*(sl_bore/2 + 25), "#8a8f96", sw=0.8)    # metal cap
    rect(z_tap - 2.65, z_tap + 2.65, s*(sl_bore/2 + 19), s*(sl_bore/2 + 23.5), "white", sw=0.6)  # cap interior
    A(f'<circle cx="{X(z_tap)}" cy="{Y(s*(form_od/2+0.42+1.6))}" r="{1.98*S}" fill="#e3c25c" stroke="#333" stroke-width="0.8"/>')  # ball
    # spring zigzag
    y0 = Y(s*(sl_bore/2+4.1)); y1 = Y(s*(sl_bore/2+23.3)); n = 14
    pts = " ".join(f"{X(z_tap)+(-1)**i*3},{y0+(y1-y0)*i/n}" for i in range(n+1))
    A(f'<polyline points="{pts}" fill="none" stroke="#555" stroke-width="1.2"/>')
# bus wire: ring around screws (shown as line along the outside) to bus hole into tail pocket
A(f'<path d="M {X(z_tap+5.5)} {Y(sl_bore/2+17)} L {X(z_tap+5.5)} {Y(boss_out+12)} L {X(sl_z0+sl_depth-6)} {Y(boss_out+12)} L {X(sl_z0+sl_depth-6)} {Y(sl_bore/2-2)} L {X(sl_z0+sl_depth+2)} {cy}" fill="none" stroke="#c76b2a" stroke-width="2"/>')
A(f'<text x="{X(z_tap+40)}" y="{Y(boss_out+12)-8}" fill="#7a3d12" text-anchor="start">bus wire: ring terminals under the 5 stem lock nuts, enters through side hole into tail pocket, solders to center pin</text>')

# dims
def dim(x1, x2, y, text, above=True):
    A(f'<line x1="{x1}" y1="{y}" x2="{x2}" y2="{y}" stroke="#1a4fa0"/>')
    for xx in (x1, x2): A(f'<line x1="{xx}" y1="{y-5}" x2="{xx}" y2="{y+5}" stroke="#1a4fa0"/>')
    A(f'<text x="{(x1+x2)/2}" y="{y-6 if above else y+16}" text-anchor="middle" fill="#1a4fa0">{text}</text>')
top = Y(boss_out + 6); bot = Y(-boss_out - 6)
dim(X(0), X(form_L), top - 60, "form 161 mm: 14 spigot | 7 gap | 100 coil (48 turns @ 2.0) | 40 bearing land at crest OD 34.24")
dim(X(sl_z0), X(sl_z0 + sl_H), top - 36, "sleeve 169 mm (OD 40.7, bore 34.74), connector face on top")
dim(X(z_t0), X(z_tap), top - 6, f"active turns (visible below sleeve) = {tap_turn}")
dim(X(-cap_face-16), X(xf+16), bot + 20, f"overall at this tap: {round(xf+16+cap_face+16)} mm. Range: tap at turn 1 = 220 mm, tap at turn 48 = 316 mm", above=False)
A(f'<text x="{X(z_t0)}" y="{bot+56}" fill="#7a3d12">filled turns = in circuit (below the balls); open turns = dead, inside the sleeve</text>')
A(f'<text x="{X(z_t0)}" y="{bot+74}" fill="#7a3d12">wire: bare tinned 18 AWG (1.02 mm), about 5.5 m. Bare, not enamel: the balls need copper.</text>')

# ---- station detail (exploded, radial) ----
dx, dy = 60, 650
A(f'<text x="{dx}" y="{dy-20}" font-size="18" font-weight="bold">Contact station, exploded (5 identical at 72 deg, 0.4 mm apart axially, ring 10 mm above sleeve bottom; all metal parts are tire-valve parts)</text>')
k = 9  # px per mm
def r2(x, w, y, h, fill, stroke="#222"): A(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}"/>')
bx = dx + 40; by = dy + 20
# boss body outline (section), 15 mm from bore to outer face
r2(bx, 15*k, by, 13*k, "#8fa3b8")
r2(bx, 1.0*k, by+(13-3.4)/2*k, 3.4*k, "white")                 # lip hole 3.4
r2(bx+1.0*k, 4.0*k, by+(13-4.4)/2*k, 4.4*k, "white")           # ball chamber 4.4 x 4
r2(bx+5.0*k, 10.0*k, by+(13-7.0)/2*k, 7.0*k, "white")          # 7.0 bore, tapped .305-32 x 10
A(f'<text x="{bx-8}" y="{by+13*k/2+4}" text-anchor="end" fill="#444">bore side (coil)</text>')
A(f'<text x="{bx+15*k+8}" y="{by+13*k/2+4}" fill="#444">outside</text>')
px = bx + 15*k + 80; pyc = by + 13*k/2
A(f'<circle cx="{px}" cy="{pyc}" r="{1.985*k}" fill="#e3c25c" stroke="#333"/>'); A(f'<text x="{px}" y="{pyc+7*k+18}" text-anchor="middle">5/32 in brass ball</text>')
px += 60
pts = " ".join(f"{px + i*25*k/14},{pyc + (-1)**i*2*k}" for i in range(15))
A(f'<polyline points="{pts}" fill="none" stroke="#555" stroke-width="2"/>'); A(f'<text x="{px+12.5*k}" y="{pyc+7*k+38}" text-anchor="middle">spring 4.0 OD x 0.55 wire x 25 free, phosphor bronze or BeCu</text>')
px += 25*k + 40
r2(px, 18*k, pyc-3.85*k, 7.7*k, "#c9a84a"); r2(px, 18*k, pyc-2.65*k, 5.3*k, "white", "#999")
for i in range(1, 23): A(f'<line x1="{px+i*0.794*k}" y1="{pyc-3.85*k}" x2="{px+i*0.794*k}" y2="{pyc-2.65*k}" stroke="#7a5a1a" stroke-width="0.5"/><line x1="{px+i*0.794*k}" y1="{pyc+2.65*k}" x2="{px+i*0.794*k}" y2="{pyc+3.85*k}" stroke="#7a5a1a" stroke-width="0.5"/>')
A(f'<text x="{px+9*k}" y="{pyc+7*k+18}" text-anchor="middle">brass valve stem, .305-32 body, cut to 18 to 20 mm</text>')
px += 18*k + 40
r2(px, 3.5*k, pyc-5.5*k, 11*k, "#b08d3a"); A(f'<circle cx="{px+1.75*k+6*k}" cy="{pyc}" r="{3.6*k}" fill="none" stroke="#7a3d12" stroke-width="3"/>')
A(f'<text x="{px+5*k}" y="{pyc+7*k+38}" text-anchor="middle">lock nut + ring terminal</text>')
px += 12*k + 40
r2(px, 10*k, pyc-4.8*k, 9.6*k, "#8a8f96"); r2(px, 6*k, pyc-3.85*k, 7.7*k, "white", "#999")
A(f'<text x="{px+5*k}" y="{pyc+7*k+18}" text-anchor="middle">metal valve cap (brass or Ni-plated)</text>')
A(f'<text x="{dx}" y="{by+13*k+60}" fill="#1a4fa0">lip 1.0 (hole 3.4) | ball chamber 4.4 dia x 4 | bore 7.0 dia x 10, tap .305-32 UNEF RH (tire-valve tap; 5/16-32 also fits, loose) | boss 13 mm square on the diagonal</text>')
A(f'<text x="{dx}" y="{by+13*k+84}" fill="#333">Assembly from outside: thread the stem in until it bottoms on the chamber shoulder (10 mm in, the rest out). Drop ball, drop spring into the stem, screw the cap on until it bottoms.</text>')
A(f'<text x="{dx}" y="{by+13*k+102}" fill="#333">Spring compressed 25 to about 20 mm, about 5 N. Phosphor bronze or BeCu only: steel springs dissipate about 3 W at 100 W. Lock nut clamps the bus-wire ring terminal against the boss face. Cap off = spring and ball out, with the sleeve still on the form.</text>')
A(f'<text x="{dx}" y="{by+13*k+120}" fill="#333">Why metal caps: anodized aluminum caps are insulated; use brass or nickel-plated. The electrical path is ball, spring, cap, stem threads, lock nut, terminal. Five in parallel.</text>')

# ---- electrical ----
ey = 1080
A(f'<text x="24" y="{ey-60}" font-size="18" font-weight="bold">Electrical</text>')
x = 200
A(f'<text x="{x-6}" y="{ey+5}" text-anchor="end">Mount / fixed coils / radio</text>')
A(f'<line x1="{x}" y1="{ey}" x2="{x+40}" y2="{ey}" stroke="#222" stroke-width="2.5"/>'); x += 40
A(f'<circle cx="{x}" cy="{ey}" r="5" fill="white" stroke="#222" stroke-width="2"/>'); A(f'<text x="{x}" y="{ey+26}" text-anchor="middle" font-size="11" fill="#555">SO-239, base cap</text>'); x += 5
A(f'<line x1="{x}" y1="{ey}" x2="{x+30}" y2="{ey}" stroke="#222" stroke-width="2.5"/>'); x += 30
ix = x; nt = 14; tap = 8
d = f"M {ix} {ey} " + "a 9 9 0 0 1 18 0 " * nt
A(f'<path d="{d}" fill="none" stroke="#222" stroke-width="2.5"/>')
A(f'<text x="{ix+18*tap/2}" y="{ey+26}" text-anchor="middle" font-size="11" fill="#555">active turns</text>')
A(f'<text x="{ix+18*(tap+(nt-tap)/2)}" y="{ey+26}" text-anchor="middle" font-size="11" fill="#555">dead turns, open end</text>')
tx = ix + 18*tap
A(f'<polygon points="{tx-5},{ey-16} {tx+5},{ey-16} {tx},{ey-6}" fill="#222"/>')
A(f'<path d="M {tx} {ey-16} L {tx} {ey-44} L {ix+18*nt+60} {ey-44} L {ix+18*nt+60} {ey}" fill="none" stroke="#222" stroke-width="2.5"/>')
A(f'<text x="{tx}" y="{ey-52}" text-anchor="middle" font-size="12">5 balls in parallel, bus wire (bridges one turn)</text>')
x = ix+18*nt+60
A(f'<line x1="{x}" y1="{ey}" x2="{x+30}" y2="{ey}" stroke="#222" stroke-width="2.5"/>'); x += 30
A(f'<circle cx="{x}" cy="{ey}" r="5" fill="white" stroke="#222" stroke-width="2"/>'); A(f'<text x="{x}" y="{ey+26}" text-anchor="middle" font-size="11" fill="#555">SO-239, sleeve</text>'); x += 5
A(f'<line x1="{x}" y1="{ey}" x2="{x+40}" y2="{ey}" stroke="#222" stroke-width="2.5"/>')
A(f'<text x="{x+46}" y="{ey+5}">Whip</text>')
A(f'<text x="24" y="{ey+60}" fill="#333">&#8226; Current path: base pin, bottom of coil, up the active turns, balls, bus wire, sleeve pin, whip. Connector shells float at both ends.</text>')
A(f'<text x="24" y="{ey+80}" fill="#333">&#8226; Optional: self-adhesive copper tape lining the sleeve bore above the stations, soldered to the bus, shorts the dead turns like a screwdriver mast.</text>')
A(f'<text x="24" y="{ey+100}" fill="#333">&#8226; Inductance (Wheeler, 1.36 in coil dia, 2.0 mm pitch): 10 turns 3 uH, 20 t 8.5 uH, 30 t 14 uH, 40 t 20 uH, 48 t 24 uH. Stack a fixed rev B coil below for 40 m.</text>')
A(f'<text x="24" y="{ey+120}" fill="#333">&#8226; Twist, do not push: the valley is shallow by design (0.2 mm V on a 4 mm ball). A hard axial shove can skip a turn; twisting never will.</text>')
A('</svg>')
open("tuner_schematic.svg", "w").write("\n".join(o))
