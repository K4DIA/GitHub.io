# Tripod hub, rev D: machining notes

One piece, 6061-T6, from 3-1/2 in round bar. Lathe for the body, chamfer, boss and bore; a tilting table or an angle fixture for the three leg holes. `revD_tripod_hub_ALU.step` is modeled with every hole at tap-drill size; the threads and the finish are specified on `revD_tripod_hub_DRAWING.pdf`, which goes with the STEP whenever the part is quoted. Finished mass about 285 g.

Two STEP exports of the same solid are supplied: `revD_tripod_hub_ALU.step` (AP214) and `revD_tripod_hub_ALU_AP203.stp` (AP203, the plainest schema). If an uploader rejects one, use the other. Quoting online: Xometry, JLCPCB and PCBWay take the STEP plus the drawing PDF and quote the threads and finish from it. SendCutSend's CNC app does not read drawings; upload the STEP, pick each tap-drill hole in the app and select its thread, and choose the finish there.

| Feature | Dimension | Note |
|---|---|---|
| Body | 86 mm dia x 23 thick | |
| Bottom chamfer | 13 mm radial x 10.9 mm rise, 40 deg from the bottom face, full circumference | The leg seat. Chamfer edge on the bottom face is 60 mm dia. |
| Boss | 50 mm dia x 36 tall on top, concentric | |
| Through bore | 41.04 mm +0.05/-0, straight through body and boss (59 mm) | The printed housing (OD 40.74) drops in from the top and hangs from its collar on the boss face. Bore or ream; do not drill. |
| Leg holes | 3 at 120 deg, on the chamfer face, centred at 36.5 mm radius, axis square to the chamfer (40 deg from the hub axis, pointing in and up), 15 deep. Tap 3/8-16 UNC, tap drill 8.0 mm (5/16 in). | The hole ends 2.3 mm from the bore and 2.1 mm from the top face. Optional spot-face 13 x 1 mm square to the axis for a full-contact seat. |
| Radial screws | 3 at 120 deg, between the legs, top face, 34 mm radius, 12 deep. Tap 1/4-20 UNC, tap drill 5.1 mm (#7). | Ring terminals for the radials and the coax shield. The hub is the ground side of the antenna. |
| Set screw | M5 x 0.8, radial through the boss, 13 mm below the boss top. Tap drill 4.2 mm. | Nylon- or brass-tipped. Lands in a groove on the housing. Only stops the housing turning; the collar carries the weight. |
| Engraving | "K4DIA" three times on the top face, one per sector between the 1/4-20 holes, tangent on a 34 mm radius, bold sans 9 mm, 0.5 mm deep. As modeled in the STEP. | 3-axis engraving or a small end mill; no fill. Chem film goes over it. |
| Finish | Chem film (chromate conversion), MIL-DTL-5541 Type II Class 3, after all machining. JLCCNC lists this as "Conductive anodizing - Natural". | Class 3 is the conductive grade. If the finish line bundles bead blasting, add "do not blast the bore" to the order notes; the housing slides in that bore. It adds no measurable thickness, so threads need no masking and it goes on after tapping. Do not anodize: anodize is an insulator and builds thread size. If a shop offers only anodize, order the part bare. |

Order of operations: machine, tap, deburr, then chem film. The coating is a dip, a few minutes, and the whole part including the threads and the bore comes out conductive.

Legs: three 1/2 in 6061 rods or 1/2 in x 0.058 wall tubes, 750 mm, with 3/8-16 cut 12 mm long on one end (a die, or the shop does it while it has the parts; the hole is 15 mm deep, so 20 mm of thread would bottom). For tube, epoxy a 3/8-16 x 1-1/2 in stud 1 in into the end, 1/2 in showing (the tapped hole is 15 mm deep; a 2 in stud bottoms); the 9.5 mm stud fits the 9.7 mm bore. Rubber chair-leg tips for feet. At 40 deg, 750 mm legs give 575 mm of height and a 520 mm foot radius.

Electrical: the hub, legs and radials are ground. The whip is insulated from the hub by the housing's plastic wall, so no thread or bore in the hub carries RF.

Loads: whip bending goes whip base, 22 mm bore in the housing top, housing wall, 59 mm of aluminum bore, body, legs. The 3/8-24 stud carries tension only. The limit is the whip's own base section, 45 to 80 N m; the SS17 at 30 mph produces about 18 N m.
