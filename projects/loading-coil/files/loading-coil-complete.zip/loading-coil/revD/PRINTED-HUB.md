# Printed tripod hub and leg feet, rev D

The hub is a printed part sized for brass heat-set inserts. The housing comes up through it from below and hangs from the threaded collar on the boss face, the legs screw into it, K4DIA is in the top face. `revD_tripod_hub_PRINT.stl`. The machined version of the same hub is in `machined_alt/` if you ever want metal; nothing else changes.

Why plastic is enough: the housing carries the whip's bending into a 65 mm bore, and the hub was only ever metal so the radials could bolt to it. With a printed hub the radials and the coax shield share one 1/4-20 bolt. The legs were never part of the antenna.

## Hub

| | Spec |
|---|---|
| Body | 98 x 29 with the 40 deg chamfer seat; boss 52 x 36 with a 14 x 6 rib for the set-screw insert; bore 41.14 straight through; 65 mm tall; 177 cm3 |
| Material | MJF PA12 at a print service (about $40, 180 g) or PETG or ASA at home (6 walls, 40% infill minimum, 220 g at 100%) |
| Leg inserts | 3 x 3/8-16 x 1/2 in brass heat-set inserts, 0.469 in OD, 15/32 in (11.9 mm) hole, 17 mm deep on the chamfer face. HI-316-WH, Zoro 1GUA1, 25 for about $14. |
| Top inserts | 3 x 1/4-20 x 1/2 in heat-set inserts, 0.315 in OD, 5/16 in (7.9 mm) hole, 15 mm deep on the top face. HI-420-WH, Zoro G3434347. One takes the ground bolt; the other two are spares. |
| Ground bolt | 1/4-20 x 3/4 in stainless. Radials and the coax shield on ring terminals under the head, washer, nut. The only electrical point on the hub. |
| Set screw | M5 x 9.5 long heat-set insert (6.4 OD, ruthex or CNC Kitchen type) in the 6.4 mm hole through the rib on the boss, 11.4 mm of wall; nylon-tip M5 x 16 set screw (11.6 mm from the rib face to the housing). Stops the housing rotating, nothing else. |
| Insert holes | Measure the inserts you buy and change `leg_tap_drill`, `radial_tap_drill` and `setscrew_tap_drill` in `tripod_print` to the maker's recommended hole size before printing. |

Setting inserts: soldering iron at 200 C for PA12 or PETG, press each insert in square until flush, let it cool before loading. The chamfer face is square to each leg hole, so the insert goes in square to the face.

## Legs

Three 1/2 in OD x 0.058 wall 6061-T6 round tubes, 750 mm (McMaster-Carr, OnlineMetals, Speedy Metals). Epoxy a 3/8-16 x 1-1/2 in stud 1 in into the top end with 1/2 in showing; the hub hole is 17 mm deep and a 2 in stud would bottom before the tube seats. The 0.384 in ID takes a 3/8 rod, 0.065 wall does not. Legs screw into the hub by hand at 40 deg: 575 mm of height, 520 mm foot radius.

## Feet

`revD_leg_foot.stl`, print three. Section in `revD_leg_foot_DRAWING.png`.

| | Spec |
|---|---|
| Body | 46 mm cup, 70 tall, flat bottom; 99 cm3, about 125 g in PETG |
| Socket | 12.9 mm x 22 deep, angled 40 deg so the base sits flat with the leg at the hub angle. Entry 7 mm inboard of centre. |
| Pin | 3.4 mm cross hole 12 mm down the socket. Slide the tube in, drill through the hole and the tube, M3 x 20 screw and nut. |
| Ballast pocket | 36 x 26 underneath, 1/4-20 x 1/2 in heat-set insert in its ceiling (7.9 hole, 14 deep). |
| Ballast | 1/4-20 x 1-1/2 in hex bolt up into the insert, head down; the head is the foot. A 2 in bolt is too long for the pocket plus insert. 1-1/4 in fender washers on the bolt fill the pocket at about 135 g. Lead cast or stacked in the pocket is about 300 g. A 150 mm lead slug dropped up the tube before the foot goes on adds about 125 g; the closed socket keeps it there. Screw a 1/4-20 rubber bumper into the insert instead for a floor indoors. |
| Stake ear | Full-height rib on the outboard side with a 9 mm vertical hole: an 8 mm tent stake through it pins the foot. |
| Print | Top face on the bed, no supports: the socket overhang is 50 deg from horizontal and the pocket opens upward. |

## Tip-over, free standing

17 ft whip fully extended, steady wind, no gust factor, 1.7 kg of hardware, 520 mm foot radius. A tripod tips about the line between two feet, so the hardware's lever arm is half the foot radius and only the upwind foot's ballast counts, at one and a half times the radius.

| Ballast per foot | Tips at | What |
|---|---|---|
| 0 g | 12.9 mph | no ballast |
| 135 g | 14.4 mph | 1-1/4 in fender washers filling the pocket |
| 127 g | 14.3 mph | 150 mm lead slug in each tube |
| 299 g | 16.0 mph | lead cast or stacked in the pocket |
| 426 g | 17.1 mph | pocket and tube both |

Ballast buys a few miles an hour. The stakes buy the rest: a staked tripod is limited by the whip, 25 mph before the top sections come down. Stake the ears whenever the forecast is over about 12 mph, or whenever you walk away from it.

Loads: PA12 at 1.8 GPa is 40 times less stiff than aluminum, so the hub flexes a little under the whip; it is thick enough that stress stays under 5 MPa at 30 mph (PA12 yields at 48). Leg inserts in PA12 hold well over 1 kN pull-out, against about 200 N of leg load. Expect the whip to sway more in gusts than it would on a metal hub. Printed in PETG, keep it out of a closed car in summer.
