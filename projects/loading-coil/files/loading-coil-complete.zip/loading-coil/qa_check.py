#!/usr/bin/env python3
"""Re-run the package QA: every STL is a closed printable volume, and the parts fit each other."""
import glob, numpy as np, trimesh
def r_at(m, z, lo, hi):
    v = m.section(plane_origin=[0, 0, z], plane_normal=[0, 0, 1]).vertices
    r = np.hypot(v[:, 0], v[:, 1]); r = r[(r > lo) & (r < hi)]; return r.min(), r.max()
import os
try:
    import cadquery as cq
except ImportError:
    cq = None
ok = True
for f in sorted(glob.glob("*.stl")):
    m = trimesh.load(f)
    g = m.is_watertight and m.is_volume and m.bounds[0][2] > -1e-6
    # inverted faces (phantom shells left by a bad boolean): a point just outside each face must be outside the solid
    if len(m.faces) <= 20000:   # ray test is memory-hungry on the helical forms; the STEP volume check covers those
        inv = int(m.contains(m.triangles_center + m.face_normals * 0.05).sum()); g &= inv == 0
        note = f" inverted_faces={inv}"
    else:
        note = ""
    # volume against the B-rep STEP of the same part, when present (facet error on a helix is under 1%)
    step = f"step/{os.path.splitext(f)[0].replace('_x2', '')}.step"
    if cq is not None and os.path.exists(step):
        dv = 100 * (trimesh.load(f).volume / cq.importers.importStep(step).val().Volume() - 1)
        g &= abs(dv) < 1.0; note += f" vol_vs_step={dv:+.2f}%"
    ok &= g
    print(("PASS " if g else "FAIL ") + f + note)
cap = trimesh.load("endcap_SO239_x2.stl"); fB = trimesh.load("coilform_SO239_18AWG.stl"); fC = trimesh.load("tuner_form_SO239.stl"); sl = trimesh.load("tuner_sleeve_SO239.stl")
capB = trimesh.load("endcap_BNC_x2.stl"); fBb = trimesh.load("coilform_BNC_18AWG.stl")
checks = [
    ("SO-239 cap bore over rev B spigot", r_at(cap, 15, 10, 18)[0] * 2 - r_at(fB, 5, 15, 18)[1] * 2, 0.2, 0.7),
    ("SO-239 cap bore over rev C spigot", r_at(cap, 15, 10, 18)[0] * 2 - r_at(fC, 5, 15, 18)[1] * 2, 0.2, 0.7),
    ("BNC cap bore over BNC spigot", r_at(capB, 15, 8, 15)[0] * 2 - r_at(fBb, 5, 12, 15)[1] * 2, 0.2, 0.7),
    ("sleeve bore over rev C land", r_at(sl, 80, 15, 18)[0] * 2 - r_at(fC, 140, 15, 18)[1] * 2, 0.3, 0.8),
    ("cap face radius minus SO-239 flange corner", r_at(cap, 3, 15, 25)[1] - 17.96, 0.5, 5),
]
for name, val, lo, hi in checks:
    g = lo <= val <= hi; ok &= g; print(f"{'PASS' if g else 'FAIL'} {name}: {val:.2f} mm (expect {lo} to {hi})")
print("\nPACKAGE OK" if ok else "\nPACKAGE HAS FAILURES")

# ---------------- rev D ----------------
if os.path.isdir("revD") and cq is not None:
    import json
    d = json.load(open("revD/revD_dims.json")); fi, hi = d["form"], d["hub"]
    L = lambda n: cq.importers.importStep(f"revD/{n}.step").val()
    for n in ("revD_form", "revD_sleeve_hub", "revD_swivel_cap", "revD_tripod_hub_PRINT", "revD_leg_foot"):
        m = trimesh.load(f"revD/{n}.stl"); s = L(n)
        dv = 100 * (m.volume / s.Volume() - 1); g = m.is_watertight and m.is_volume and abs(dv) < 1.0; ok &= g
        print(f"{'PASS' if g else 'FAIL'} revD/{n}.stl watertight={m.is_watertight} vol_vs_step={dv:+.2f}%")
    fm, hb, sw = L("revD_form"), L("revD_sleeve_hub"), L("revD_swivel_cap")
    inter = lambda a, b: a.intersect(b).Volume()
    cap = sw.translate((0, 0, -17))
    for n, lab in ((0, "form fully in"), (fi["length"] and 79, "form fully out")):
        dz = hi["z_stations"] - (fi["z_first_turn"] + 2.0 * (n + 0.5))
        v1 = inter(fm.translate((0, 0, dz)), hb); v2 = inter(cap.translate((0, 0, dz)), hb); g = v1 < 1e-3 and v2 < 1e-3; ok &= g
        print(f"{'PASS' if g else 'FAIL'} rev D {lab}: form/hub {v1:.2f} mm3, cap/hub {v2:.2f} mm3")
    v = inter(cap, fm); g = v < 1e-3; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D swivel cap on journal: {v:.2f} mm3")
    P = d["params"]; t = P["tripod"]; ti = d["tripod"]
    hubal = L("machined_alt/revD_tripod_hub_ALU").translate((0, 0, hi["z_hub_top"] - ti["height"]))
    v = inter(hubal, hb); g = v < 1e-3; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D housing hanging in the aluminum hub bore: {v:.2f} mm3")
    zss = hi["z_hub_top"] - ti["height"] + ti["z_setscrew"]; groove = hi["height"] - P["setscrew_below_top"]; g = abs(zss - groove) < 0.5; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D set screw on the housing groove: {zss:.1f} vs {groove:.1f}")
    g = ti["wall_to_bore_at_end"] >= 2.0 and ti["wall_to_top_at_end"] >= 2.0; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D leg holes end {ti['wall_to_bore_at_end']} mm from the bore and {ti['wall_to_top_at_end']} mm from the top (2 mm minimum)")
    alu = L("machined_alt/revD_tripod_hub_ALU")
    tube = cq.Workplane("XY").workplane(offset=0.2).circle(hi["od"] / 2 + 1.8).circle(hi["od"] / 2 + 0.2).extrude(t["body_t"] - 0.4).val()
    pct = 100 * tube.intersect(alu).Volume() / tube.Volume(); g = pct > 99.99; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D hub bore wall intact through the body: {pct:.2f}%")
    ring = cq.Workplane("XY").workplane(offset=ti["chamfer_rise"] + 0.2).circle(t["body_dia"] / 2).circle(t["body_dia"] / 2 - 2).extrude(t["body_t"] - ti["chamfer_rise"] - 0.4).val()
    pct = 100 * ring.intersect(alu).Volume() / ring.Volume(); g = pct > 99.99; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D hub outer wall intact: {pct:.2f}%")
    # printed hub variant: same checks against the housing
    tp = P["tripod_print"]; tip = d["tripod_print"]; prt = L("revD_tripod_hub_PRINT")
    v = inter(prt.translate((0, 0, hi["z_hub_top"] - tip["height"])), hb); g = v < 1e-3; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D printed hub: housing in bore {v:.2f} mm3")
    tube = cq.Workplane("XY").workplane(offset=0.2).circle(hi["od"] / 2 + 2.0).circle(hi["od"] / 2 + 0.25).extrude(tp["body_t"] - 0.4).val()
    pct = 100 * tube.intersect(prt).Volume() / tube.Volume(); g = pct > 99.99; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D printed hub bore wall intact: {pct:.2f}%; insert holes end {tip['wall_to_bore_at_end']} mm from the bore, {tip['wall_to_top_at_end']} mm from the top")
    # printed leg foot: pins through every hole, walls around the socket
    import math
    f = P["foot"]; fo = d["foot"]; ft = L("revD_leg_foot"); la = P["tripod_print"]["leg_angle"]
    pin = (cq.Workplane("XY").workplane(offset=0.5).circle(12.7 / 2).extrude(f["socket_len"] - 1.0)
           .rotate((0, 0, 0), (0, 1, 0), 180 - la).translate((-f["socket_offset"], 0, f["height"]))).val()
    v = pin.intersect(ft).Volume(); g = v < 1e-3; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D foot: 1/2 in leg passes down the socket: {v:.2f} mm3 interference")
    for lab, pinw in (("8.5 mm stake through the ear", cq.Workplane("XY").workplane(offset=-1).center(f["od"] / 2 + f["ear_out"] / 2, 0).circle(4.25).extrude(f["height"] + 2).val()),
                      ("35 mm ballast stack into the pocket", cq.Workplane("XY").workplane(offset=0.5).circle(17.5).extrude(f["pocket_depth"] - 1).val()),
                      ("1/4-20 insert hole clear", cq.Workplane("XY").workplane(offset=f["pocket_depth"] + 0.5).circle(f["insert_hole"] / 2 - 0.1).extrude(f["insert_depth"] - 1).val())):
        v = pinw.intersect(ft).Volume(); g = v < 1e-3; ok &= g
        print(f"{'PASS' if g else 'FAIL'} rev D foot: {lab}: {v:.2f} mm3")
    g = fo["socket_to_insert_wall"] >= 2.0 and fo["socket_inner_wall_at_top"] >= 3.0; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D foot walls: {fo['socket_to_insert_wall']} mm socket to insert hole, {fo['socket_inner_wall_at_top']} mm at the socket mouth")
    # hardware lengths against the holes: inserts are 1/2 in (12.7) with 1 mm of melt reservoir; stud shows 12.7 (1-1/2 in, 1 in in the tube); ballast bolt 1-1/2 in
    g = tip["radial_depth"] >= 13.7 and tp["leg_depth"] >= 13.7 and tip["setscrew_wall"] >= 10.5; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D hub inserts fit: 1/4-20 hole {tip['radial_depth']} deep, leg hole {tp['leg_depth']} deep (12.7 insert + 1), set-screw wall {tip['setscrew_wall']} for a 9.5 M5 insert")
    g = f["insert_depth"] >= 13.7 and (38.1 - f["pocket_depth"]) <= f["insert_depth"] - 1.0; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D foot insert hole {f['insert_depth']} deep; 1-1/2 in ballast bolt enters {38.1 - f['pocket_depth']:.1f} mm of it")
    # leg hole axes and the foot socket axis read from the B-rep cylinder faces, not from the parameters
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    from OCP.GeomAbs import GeomAbs_Cylinder
    def axis_angles(shape, r):
        out = set()
        for face in shape.Faces():
            ad = BRepAdaptor_Surface(face.wrapped)
            if ad.GetType() == GeomAbs_Cylinder and abs(ad.Cylinder().Radius() - r) < 0.05:
                out.add(round(math.degrees(math.acos(abs(ad.Cylinder().Axis().Direction().Z()))), 2))
        return out
    a_hub = axis_angles(prt, tp["leg_tap_drill"] / 2); a_foot = axis_angles(ft, f["socket_d"] / 2)
    g = a_hub == {float(la)} and a_foot == {float(la)}; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D leg hole axes {sorted(a_hub)} and foot socket axis {sorted(a_foot)} deg from vertical, both {la}: foot sits flat")
    # the foot sits flat when the leg is at the hub angle: socket axis is at leg_angle from the base normal by construction; check the base is one plane
    bb = ft.BoundingBox(); g = abs(bb.zmin) < 1e-6 and abs(bb.zlen - f["height"]) < 1e-6; ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D foot: flat base at z=0, height {bb.zlen:.2f}")
    g = (hi["height"] - P["whip_bore_depth"]) >= (hi["z_hub_top"] - t["boss_h"]); ok &= g
    print(f"{'PASS' if g else 'FAIL'} rev D whip-base bore lies within the hub boss")
    print("\nPACKAGE OK" if ok else "\nPACKAGE HAS FAILURES")
