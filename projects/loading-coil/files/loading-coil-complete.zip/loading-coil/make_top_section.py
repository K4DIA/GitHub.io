#!/usr/bin/env python3
"""Housing top in the printed hub, half section, rev D. Drawn from revD_dims.json.
Labels live in two columns outside the drawing; leaders are straight and ordered
top to bottom on both sides so none cross."""
import json, sys

D = json.load(open(sys.argv[1]))
P = D["params"]; H = D["hub"]; TP = D["tripod_print"]; C = D["collar"]

S = 5.0                      # px per mm
CX = 700                     # drawing centre x (px)
Z0, Z1 = 186.0, 300.0        # mm window, housing rim is z = 0
W, HT = 1400, 700
TOP = 70                     # px of title space above the window
def X(x): return CX + x * S
def Y(z): return TOP + (Z1 - z) * S

# geometry (mm)
hub_bot = H["z_hub_bottom"]; body_t = P["tripod_print"]["body_t"]; body_r = P["tripod_print"]["body_dia"] / 2
boss_r = P["tripod_print"]["boss_od"] / 2; boss_top = H["z_hub_top"]; body_top = hub_bot + body_t
bore_r = TP["bore"] / 2
ch_rise = TP["chamfer_rise"]; ch_run = (TP["chamfer_face_width"] ** 2 - ch_rise ** 2) ** 0.5
rib_w = P["tripod_print"]["setscrew_rib"]["w"]; rib_out = P["tripod_print"]["setscrew_rib"]["out"]
z_set = hub_bot + TP["z_setscrew"]
h_od = H["od"] / 2; h_bore = H["bore_d"] / 2; h_top = H["height"]
z_thr0 = H["z_thread0"]; z_wb = H["z_whip_bore_bottom"]; whip_r = P["whip"]["base_od"] / 2
ledge = P["nut_ledge"]; nut_af = P["hex_af"] / 2; nut_len = P["nut_len"]
z_nut_top = z_wb - ledge; z_nut_bot = z_nut_top - nut_len
col_r = C["od"] / 2; col_h = C["h"]; col_bore = C["bore"] / 2
z_bus = H["z_bus_hole"]
pitch = P["thread"]["pitch"]; tdep = P["thread"]["depth"]
ins_r = P["tripod_print"]["radial_tap_drill"] / 2; ins_x = -P["tripod_print"]["radial_r"]; ins_depth = P["tripod_print"]["radial_depth"]

HUB = "#a9b6c6"; HUBL = "#8fa0b4"; HSG = "#d9dee5"; HSGL = "#8a929c"; COL = "#d9a06a"; COLL = "#9a6a3c"
BRASS = "#d4b24f"; BRL = "#8a7020"; WHIP = "#4a4a4a"; STEEL = "#9a9a9a"; INK = "#1d1b17"; LEAD = "#444"

o = []
def rect(x0, z0, x1, z1, fill, stroke=None, sw=1.0):
    o.append(f'<rect x="{X(min(x0,x1)):.1f}" y="{Y(max(z0,z1)):.1f}" width="{abs(x1-x0)*S:.1f}" height="{abs(z1-z0)*S:.1f}" fill="{fill}" stroke="{stroke or INK}" stroke-width="{sw}"/>')
def poly(pts, fill, stroke=None, sw=1.0):
    o.append('<polygon points="' + ' '.join(f'{X(x):.1f},{Y(z):.1f}' for x, z in pts) + f'" fill="{fill}" stroke="{stroke or INK}" stroke-width="{sw}"/>')
def line(x0, z0, x1, z1, stroke=INK, sw=1.0, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ''
    o.append(f'<line x1="{X(x0):.1f}" y1="{Y(z0):.1f}" x2="{X(x1):.1f}" y2="{Y(z1):.1f}" stroke="{stroke}" stroke-width="{sw}"{d}/>')

o.append(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {HT}" font-family="Helvetica, Arial, sans-serif" font-size="13" fill="{INK}">')
o.append(f'<rect width="100%" height="100%" fill="#fff"/>')
o.append(f'<text x="24" y="34" font-size="20" font-weight="bold">Housing top in the printed hub, section (rev D)</text>')
o.append(f'<text x="24" y="54" fill="#444">Dimensions in mm, housing rim is z = 0. The housing comes up through the hub from below; the collar screws on from above and carries the load.</text>')

# clip to window
o.append(f'<clipPath id="win"><rect x="{X(-62)}" y="{Y(Z1)}" width="{124*S}" height="{(Z1-Z0)*S}"/></clipPath><g clip-path="url(#win)">')

# hub: body with chamfer seat, boss, rib (right), bore through
for sgn in (1, -1):
    body = [(bore_r*sgn, hub_bot), ((body_r-ch_run)*sgn, hub_bot), (body_r*sgn, hub_bot+ch_rise), (body_r*sgn, body_top), (boss_r*sgn, body_top), (boss_r*sgn, boss_top), (bore_r*sgn, boss_top)]
    poly(body, HUB)
# rib on the right of the boss
rect(boss_r, z_set-rib_w/2, boss_r+rib_out, z_set+rib_w/2, HUB)
fx, fz = -(body_r-ch_run/2), hub_bot+ch_rise/2   # chamfer face centre, for the callout
# ground bolt insert on the top face, left: insert sleeve, bolt, washer + terminals, nut
rect(ins_x-ins_r, body_top-ins_depth, ins_x+ins_r, body_top, "#fff")
rect(ins_x-ins_r+0.4, body_top-12.7, ins_x+ins_r-0.4, body_top, BRASS, BRL)
rect(ins_x-3.2, body_top-12.7, ins_x+3.2, body_top+9.5, STEEL)        # 1/4-20 shank
rect(ins_x-5.5, body_top+0.0, ins_x+5.5, body_top+1.2, STEEL)           # washer
rect(ins_x-6.5, body_top+1.2, ins_x+6.5, body_top+2.0, "#b87333")       # ring terminals
rect(ins_x-6.5, body_top+2.0, ins_x+6.5, body_top+2.8, "#b87333")
rect(ins_x-5.5, body_top+2.8, ins_x+5.5, body_top+4.0, STEEL)           # washer
rect(ins_x-5.5, body_top+4.0, ins_x+5.5, body_top+9.5, STEEL)           # nut
# housing walls (full height of window), thick around the whip bore, thin below the nut pocket
for sgn in (1, -1):
    rect(h_bore*sgn, Z0, h_od*sgn, z_nut_bot, HSG, HSGL)                     # form bore walls
    rect(nut_af*sgn+1.1*sgn, z_nut_bot, h_od*sgn, z_nut_top, HSG, HSGL)      # hex pocket walls
    rect(nut_af*sgn+1.1*sgn, z_nut_top, h_od*sgn, z_wb, HSG, HSGL)           # ledge region
    rect(whip_r*sgn+0.3*sgn, z_wb, h_od*sgn, h_top, HSG, HSGL)               # whip bore walls
# whip bore floor line already by rects; ledge drawn as the step. set-screw groove on the right wall, 1 deep
rect(h_od-1.0, z_set-1.5, h_od, z_set+1.5, "#fff", HSGL)
# bus hole through the right wall
rect(h_bore, z_bus-1.5, h_od, z_bus+1.5, "#fff", HSGL)
# external thread teeth on the housing top (both sides), internal teeth on the collar
def teeth(xw, z0, z1, sgn, out):
    z = z0; pts = []
    while z < z1 - 0.01:
        pts += [(xw*sgn, z), ((xw+out)*sgn, z+pitch/2)]
        z += pitch
    pts.append((xw*sgn, min(z, z1)))
    o.append('<polyline points="' + ' '.join(f'{X(x):.1f},{Y(zz):.1f}' for x, zz in pts) + f'" fill="none" stroke="{INK}" stroke-width="0.9"/>')
for sgn in (1, -1):
    teeth(h_od, z_thr0, h_top, sgn, tdep)
# collar
for sgn in (1, -1):
    rect(col_bore*sgn, boss_top, col_r*sgn, boss_top+col_h, COL, COLL)
    teeth(col_bore, boss_top, boss_top+col_h, sgn, -tdep)
# whip and stud
rect(-whip_r, z_wb, whip_r, Z1+5, WHIP, "#222")
rect(-4.8, z_wb-14, 4.8, z_wb, "#6a6a6a", "#222")
# coupling nut
rect(-nut_af, z_nut_bot, nut_af, z_nut_top, BRASS, BRL)
# inside bolt: shank up into the nut, ring terminal, head
rect(-4.8, z_nut_bot-5, 4.8, z_nut_bot+11, "#c9a53f", BRL)
rect(-9.0, z_nut_bot-1.2, 9.0, z_nut_bot, "#b87333", "#7a4a20")
rect(-7.3, z_nut_bot-5.5, 7.3, z_nut_bot-1.2, BRASS, BRL)
# set screw: M5 insert in the rib, screw through it to the groove
rect(boss_r+rib_out-9.5, z_set-3.2, boss_r+rib_out, z_set+3.2, BRASS, BRL)
rect(h_od-0.8, z_set-2.5, boss_r+rib_out+6, z_set+2.5, STEEL, "#555")
rect(boss_r+rib_out+6, z_set-4, boss_r+rib_out+10, z_set+4, STEEL, "#555")
# centreline
line(0, Z0, 0, Z1, "#777", 0.8, "8 4")
o.append('</g>')

# ---------- labels: two columns, leaders ordered top to bottom so none cross ----------
LX = 395   # right edge of the left column
RX = 1040  # left edge of the right column
def label(side, zt, xt, lines, y_px):
    xpx, ypx = X(xt), Y(zt)
    if side == 'L':
        ax, anchor = LX, 'end'
        o.append(f'<line x1="{ax+8}" y1="{y_px-4}" x2="{xpx:.1f}" y2="{ypx:.1f}" stroke="{LEAD}" stroke-width="0.9"/>')
    else:
        ax, anchor = RX, 'start'
        o.append(f'<line x1="{ax-8}" y1="{y_px-4}" x2="{xpx:.1f}" y2="{ypx:.1f}" stroke="{LEAD}" stroke-width="0.9"/>')
    o.append(f'<circle cx="{xpx:.1f}" cy="{ypx:.1f}" r="2.4" fill="{LEAD}"/>')
    for i, t in enumerate(lines):
        o.append(f'<text x="{ax}" y="{y_px + i*16}" text-anchor="{anchor}">{t}</text>')

# left column, targets descending in z
label('L', boss_top+col_h/2, -col_r, ["printed collar, 52 OD, internal thread at 3 mm pitch:", "screws onto the housing from above and sits on", "the boss face. It carries the housing, whip and form."], Y(297))
label('L', z_wb+17, -(whip_r+0.3), ["whip-base bore, 34 deep: carries the bending.", "The housing wall insulates the whip from the hub."], Y(270))
label('L', body_top+6, ins_x-6.5, ["ground bolt in a 1/4-20 heat-set insert: radials", "and the coax shield on ring terminals under the head"], Y(247))
label('L', fz, fx, ["chamfer seat, 40 deg: the three leg inserts go in", "square to this face, pointing in and up (not in this cut)"], Y(222))
label('L', Z0+8, -h_od, ["housing, OD 40.7, up through the 41 mm hub bore", "from below; 65 mm of bore carries the whip's bending"], Y(200))
# right column
label('R', Z1-6, whip_r, ["whip, 3/8-24 stud, base 16 mm"], Y(296))
label('R', z_set, boss_r+rib_out+8, ["M5 x 16 nylon-tip set screw in an M5 insert through", "the boss rib, into a 1 mm groove: stops rotation only"], Y(272))
label('R', z_nut_top-6, nut_af, ["3/8-24 brass coupling nut, captive in the hex", "pocket; it goes in from the bore before anything else"], Y(248))
label('R', z_nut_bot-3.3, 7.3, ["inside bolt, 3/8-24 x 1/2, ring terminal under its", "head: the bus wire and the lining lead land here"], Y(226))
label('R', z_bus, h_od, ["bus hole, 6 mm below the hub; wire channels run", "outside from the stations to here, inside to the ceiling"], Y(204))
o.append('</svg>')
open(sys.argv[2], 'w', encoding='utf-8').write('\n'.join(o))
print('ok')
