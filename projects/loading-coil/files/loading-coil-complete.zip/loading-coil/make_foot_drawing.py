#!/usr/bin/env python3
"""Rev D printed leg foot, section through the socket axis. Drawn from revD_dims.json.
Dimensions sit outside the part; callouts are in two columns with leaders that do not cross."""
import json, sys, math

D = json.load(open(sys.argv[1]))
F = D["params"]["foot"]; LA = D["params"]["tripod_print"]["leg_angle"]

S = 5.0                   # px per mm
W, HT = 1400, 860
INK = "#1d1b17"; LEAD = "#444"; BODY = "#d6dde8"; BODYL = "#5a6472"; TUBE = "#b9bec6"; STEEL = "#9a9a9a"; BRASS = "#d4b24f"; BRL = "#8a7020"

od, h = F["od"], F["height"]
cx_px, base_px = 700, 600          # body centre x and bottom face y in px
def X(x): return cx_px + x * S     # x in mm from body centre
def Y(z): return base_px - z * S   # z in mm above the bottom face

o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {HT}" font-family="Helvetica, Arial, sans-serif" font-size="13" fill="{INK}">',
     '<rect width="100%" height="100%" fill="#fff"/>',
     '<text x="24" y="34" font-size="20" font-weight="bold">Rev D printed leg foot, section through the socket axis (mm)</text>',
     '<text x="24" y="54" fill="#444">Flat bottom down in use. Print with the top face on the bed, no supports. Inboard side (toward the hub) is to the left.</text>']
def rect(x0, z0, x1, z1, fill, stroke=INK, sw=1.0, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ''
    o.append(f'<rect x="{X(min(x0,x1)):.1f}" y="{Y(max(z0,z1)):.1f}" width="{abs(x1-x0)*S:.1f}" height="{abs(z1-z0)*S:.1f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{d}/>')
def poly(pts, fill, stroke=INK, sw=1.0):
    o.append('<polygon points="' + ' '.join(f'{X(x):.1f},{Y(z):.1f}' for x, z in pts) + f'" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')

# body and ear (ear on the outboard side, right)
r = od / 2
rect(-r, 0, r, h, BODY, BODYL)
ear_x0 = r; ear_x1 = r + F["ear_out"]
rect(ear_x0, 0, ear_x1, h, BODY, BODYL)
# stake hole, vertical through the ear
sx = ear_x0 + F["ear_out"] / 2
rect(sx - F["stake_hole"] / 2, 0, sx + F["stake_hole"] / 2, h, "#fff", BODYL)
# ballast pocket from the bottom, insert hole above it
pr = F["pocket_d"] / 2; pd = F["pocket_depth"]
rect(-pr, 0, pr, pd, "#fff", BODYL)
ir = F["insert_hole"] / 2; idp = F["insert_depth"]
rect(-ir, pd, ir, pd + idp, "#fff", BODYL)
# brass insert in the hole, ballast bolt with washers, head below the bottom face
rect(-ir + 0.3, pd, ir - 0.3, pd + 12.7, BRASS, BRL)
rect(-3.2, -6, 3.2, pd + 12.7, STEEL, "#555")
for i in range(15):
    z = 1.2 + i * 1.6
    rect(-15.8, z, 15.8, z + 1.2, "#c8c8c8", "#777", 0.6)
rect(-5.5, -6, 5.5, -1, STEEL, "#555")   # bolt head (the foot)
# socket, 40 deg, entering the top face 7 mm inboard of centre, 22 deep; tube in it
a = math.radians(LA); ex = -F["socket_offset"]; ez = h
dx, dz = math.cos(a), -math.sin(a)       # down and outboard, into the body
nx, nz = -dz, dx
sr = F["socket_d"] / 2; L = F["socket_len"]
def along(t, n): return (ex + dx * t + nx * n, ez + dz * t + nz * n)
poly([along(0, sr), along(L, sr), along(L, -sr), along(0, -sr)], "#fff", BODYL)
tr = 12.7 / 2
poly([along(-26, tr), along(L - 1, tr), along(L - 1, -tr), along(-26, -tr)], TUBE, "#777")
# cross hole for the M3 pin, 12 along the socket from the entry
ph = along(F["pin_from_entry"], 0)
o.append(f'<circle cx="{X(ph[0]):.1f}" cy="{Y(ph[1]):.1f}" r="{F["pin_hole"]/2*S:.1f}" fill="#fff" stroke="{INK}" stroke-width="1"/>')

# ---------- dimensions, all outside the part ----------
def dim_h(x0, x1, zpx, text, above=True):
    y = zpx
    o.append(f'<line x1="{X(x0):.1f}" y1="{y}" x2="{X(x1):.1f}" y2="{y}" stroke="{INK}" stroke-width="0.9"/>')
    for x, s in ((x0, 1), (x1, -1)):
        o.append(f'<path d="M{X(x):.1f},{y} l{6*s},-3 l0,6 z" fill="{INK}"/>')
    o.append(f'<text x="{(X(x0)+X(x1))/2:.1f}" y="{y - 6 if above else y + 16}" text-anchor="middle">{text}</text>')
def dim_v(z0, z1, xpx, text, left=True):
    x = xpx
    o.append(f'<line x1="{x}" y1="{Y(z0):.1f}" x2="{x}" y2="{Y(z1):.1f}" stroke="{INK}" stroke-width="0.9"/>')
    for z, s in ((z0, -1), (z1, 1)):
        o.append(f'<path d="M{x},{Y(z):.1f} l-3,{6*s} l6,0 z" fill="{INK}"/>')
    ym = (Y(z0) + Y(z1)) / 2
    o.append(f'<text x="{x - 8 if left else x + 8}" y="{ym:.1f}" text-anchor="{"end" if left else "start"}" dominant-baseline="middle">{text}</text>')
def ext(x, z0, z1):  # extension line
    o.append(f'<line x1="{X(x):.1f}" y1="{Y(z0):.1f}" x2="{X(x):.1f}" y2="{Y(z1):.1f}" stroke="#888" stroke-width="0.7"/>')
def exth(x0, x1, z):
    o.append(f'<line x1="{X(x0):.1f}" y1="{Y(z):.1f}" x2="{X(x1):.1f}" y2="{Y(z):.1f}" stroke="#888" stroke-width="0.7"/>')

# below the part: body, pocket, ear, stake
for x in (-r, r, -pr, pr, ear_x1, sx - 4.5, sx + 4.5): ext(x, 0, -6 if abs(x) in (r,) or x == ear_x1 else -3)
for x in (-r, r, ear_x1): ext(x, 0, -34)
dim_h(-pr, pr, Y(-14), f'{F["pocket_d"]:g} ballast pocket', above=False)
dim_h(sx - 4.5, sx + 4.5, Y(-14), f'{F["stake_hole"]:g} stake', above=False)
dim_h(-r, r, Y(-36), f'{od:g} body', above=False)
dim_h(r, ear_x1, Y(-36), f'{F["ear_out"]:g} ear', above=False)
# left of the part: height, pocket depth, insert depth
for z in (0, h): exth(-r, -r - 36, z)
for z in (pd,): exth(-pr, -r - 24, z)
exth(-ir, -r - 12, pd + idp)
dim_v(0, h, X(-r - 34), f'{h:g}')
dim_v(0, pd, X(-r - 22), f'{pd:g}')
dim_v(pd, pd + idp, X(-r - 10), f'{idp:g}')
# right of the part: ear width across the top
exth(ear_x1, ear_x1 + 14, 0)
# top: socket entry offset from centre
for x in (0, ex): ext(x, h, h + 27)
yd = Y(h + 25)
o.append(f'<line x1="{X(ex):.1f}" y1="{yd}" x2="{X(0):.1f}" y2="{yd}" stroke="{INK}" stroke-width="0.9"/>')
o.append(f'<path d="M{X(ex):.1f},{yd} l6,-3 l0,6 z" fill="{INK}"/><path d="M{X(0):.1f},{yd} l-6,-3 l0,6 z" fill="{INK}"/>')
o.append(f'<text x="{X(0)+10:.1f}" y="{yd+4}">{F["socket_offset"]:g} socket entry inboard of centre</text>')
o.append(f'<line x1="{X(0):.1f}" y1="{Y(-9)}" x2="{X(0):.1f}" y2="{Y(h+10)}" stroke="#999" stroke-width="0.7" stroke-dasharray="8 4"/>')

# ---------- callouts, one column on the right, ordered top to bottom with their targets ----------
RX = 1040
def label(xt, zt, lines, ypx):
    xpx, ypt = X(xt), Y(zt)
    o.append(f'<line x1="{RX-8}" y1="{ypx-4}" x2="{xpx:.1f}" y2="{ypt:.1f}" stroke="{LEAD}" stroke-width="0.9"/>')
    o.append(f'<circle cx="{xpx:.1f}" cy="{ypt:.1f}" r="2.4" fill="{LEAD}"/>')
    for i, t in enumerate(lines):
        o.append(f'<text x="{RX}" y="{ypx + i*16}">{t}</text>')
t_top = along(-18, tr)
label(t_top[0], t_top[1], ["1/2 in leg tube, 750 mm, in a", f'{F["socket_d"]:g} x {F["socket_len"]:g} deep socket at {LA:g} deg, so the', "base sits flat with the leg at the hub angle"], 150)
label(ph[0] + F["pin_hole"] / 2, ph[1], [f'{F["pin_hole"]:g} cross hole {F["pin_from_entry"]:g} along the socket: slide the tube', "in, drill through hole and tube, M3 x 20 screw and nut"], 228)
s_fl = along(L, 0)
label(s_fl[0], s_fl[1], ["socket floor is closed: a lead slug dropped up the", "tube before the foot goes on stays where it is"], 300)
label(sx + F["stake_hole"] / 2, h * 0.52, [f'stake ear, {F["ear_out"]:g} out and {F["ear_w"]:g} wide, full height, with a', f'{F["stake_hole"]:g} vertical hole: an 8 mm tent stake through it pins the foot'], 372)
label(ir - 0.3, pd + 7, [f'1/4-20 x 1/2 in heat-set insert, {F["insert_hole"]:g} hole x {idp:g} deep,', "in the pocket ceiling; set at 200 C, square to the face"], 448)
label(15.8, 12, ["1-1/4 in fender washers on the bolt fill the pocket,", "about 135 g; lead cast or stacked in it is about 300 g"], 530)
label(5.5, -3.5, ["1/4-20 x 1-1/2 in hex bolt up into the insert; the head", "is the foot. A rubber bumper screws in instead indoors"], 608)
o.append('</svg>')
open(sys.argv[2], 'w', encoding='utf-8').write('\n'.join(o)); print('ok')
