# Assembly manual generator

Builds `ASSEMBLY-MANUAL.pdf`: every step is a rendered picture of the real STLs with the hardware modelled in place, laid out like a brick-set instruction book, with the parts for the step in a box and a line of text only where a picture cannot carry it.

    npm install three@0.170.0 playwright
    mkdir stl && cp ../revD/*.stl stl/
    python3 gen.py scenes.json steps.json      # scene list and step list
    node render.js scenes.json out             # renders every scene to out/*.png (headless Chromium, three.js)
    python3 build_pages.py                     # manual.html
    node topdf.js                              # ASSEMBLY-MANUAL.pdf, 11 x 8.5 in landscape

Geometry comes from the STLs and the constants at the top of `gen.py` (station angles, insert hole angles, the leg angle, the assembled offsets from `revD/assembly/scene_assembled.json`). Change a dimension in `make_revD.py`, re-export the STLs, update the constant, rebuild.
