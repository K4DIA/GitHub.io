#!/usr/bin/env python3
"""Scene generator for the rev D assembly manual. Writes scenes.json for render.js and steps.json for the page builder."""
import json, math, sys

# ---------------- part library ----------------
C = dict(hub="#8fa3b8", collar="#c98a5a", housing="#d8dee6", form="#e3c89a", cap="#c9d6c0", foot="#b8c4b0",
         brass="#d4b24f", steel="#9aa0a6", copper="#c27a3a", alu="#c8cdd2", nylon="#f2f2ee", whip="#4a4a4a",
         nickel="#c9ccd0", bronze="#b08d57", tin="#d6d9dc", black="#2b2b2b", arrow="#1d1b17", red="#c0392b", ins="#d4b24f")

def stl(file, color, pos=(0, 0, 0), rot=None, name=None, **k):
    d = dict(kind="stl", file=f"/stl/{file}", color=color, pos=list(pos));
    if rot: d["rot"] = rot
    if name: d["name"] = name
    d.update(k); return d
def cyl(r, h, pos=(0, 0, 0), color=C["steel"], rot=None, r2=None, **k):
    d = dict(kind="cyl", r=r, h=h, pos=list(pos), color=color);
    if r2 is not None: d["r2"] = r2
    if rot: d["rot"] = rot
    d.update(k); return d
def tube(ro, ri, h, pos=(0, 0, 0), color=C["alu"], rot=None, **k):
    d = dict(kind="tube", ro=ro, ri=ri, h=h, pos=list(pos), color=color)
    if rot: d["rot"] = rot
    d.update(k); return d
def hexp(af, h, pos=(0, 0, 0), color=C["brass"], rot=None, **k):
    d = dict(kind="hex", af=af, h=h, pos=list(pos), color=color)
    if rot: d["rot"] = rot
    d.update(k); return d
def sphere(r, pos, color=C["brass"], **k): return dict(kind="sphere", r=r, pos=list(pos), color=color, **k)
def box(size, pos=(0, 0, 0), color=C["steel"], rot=None, **k):
    d = dict(kind="box", size=list(size), pos=list(pos), color=color)
    if rot: d["rot"] = rot
    d.update(k); return d
def helix(r, pitch, turns, wr, pos=(0, 0, 0), color=C["bronze"], rot=None, **k):
    d = dict(kind="helix", r=r, pitch=pitch, turns=turns, wr=wr, pos=list(pos), color=color)
    if rot: d["rot"] = rot
    d.update(k); return d
def torus(r, wr, pos=(0, 0, 0), color=C["copper"], rot=None, **k):
    d = dict(kind="torus", r=r, wr=wr, pos=list(pos), color=color)
    if rot: d["rot"] = rot
    d.update(k); return d
def arrow(a, b, color=C["arrow"], shaft=1.0, head=4.0): return dict(kind="arrow", **{"from": list(a), "to": list(b)}, color=color, shaft=shaft, head=head, noframe=True)
def group(parts, pos=(0, 0, 0), rot=None, name=None, **k):
    d = dict(kind="group", parts=parts, pos=list(pos))
    if rot: d["rot"] = rot
    if name: d["name"] = name
    d.update(k); return d

# hardware, each built along +z from z=0 at the origin
def insert(kind):
    r, h = {"1420": (4.0, 12.7), "3816": (5.95, 15.9), "m5": (3.2, 9.5)}[kind]
    return group([cyl(r, h, color=C["brass"]), cyl(r * 0.62, h + 0.2, pos=(0, 0, -0.1), color="#7a6220", edges=False)])
def bolt_1420(L, head="hex"):  # head at z=0 down (head below z=0), shank up
    return group([hexp(11.1, 4.4, pos=(0, 0, -4.4), color=C["steel"]), cyl(3.2, L, color=C["steel"])])
def washer(ro=15.9, ri=3.4, t=1.2, color=C["steel"]): return tube(ro, ri, t, color=color)
def stud_3816(L=38.1): return cyl(4.76, L, color=C["steel"])
def leg_tube(L=750): return tube(6.35, 4.88, L, color=C["alu"])
def m3_screw(L=20): return group([cyl(2.75, 2.0, pos=(0, 0, -2.0), color=C["steel"]), cyl(1.5, L, color=C["steel"])])
def m3_nut(): return hexp(5.5, 2.4, color=C["steel"])
def stake(): return group([cyl(4, 200, color=C["steel"]), cyl(4, 0.01, r2=0.5, pos=(0, 0, -6), color=C["steel"], edges=False), torus(8, 2, pos=(0, 0, 204), color=C["steel"])])
def coupling_nut(): return hexp(14.3, 28.6, color=C["brass"])
def inside_bolt(): return group([hexp(14.3, 4.0, pos=(0, 0, -4.0), color=C["brass"]), cyl(4.76, 12.7, color=C["brass"])])
def ring_terminal(stud=4.8, color=C["copper"]):  # ring in the xy plane at z=0, tab toward +x
    return group([tube(stud + 2.8, stud, 0.8, color=color), box([9, 5, 0.8], pos=(stud + 6.5, 0, 0), color=color), cyl(2.2, 7, pos=(stud + 11, 0, 0.4), rot=[[0, 1, 0, 90]], color=C["red"], edges=False)])
def stem(): return group([tube(3.85, 2.65, 19, color=C["brass"])])
def stem_nut(): return cyl(5.6, 3.0, color=C["brass"])
def ball(): return sphere(1.98, (0, 0, 0), color=C["brass"])
def spring(): return helix(1.5, 1.9, 11, 0.27, color=C["bronze"])
def valve_cap(): return group([cyl(4.6, 9, color=C["nickel"]), cyl(4.6, 1.5, pos=(0, 0, 9), r2=3.5, color=C["nickel"], edges=False)])
def so239(): return group([box([25.4, 25.4, 1.6], pos=(0, 0, 0), color=C["nickel"]), cyl(7.9, 14, pos=(0, 0, 1.6), color=C["nickel"]), cyl(2.0, 6, pos=(0, 0, -6), color=C["brass"], edges=False)])
def pl259(): return group([cyl(9.2, 22, color=C["nickel"]), cyl(3.5, 60, pos=(0, 0, 22), color=C["black"], edges=False)])
def whip_base(L=260): return group([cyl(8.0, L, color=C["whip"]), cyl(4.76, 14, pos=(0, 0, -14), color=C["steel"]), cyl(7.2, 40, pos=(0, 0, L), color=C["whip"], edges=False)])
def set_screw(): return group([cyl(2.5, 16, color=C["steel"]), cyl(2.0, 2.5, pos=(0, 0, -2.5), color=C["nylon"], edges=False)])
def tap(): return group([cyl(3.9, 45, color=C["steel"]), box([6, 6, 12], pos=(0, 0, 45), color=C["steel"])])
def brass_ring(): return tube(12.7, 12.35, 8, color=C["brass"])
def dowel(L=300): return cyl(6.35, L, color="#d9c39a")
def copper_lining(): return tube(17.3, 17.0, 185, color=C["copper"])
def coil(turns=80): return helix(17.12 + 0.51, 2.0, turns, 0.51, color=C["tin"])
def iron(): return group([cyl(0.6, 1, r2=5.5, pos=(0, 0, 0), color="#333", edges=False), cyl(5.5, 30, pos=(0, 0, 1), color="#333", edges=False), cyl(9, 60, pos=(0, 0, 31), color="#222", edges=False)])

# geometry constants (mm), assembled frame: housing rim z = 0
HUB_Z = 204.8; COLLAR_Z = 269.8; FORM_Z = -79.1; CAP_Z = -86.1
HUB_TOP = 29.0; HUB_BOSS_TOP = 65.0; HUB_SET_Z = 55.0; HUB_SET_R = 32.0
TOP_HOLES = [90, 210, 330]; TOP_R = 38.0; TOP_DEPTH = 15.0
LEG_ANGLES = [0, 120, 240]; SEAT_R = 41.5; SEAT_Z = 6.29; LEG_DEPTH = 17.0
STATIONS = [357, 69, 141, 213, 285]; STATION_Z = 10.0; BOSS_FACE_R = 33.0; CHAMBER_R = 24.0
CAP_STATIONS = [0, 180]; CAP_ST_Z = 29.0; CAP_BOSS_R = 28.0; CAP_SCREWS = [90, 270]; CAP_SCREW_Z = 22.0
BUS_ANGLE = 35.0; BUS_Z = 198.8; NUT_Z = 218.2; LINING_Z0, LINING_Z1 = 25.0, 210.0
FOOT_SOCKET_OFF = 7.0; LEG_FROM_VERT = 40.0

def rad(a): return math.radians(a)
def polar(r, a, z): return [r * math.cos(rad(a)), r * math.sin(rad(a)), z]
def radial_rot(a):  # rotate +z axis to point radially outward at angle a (in xy plane)
    return [[0, 1, 0, 90], [0, 0, 1, a]]
def radial_in_rot(a):  # +z pointing inward (toward the axis)
    return [[0, 1, 0, -90], [0, 0, 1, a]]

hub = lambda pos=(0, 0, 0), **k: stl("revD_tripod_hub_PRINT.stl", C["hub"], pos, name="hub", **k)
collar = lambda pos=(0, 0, 0), **k: stl("revD_collar.stl", C["collar"], pos, name="collar", **k)
housing = lambda pos=(0, 0, 0), **k: stl("revD_sleeve_hub.stl", C["housing"], pos, name="housing", **k)
form = lambda pos=(0, 0, 0), **k: stl("revD_form.stl", C["form"], pos, name="form", edges=False, **k)
cap = lambda pos=(0, 0, 0), **k: stl("revD_swivel_cap.stl", C["cap"], pos, name="cap", **k)
# the STL is in its working orientation: pocket opening at z=0, top face (socket entry) at z=70
foot_use = lambda pos=(0, 0, 0), **k: stl("revD_leg_foot.stl", C["foot"], (pos[0], pos[1], pos[2] - 70), name="foot", **k)   # pos = centre of the top face
foot_print = lambda pos=(0, 0, 0), **k: stl("revD_leg_foot.stl", C["foot"], (pos[0], pos[1], pos[2] + 70), rot=[[1, 0, 0, 180]], name="foot", **k)  # pocket up, top face on the bed at z=pos

# leg axis in the hub frame: from the chamfer seat at angle a, pointing in and up at 40 deg from vertical
def leg_axis(a):
    seat = polar(SEAT_R, a, SEAT_Z)
    d = [-math.sin(rad(LEG_FROM_VERT)) * math.cos(rad(a)), -math.sin(rad(LEG_FROM_VERT)) * math.sin(rad(a)), math.cos(rad(LEG_FROM_VERT))]
    return seat, d
def leg_rot(a):  # rotate +z to the leg direction (in and up)
    return [[0, 1, 0, -LEG_FROM_VERT], [0, 0, 1, a]]
def along(p, d, t): return [p[i] + d[i] * t for i in range(3)]

# ---------------- scenes ----------------
scenes = []; steps = []; thumbs = {}
def scene(name, parts, w=1000, h=800, az=-35, el=26, fov=18, pad=1.12, frame=None, center=None, radius=None):
    s = dict(name=name, w=w, h=h, az=az, el=el, fov=fov, pad=pad, parts=parts)
    if radius: s["radius"] = radius
    if frame: s["frame"] = frame
    if center: s["center"] = center
    scenes.append(s); return name
def thumb(key, part, az=-35, el=28, fov=14, pad=1.3, w=300, h=240):
    if key not in thumbs:
        thumbs[key] = scene("thumb_" + key, [part], w=w, h=h, az=az, el=el, fov=fov, pad=pad)
    return "thumb_" + key
def step(num, title, main, parts, insets=None, note=None, span=1, stage=None, checks=None):
    steps.append(dict(num=num, title=title, main=main, parts=parts, insets=insets or [], note=note, span=span, stage=stage, checks=checks))

# part box entries: (thumb key, part dict, count label)
P = {}
P["hub"] = (hub(), "Hub"); P["collar"] = (collar(), "Collar"); P["housing"] = (housing(), "Housing"); P["form"] = (form(), "Coil form"); P["cap"] = (cap(), "Swivel cap")
P["foot"] = (foot_use(pos=(0, 0, 0)), "Leg foot")
P["ins1420"] = (insert("1420"), "1/4-20 insert"); P["ins3816"] = (insert("3816"), "3/8-16 insert"); P["insm5"] = (insert("m5"), "M5 insert")
P["tube"] = (leg_tube(), "1/2 in tube, 750"); P["stud"] = (stud_3816(), "3/8-16 x 1-1/2 stud"); P["m3"] = (m3_screw(), "M3 x 20"); P["m3nut"] = (m3_nut(), "M3 nut")
P["bolt1420"] = (bolt_1420(38.1), "1/4-20 x 1-1/2 bolt"); P["washer"] = (washer(), "1-1/4 in fender washer"); P["stake"] = (stake(), "8 mm tent stake")
P["tap"] = (tap(), ".305-32 tap"); P["lining"] = (copper_lining(), "copper foil tape"); P["cnut"] = (coupling_nut(), "3/8-24 coupling nut"); P["ibolt"] = (inside_bolt(), "3/8-24 x 1/2 bolt")
P["ring38"] = (ring_terminal(4.8), "3/8 ring terminal"); P["ring516"] = (ring_terminal(4.0), "5/16 ring terminal"); P["buswire"] = (cyl(0.6, 120, color=C["red"], edges=False), "18 AWG bus wire")
P["stem"] = (stem(), "brass valve stem, 19"); P["stemnut"] = (stem_nut(), "stem nut"); P["ball"] = (ball(), "5/32 brass ball"); P["spring"] = (spring(), "PB spring 4.0 x 0.55 x 25"); P["vcap"] = (valve_cap(), "metal valve cap")
P["wire"] = (coil(6), "18 AWG bare tinned, 9.5 m"); P["bring"] = (brass_ring(), "K&S 1 in brass ring, 8"); P["so239"] = (so239(), "SO-239"); P["n4"] = (group([cyl(2.4, 1.8, pos=(0, 0, -1.8)), cyl(1.4, 9.5)]), "#4 x 3/8 screw"); P["m3x10"] = (m3_screw(10), "M3 x 10")
P["whip"] = (whip_base(), "CHA SS17 whip"); P["setscrew"] = (set_screw(), "M5 x 16 set screw"); P["gbolt"] = (bolt_1420(19), "1/4-20 x 3/4 bolt"); P["gwasher"] = (washer(6.4, 3.4, 1.0), "1/4 washer"); P["gnut"] = (hexp(11.1, 5.5), "1/4-20 nut")
P["pl259"] = (pl259(), "coax, PL-259"); P["shield"] = (cyl(0.6, 100, color=C["black"], edges=False), "shield wire, 300")
P["dowel"] = (dowel(), "1/2 in dowel"); P["iron"] = (iron(), "iron, 200 C"); P["epoxy"] = (cyl(9, 60, color="#e0e0e0"), "epoxy")
for k, (part, label) in P.items(): thumb(k, part)
def parts(*items): return [dict(thumb="thumb_" + k, label=P[k][1], qty=q) for k, q in items]

# ======================= STAGE 1: hub inserts =======================
# step 1: three 1/4-20 inserts into the top face
ps = [hub()]
for a in TOP_HOLES:
    p = polar(TOP_R, a, HUB_TOP)
    ps.append(group([insert("1420")], pos=(p[0], p[1], HUB_TOP + 22)))
    ps.append(arrow([p[0], p[1], HUB_TOP + 20], [p[0], p[1], HUB_TOP + 2]))
main = scene("s01", ps, az=-30, el=38)
# inset: how an insert is set
ins = []
ins.append(scene("i01a", [box([30, 30, 14], pos=(0, 0, -14), color=C["hub"]), tube(4.0, 3.0, 14.1, pos=(0, 0, -14.05), color="#f8f8f8", edges=False), group([insert("1420")], pos=(0, 0, 1)), group([iron()], pos=(0, 0, 14))], w=360, h=300, az=-30, el=14, fov=16))
ins.append(scene("i01b", [box([30, 30, 14], pos=(0, 0, -14), color=C["hub"]), group([insert("1420")], pos=(0, 0, -7)), group([iron()], pos=(0, 0, 6))], w=360, h=300, az=-30, el=14, fov=16))
ins.append(scene("i01c", [box([30, 30, 14], pos=(0, 0, -14), color=C["hub"]), group([insert("1420")], pos=(0, 0, -12.7)), group([iron()], pos=(0, 0, 40)), arrow([0, 0, 2], [0, 0, 34])], w=360, h=300, az=-30, el=14, fov=16))
step(1, "Top inserts", main, parts(("hub", 1), ("ins1420", 3)), insets=[dict(scenes=ins, labels=["Start it square by hand on the hot tip", "Light pressure only: it sinks in 15 to 20 s", "Stop flush, lift straight up, leave 30 s"])],
     note="Iron at 200 C for PETG or PA12, 240 C for ASA. Check each insert with a bolt: it threads in smoothly and the insert does not turn.", stage="Stage 1: Heat-set inserts")

# step 2: three 3/8-16 inserts in the chamfer face
ps = [hub()]
for a in LEG_ANGLES:
    seat, d = leg_axis(a)
    ps.append(group([insert("3816")], pos=along(seat, d, -34), rot=leg_rot(a)))
    ps.append(arrow(along(seat, d, -30), along(seat, d, -2)))
step(2, "Leg inserts, in the chamfer face", scene("s02", ps, az=-20, el=8), parts(("ins3816", 3)),
     note="Prop the hub on a folded towel so the hole you are working on points straight up. The hole is 17 mm deep and 40 degrees from vertical; set the insert square to the chamfer face. A big insert takes about 30 s.")

# step 3: M5 insert in the rib
ps = [hub()]
p = polar(HUB_SET_R, 0, HUB_SET_Z)
ps.append(group([insert("m5")], pos=polar(HUB_SET_R + 24, 0, HUB_SET_Z), rot=radial_in_rot(0)))
ps.append(arrow(polar(HUB_SET_R + 22, 0, HUB_SET_Z), polar(HUB_SET_R + 2, 0, HUB_SET_Z)))
step(3, "Set-screw insert, in the boss rib", scene("s03", ps, az=20, el=18), parts(("insm5", 1)),
     note="Lay the hub on its side so the rib points up. The hole is 11.4 mm deep for the 9.5 mm insert; drive it flush with the rib face.")

# step 4: feet inserts (foot printed orientation, pocket opening up)
ps = [foot_print()]
ps.append(group([insert("1420")], pos=(0, 0, 70 + 16)))
ps.append(arrow([0, 0, 84], [0, 0, 46]))
step(4, "Foot inserts, three feet", scene("s04", ps, az=-35, el=30), parts(("foot", 3), ("ins1420", 3)),
     note="Each foot sits pocket up, as it was printed. The hole is in the pocket floor, 7.9 x 14. Set the insert flush with the pocket floor.",
     checks="Thread the matching bolt into every insert by hand. Ten inserts, ten checks: it goes in smoothly and the insert does not turn. Chase a tight one with the bolt and a drop of oil; reheat one that turns, with a drop of CA in the hole.")

# ======================= STAGE 2: legs and feet =======================
# step 5: stud into tube
ps = [group([leg_tube(220)], pos=(0, 0, -220)), group([stud_3816()], pos=(0, 0, 40)), arrow([0, 0, 36], [0, 0, 4]),
      tube(6.45, 6.36, 4, pos=(0, 0, -26), color="#e8c84a", edges=False)]
step(5, "Studs into the tubes, cure overnight", scene("s05", ps, az=-35, el=20, fov=16), parts(("tube", 3), ("stud", 3), ("epoxy", 1)),
     note="Cut the tubes to 750 mm and deburr both ends. Rough the first 25 mm inside one end and the whole stud with 220 grit, wipe with alcohol. Tape the stud 1 in (25 mm) from the end as a depth stop, butter it with epoxy, push it in to the tape with a twist. 1/2 in shows. Stand stud up and leave 24 h. Three legs.", stage="Stage 2: Legs and feet")

# step 6: tube into foot, M3 pin  (foot in use: top up; socket entry 7 mm inboard (-x), tube goes up and inboard)
seat = [-FOOT_SOCKET_OFF, 0, 0]
d = [-math.sin(rad(LEG_FROM_VERT)), 0, math.cos(rad(LEG_FROM_VERT))]
ps = [foot_use(pos=(0, 0, 0))]
ps.append(group([leg_tube(170)], pos=along(seat, d, 30), rot=[[0, 1, 0, -LEG_FROM_VERT]]))
ps.append(arrow(along(seat, d, 28), along(seat, d, -8)))
ph = along(seat, d, -12)   # cross hole, 12 mm down the socket
ps.append(group([m3_screw(20)], pos=[ph[0], ph[1] + 26, ph[2]], rot=[[1, 0, 0, 90]]))
ps.append(arrow([ph[0], ph[1] + 24, ph[2]], [ph[0], ph[1] + 9, ph[2]]))
ps.append(group([m3_nut()], pos=[ph[0], ph[1] - 26, ph[2]], rot=[[1, 0, 0, -90]]))
ps.append(arrow([ph[0], ph[1] - 24, ph[2]], [ph[0], ph[1] - 9, ph[2]]))
step(6, "Legs into the feet", scene("s06", ps, az=-55, el=22, fov=16), parts(("m3", 3), ("m3nut", 3)),
     note="Push the plain end of the tube into the socket until it stops, 22 mm in. Drill 3.4 mm through the foot's cross hole and straight through the tube, using the printed hole as the guide. M3 x 20 through, nut on, snug. If you are using a lead slug in the tube, drop it in from the stud end first.")

# step 7: ballast into the pocket
ps = [foot_use(pos=(0, 0, 0))]
stack = [group([bolt_1420(38.1)], pos=(0, 0, 0))]
for i in range(15): stack.append(group([washer()], pos=(0, 0, 0.6 + i * 1.55)))
ps.append(group(stack, pos=(0, 0, -70 - 56)))
ps.append(arrow([0, 0, -70 - 52 + 24], [0, 0, -70 - 2]))
step(7, "Ballast, three feet", scene("s07", ps, az=-35, el=-8, fov=16), parts(("bolt1420", 3), ("washer", 45)),
     note="About 15 washers fill the 26 mm pocket (135 g). Thread the bolt up into the insert and tighten; the bolt head is the foot's contact point. Lead in the pocket is about 300 g instead. Indoors, a 1/4-20 rubber bumper screws into the same insert.")

# ======================= STAGE 3: tapping =======================
ps = [housing(), cap(pos=(90, -20, 0))]
a0 = STATIONS[1]
ps.append(group([tap()], pos=polar(BOSS_FACE_R + 30, a0, STATION_Z), rot=radial_in_rot(a0)))
ps.append(arrow(polar(BOSS_FACE_R + 28, a0, STATION_Z), polar(BOSS_FACE_R + 3, a0, STATION_Z)))
ps.append(group([tap()], pos=[90 + CAP_BOSS_R + 30, -20, CAP_ST_Z], rot=radial_in_rot(0)))
ps.append(arrow([90 + CAP_BOSS_R + 28, -20, CAP_ST_Z], [90 + CAP_BOSS_R + 3, -20, CAP_ST_Z]))
step(8, "Tap the seven station bosses", scene("s08", ps, az=-30, el=14, fov=16, frame=["housing", "cap"]), parts(("housing", 1), ("cap", 1), ("tap", 1)),
     note="Five bosses on the housing rim, two on the swivel cap, each printed with a 7.0 mm bore 10 mm deep. By hand, square to the boss face: half a turn in, a quarter back. Stop when the tap touches the shoulder; the chamber below it is where the ball lives. Thread a valve stem in to check: it bottoms with 8 to 10 mm showing.", stage="Stage 3: Tapping the station bosses")

# ======================= STAGE 4: housing internals =======================
# step 9: copper lining
ps = [housing(opacity=0.32, edges=True), group([copper_lining()], pos=(0, 0, -215)), arrow([0, 0, -26], [0, 0, 20]),
      group([copper_lining()], pos=(0, 0, LINING_Z0), opacity=0.9)]
step(9, "Copper lining in the bore", scene("s09", ps, az=-35, el=16, fov=14, frame=["housing"]), parts(("lining", 1)),
     note="Mark the outside of the housing 25 mm and 210 mm up from the rim; the lining runs between those marks. Five strips of 25 mm tape, 185 mm long, laid in from the rim with a dowel and burnished hard, each overlapping the last by 3 mm. Slit the last strip along the inside wire channel so the channel stays open. The form must still pass with light drag.", stage="Stage 4: The housing")

# step 10: coupling nut assembly, pushed up the bore
nutasm = [group([coupling_nut()], pos=(0, 0, 0)), group([ring_terminal(4.8)], pos=(0, 0, -0.8), rot=[[0, 0, 1, 180]]), group([inside_bolt()], pos=(0, 0, -0.8))]
ins = []
ins.append(scene("i10a", [group([ring_terminal(4.8)], pos=(0, 0, 0)), group([inside_bolt()], pos=(0, 0, -14)), arrow([0, 0, -8], [0, 0, -1.5])], w=360, h=300, az=-35, el=22, fov=16))
ins.append(scene("i10b", [group([coupling_nut()], pos=(0, 0, 0)), group([ring_terminal(4.8)], pos=(0, 0, -18)), group([inside_bolt()], pos=(0, 0, -18.8)), arrow([0, 0, -12], [0, 0, -1.5])], w=360, h=300, az=-35, el=22, fov=16))
ins.append(scene("i10c", nutasm + [cyl(0.6, 60, pos=(15.8, 0, -1), rot=[[0, 1, 0, 70]], color=C["red"], edges=False)], w=360, h=300, az=-35, el=22, fov=16))
ps = [housing(opacity=0.32), group(nutasm + [cyl(0.6, 150, pos=(16, 0, -2), rot=[[0, 1, 0, 160]], color=C["red"], edges=False)], pos=(0, 0, -95)),
      group([dowel(140)], pos=(0, 0, -250)), arrow([0, 0, -80], [0, 0, 60]),
      group([coupling_nut()], pos=(0, 0, NUT_Z), opacity=0.95), group([inside_bolt()], pos=(0, 0, NUT_Z - 0.8), opacity=0.95)]
step(10, "Coupling nut, inside bolt and bus wire", scene("s10", ps, az=-35, el=16, fov=14, frame=["housing"]), parts(("cnut", 1), ("ibolt", 1), ("ring38", 1), ("buswire", 1), ("dowel", 1)),
     insets=[dict(scenes=ins, labels=["Terminal on the bolt", "Bolt into the nut, tight: the terminal is clamped with its tab past the flats", "Bus wire, 1.2 m, soldered into the terminal"])],
     note="Feed the free end of the wire in from the rim and fish it out through the bus hole, 199 mm up at the top of the outside channel. Lay the inside run into the inside channel, then push the nut up the bore with the dowel, hex to hex, until it sits on the ledge 218 mm up. Pull the outside end to take up slack and fix it at the bus hole with a drop of CA. Check: wire end to nut, continuity.")

# step 11: one ball station, exploded along the boss axis, then five
a0 = STATIONS[3]
def station_parts(a, z, face_r, explode=0.0, with_terminal=True):
    """parts of one station along the boss axis at angle a, built outward from the boss face"""
    out = []
    def at(t, part, rot=None):  # t = distance outward from the boss face
        return group([part], pos=polar(face_r + t, a, z), rot=radial_rot(a) if rot is None else rot)
    e = explode
    out.append(at(-10 + 0 * e, group([ball()], pos=(0, 0, 0))))          # ball in the chamber, 10 in from the face (shown exploded separately below)
    return out
def station_exploded(a, z, face_r):
    out = []; e = 1.0
    def at(t, part): return group([part], pos=polar(face_r + t, a, z), rot=radial_rot(a))
    # order outward: ball (into the chamber), stem (threads in 10 mm), spring (down the stem), cap, nut + terminal on the stem
    out.append(at(6, group([ball()])))
    out.append(arrow(polar(face_r + 4, a, z), polar(face_r - 8, a, z)))
    out.append(at(22, group([stem_nut()], pos=(0, 0, 0))))
    out.append(at(22, group([ring_terminal(4.0)], pos=(0, 0, 3.2), rot=[[0, 0, 1, 90]])))
    out.append(at(26, group([stem()], pos=(0, 0, -10))))
    out.append(arrow(polar(face_r + 14, a, z), polar(face_r + 1, a, z)))
    out.append(at(44, group([spring()])))
    out.append(at(70, group([valve_cap()])))
    out.append(arrow(polar(face_r + 68, a, z), polar(face_r + 56, a, z)))
    return out
def station_done(a, z, face_r, terminal_turn=0):
    out = []
    def at(t, part, rot=None): return group([part], pos=polar(face_r + t, a, z), rot=rot or radial_rot(a))
    out.append(at(0, group([tube(3.85, 2.65, 9, color=C["brass"])])))           # exposed stem, 9 mm
    out.append(at(0.4, group([stem_nut()])))
    out.append(at(0.0, group([ring_terminal(4.0)], rot=[[0, 0, 1, 90 + terminal_turn]])))
    out.append(at(3.4, group([valve_cap()])))
    return out
ps = [housing()]
for a in STATIONS:
    if a == a0: ps += station_exploded(a, STATION_Z, BOSS_FACE_R)
    else: ps += station_done(a, STATION_Z, BOSS_FACE_R)
ins = []
sec = []  # section inset of one station: boss block, chamber, parts
ins.append(scene("i11a", [group([stem_nut()], pos=(0, 0, 10)), group([ring_terminal(4.0)], pos=(0, 0, 9), rot=[[0, 0, 1, 90]]), group([stem()], pos=(0, 0, 0)), arrow([0, 0, 28], [0, 0, 15])], w=360, h=300, az=-35, el=20, fov=16))
ins.append(scene("i11b", [box([13, 13, 14], pos=(-6.5, -6.5, -14), rot=[[0, 0, 1, 45]], color=C["housing"]), tube(3.6, 2.2, 10.1, pos=(0, 0, -10), color="#fff", edges=False), group([stem()], pos=(0, 0, -10)), group([stem_nut()], pos=(0, 0, 5)), group([ring_terminal(4.0)], pos=(0, 0, 4.2), rot=[[0, 0, 1, 90]]), group([ball()], pos=(0, 0, 26)), arrow([0, 0, 22], [0, 0, 11])], w=360, h=300, az=-35, el=20, fov=16))
ins.append(scene("i11c", [box([13, 13, 14], pos=(-6.5, -6.5, -14), rot=[[0, 0, 1, 45]], color=C["housing"]), group([stem()], pos=(0, 0, -10)), group([stem_nut()], pos=(0, 0, 5)), group([ring_terminal(4.0)], pos=(0, 0, 4.2), rot=[[0, 0, 1, 90]]), group([spring()], pos=(0, 0, 22)), arrow([0, 0, 20], [0, 0, 11])], w=360, h=300, az=-35, el=20, fov=16))
ins.append(scene("i11d", [box([13, 13, 14], pos=(-6.5, -6.5, -14), rot=[[0, 0, 1, 45]], color=C["housing"]), group([stem()], pos=(0, 0, -10)), group([stem_nut()], pos=(0, 0, 0.4)), group([ring_terminal(4.0)], pos=(0, 0, 0), rot=[[0, 0, 1, 90]]), group([valve_cap()], pos=(0, 0, 3.4)), arrow([0, 0, 26], [0, 0, 14])], w=360, h=300, az=-35, el=20, fov=16))
step(11, "Ball stations, five on the housing", scene("s11", ps, az=-35, el=20, fov=12, center=[0, 0, 14], radius=62), parts(("stem", 5), ("stemnut", 5), ("ring516", 5), ("ball", 5), ("spring", 5), ("vcap", 5)),
     insets=[dict(scenes=ins, labels=["Nut on first, run up loose; ring terminal under it", "Stem in by hand until it stops on the shoulder; drop the ball down the stem", "Spring down the stem onto the ball", "Cap on finger tight until it bottoms; nut down to the boss face, a quarter turn past snug"])],
     note="Work with the boss pointing up so nothing falls out. Nothing is adjusted: the stem bottoms on the shoulder, the cap bottoms on the stem, and that sets the preload. Point each terminal tab along the housing toward the next station. Check every station: push the ball with a toothpick, it springs back.", stage="Stage 5: Ball stations")

# step 12: the two cap stations
ps = [cap()]
ps += station_exploded(180, CAP_ST_Z, CAP_BOSS_R)
ps += station_done(0, CAP_ST_Z, CAP_BOSS_R)
step(12, "Ball stations, two on the swivel cap", scene("s12", ps, az=-35, el=22, fov=14, center=[0, 0, 22], radius=70), parts(("stem", 2), ("stemnut", 2), ("ring516", 2), ("ball", 2), ("spring", 2), ("vcap", 2)),
     note="Same build. These two balls ride on the brass ring of the form journal. Point both terminal tabs toward the side hole in the cap wall.")

# step 13: bus the five stations
ps = [housing()]
for a in STATIONS: ps += station_done(a, STATION_Z, BOSS_FACE_R, terminal_turn=0)
# wire ring through the terminals at the terminal radius, plus the run up the outside channel
ps.append(torus(BOSS_FACE_R + 2.0, 0.6, pos=(0, 0, STATION_Z + 0.0), color=C["red"]))
bp = polar(20.6, BUS_ANGLE, 0)
ps.append(cyl(0.6, BUS_Z - STATION_Z - 2, pos=polar(20.9, BUS_ANGLE, STATION_Z + 1), color=C["red"], edges=False))
step(13, "Bus the five stations", scene("s13", ps, az=-35, el=20, fov=12, center=[0, 0, 40], radius=80), parts(("buswire", 1)),
     note="The bus wire is hanging out of the bus hole. Lay it down the outside channel to the first terminal, 10 mm above the rim, tape it every 50 mm. Loop it round through all five terminal rings, snug against the bosses, back to the first, solder every terminal, cut the surplus. A bead of thin CA along the channel, then pull the tape. Check: each valve cap to the coupling nut, continuity; cap to the copper lining, continuity.")

# ======================= STAGE 5: coil form =======================
ps = [form(), group([coil(80)], pos=(0, 0, 48)), cyl(0.5, 40, pos=(17.3, 0, 10), color=C["tin"], edges=False)]
step(14, "Wind the form", scene("s14", ps, az=-35, el=18, fov=12), parts(("form", 1), ("wire", 1)),
     note="Straighten the wire first. Leave a 150 mm tail down the channel on the outside of the form, through the slot in the grip to the ring band on the journal; tape it there. Stand the form on its journal, channel toward you, and wind: 80 turns at 2.0 mm pitch, 48 mm up to 208 mm, keeping tension and thumbing every turn into the groove. Tape every ten turns. At the top the groove ends at a 2.2 mm hole: cut 25 mm past it, bend 90 degrees, push the end into the hole and leave it. Mark every tenth turn on the land side.", stage="Stage 6: The coil form")

ps = [form(), group([coil(80)], pos=(0, 0, 48)), group([brass_ring()], pos=(0, 0, -40)), arrow([0, 0, -30], [0, 0, 6]), group([brass_ring()], pos=(0, 0, 8), opacity=0.95)]
step(15, "Brass ring over the tail", scene("s15", ps, az=-35, el=-14, fov=12, frame=["form"]), parts(("bring", 1)),
     note="Cut an 8 mm ring from the K&S 1 in tube, deburr. Untape the tail, lay it across the ring band in the channel, push the ring over it into the recess 8 to 16 mm from the journal end. Solder the ring to the tail with the big iron, fast, and cut the tail flush. Check: ring to the top turn, about 0.2 ohm; ring to the journal end, open.")

# ======================= STAGE 6: swivel cap =======================
# cap turned over (floor up) so the SO-239 goes onto the floor
ps = [cap(rot=[[1, 0, 0, 180]], pos=(0, 0, 39))]
ps += [group(p["parts"], pos=p["pos"], rot=[[1, 0, 0, 180]]) for p in []]
ps.append(group([so239()], pos=(0, 0, 39 + 26)))
ps.append(arrow([0, 0, 39 + 22], [0, 0, 39 + 3]))
for i, (sx, sy) in enumerate([(9.1, 9.1), (-9.1, 9.1), (-9.1, -9.1), (9.1, -9.1)]):
    if i == 3: continue  # one screw left out for the shield wire
    ps.append(group([group([cyl(2.4, 1.8, pos=(0, 0, -1.8)), cyl(1.4, 9.5)])], pos=(sx, sy, 39 + 44), rot=[[1, 0, 0, 180]]))
    ps.append(arrow([sx, sy, 39 + 41], [sx, sy, 39 + 29]))
ins = [scene("i16a", [group([so239()], pos=(0, 0, 0)), cyl(0.6, 60, pos=(0, 0, -6), rot=[[0, 1, 0, 170]], color=C["red"], edges=False)], w=360, h=300, az=-35, el=22, fov=16)]
step(16, "SO-239 on the swivel cap floor", scene("s16", ps, az=-35, el=30, fov=16, frame=["cap"]), parts(("so239", 1), ("n4", 4), ("buswire", 1)),
     insets=[dict(scenes=ins, labels=["100 mm of insulated wire soldered to the center-pin tail, heat-shrink over the joint"])],
     note="Turn the cap over. Push the wire up through the connector hole in the floor and out the small side hole between the two stations. Seat the flange on the floor, three #4 screws in, snug not stripped. Leave the fourth hole empty for now; the shield wire goes under that screw at the end. Cut the wire to reach both station terminals with a little slack, strip, solder to both. Check: center pin to each valve cap, continuity; center pin to the shell, open.", stage="Stage 7: The swivel cap")

# step 17: cap onto the journal, retaining screws
ps = [form(), group([coil(80)], pos=(0, 0, 48)), group([brass_ring()], pos=(0, 0, 8)), group([cap(), *station_done(0, CAP_ST_Z, CAP_BOSS_R), *station_done(180, CAP_ST_Z, CAP_BOSS_R), group([so239()], pos=(0, 0, 0), rot=[[1, 0, 0, 180]])], pos=(0, 0, -7 - 60)), arrow([0, 0, -62], [0, 0, -12])]
for a in CAP_SCREWS:
    ps.append(group([m3_screw(10)], pos=polar(20 + 20, a, -7 + CAP_SCREW_Z), rot=radial_in_rot(a)))
    ps.append(arrow(polar(38, a, -7 + CAP_SCREW_Z), polar(22, a, -7 + CAP_SCREW_Z)))
step(17, "Swivel cap onto the journal", scene("s17", ps, az=-35, el=-10, fov=12, frame=["form"]), parts(("m3x10", 2)),
     note="Slide the cap over the journal end, open end first, until the two balls click onto the brass ring; the cap floor is now about 10 mm below the journal end. The retaining screw holes are 90 degrees from the stations: thread an M3 x 10 into each until its tip touches the groove floor, then a quarter turn back. The cap cannot come off and the form spins in it. Check: spin it, no catch; center pin to the top turn, about 0.5 ohm, steady through a full turn.")

# ======================= STAGE 7: final assembly =======================
def foot_at(seat, d, a, t):
    """foot whose socket entry sits at along(seat, d, t); its inboard side faces the hub"""
    e = along(seat, d, t)
    return group([foot_use()], pos=[e[0] + FOOT_SOCKET_OFF * math.cos(rad(a)), e[1] + FOOT_SOCKET_OFF * math.sin(rad(a)), e[2]], rot=[[0, 0, 1, a]])
def tripod_parts(z_hub=HUB_Z, legs=True, feet=True):
    out = [hub(pos=(0, 0, z_hub))]
    if legs:
        for a in LEG_ANGLES:
            seat, d = leg_axis(a); seat = [seat[0], seat[1], seat[2] + z_hub]
            out.append(group([leg_tube(750), group([stud_3816()], pos=(0, 0, 750))], pos=along(seat, d, -750), rot=leg_rot(a)))
            if feet: out.append(foot_at(seat, d, a, -750 + 22))
    return out
# step 18: legs into the hub (hub at bench height; legs shown with feet)
ps = [hub(pos=(0, 0, HUB_Z))]
for a in LEG_ANGLES:
    seat, d = leg_axis(a); seat = [seat[0], seat[1], seat[2] + HUB_Z]
    ps.append(group([leg_tube(750), group([stud_3816()], pos=(0, 0, 750))], pos=along(seat, d, -750 - 140), rot=leg_rot(a)))
    ps.append(foot_at(seat, d, a, -750 + 22 - 140))
    ps.append(arrow(along(seat, d, -136), along(seat, d, -6), shaft=2.0, head=9))
step(18, "Legs into the hub", scene("s18", ps, az=-35, el=16, fov=14), parts(("hub", 1)),
     note="Screw each leg in by hand until the tube shoulder seats on the chamfer face. Hand tight only; the inserts are in plastic. Stand it up: all three feet flat, hub level. A rocking foot means that leg is not seated.", stage="Stage 8: Final assembly")

# step 19: housing up through the hub
ps = tripod_parts()
hs = [housing()]
for a in STATIONS: hs += station_done(a, STATION_Z, BOSS_FACE_R)
ps.append(group(hs, pos=(0, 0, -150)))
ps.append(arrow([0, 0, -150 + 300], [0, 0, 130]))
step(19, "Housing up through the hub, from below", scene("s19", ps, az=-35, el=12, fov=14, frame=["hub", "housing"]), parts(("housing", 1)),
     note="From below, between the legs, push the housing threaded end first up through the hub bore until the thread stands clear above the boss face. Hold it there for the next step.")

# step 20: collar on
ps = tripod_parts(); hs = [housing()]
for a in STATIONS: hs += station_done(a, STATION_Z, BOSS_FACE_R)
ps += hs
ps.append(group([collar()], pos=(0, 0, COLLAR_Z + 70)))
ps.append(arrow([0, 0, COLLAR_Z + 64], [0, 0, COLLAR_Z + 16]))
step(20, "Collar on from above", scene("s20", ps, az=-35, el=18, fov=10, frame=["hub", "collar"]), parts(("collar", 1)),
     note="Screw the collar onto the housing clockwise until it seats on the boss face. Let go of the housing: the collar is carrying it now. Hand tight; the flutes are the grip. Turn housing and collar together so the outside wire channel faces away from where you stand to tune.")

# step 21: set screw
ps = tripod_parts() + hs + [collar(pos=(0, 0, COLLAR_Z))]
ps.append(group([set_screw()], pos=polar(HUB_SET_R + 30, 0, HUB_Z + HUB_SET_Z), rot=radial_in_rot(0)))
ps.append(arrow(polar(HUB_SET_R + 26, 0, HUB_Z + HUB_SET_Z), polar(HUB_SET_R + 4, 0, HUB_Z + HUB_SET_Z)))
step(21, "Set screw", scene("s21", ps, az=25, el=16, fov=8, frame=["hub", "collar"]), parts(("setscrew", 1)),
     note="Thread the M5 x 16 nylon-tip set screw into the rib insert until it touches the housing, then a quarter turn more. It only stops rotation. If you cannot feel it touch, turn the housing a few degrees: the groove is 10 mm below the boss face and the screw must land in it.")

# step 22: form up into the housing
ps = tripod_parts() + hs + [collar(pos=(0, 0, COLLAR_Z))]
fa = [form(), group([coil(80)], pos=(0, 0, 48)), group([brass_ring()], pos=(0, 0, 8)), group([cap(), *station_done(0, CAP_ST_Z, CAP_BOSS_R), *station_done(180, CAP_ST_Z, CAP_BOSS_R), group([so239()], pos=(0, 0, 0), rot=[[1, 0, 0, 180]])], pos=(0, 0, -7))]
ps.append(group(fa, pos=(0, 0, FORM_Z - 190)))
ps.append(arrow([0, 0, FORM_Z - 190 + 255], [0, 0, 40]))
step(22, "Form up into the housing, then twist", scene("s22", ps, az=-35, el=10, fov=14, frame=["hub", "housing", "form"]), parts(),
     note="From below, offer the form up land first (the end without the grip). Push until the land meets the five balls; a firm push clicks it past them. Keep pushing until the first groove reaches the balls: they click into the valley and the form now wants to turn. Twist the grip clockwise as seen from below. One revolution is one turn and the form rises 2 mm. Twist until one turn shows below the rim: the form is fully in. Nothing in this joint needs force.")

# step 23: whip
ps = tripod_parts() + hs + [collar(pos=(0, 0, COLLAR_Z))] + [group(fa, pos=(0, 0, FORM_Z))]
ps.append(group([whip_base(200)], pos=(0, 0, 283.8 + 90)))
ps.append(arrow([0, 0, 283.8 + 84], [0, 0, 283.8 + 6]))
step(23, "Whip into the top", scene("s23", ps, az=-35, el=16, fov=10, frame=["hub", "collar"]), parts(("whip", 1)),
     note="Push the whip's base section into the bore at the top of the housing. It goes in 34 mm and stops on the ledge; the stud passes through into the coupling nut. Turn the whip to thread the stud into the nut, tight by hand. The stud carries nothing but its own tension; the bore carries the bending.")

# step 24: ground bolt, radials, shield wire
ps = tripod_parts() + hs + [collar(pos=(0, 0, COLLAR_Z))] + [group(fa, pos=(0, 0, FORM_Z))] + [group([whip_base(200)], pos=(0, 0, 283.8))]
ga = TOP_HOLES[0]; gp = polar(TOP_R, ga, HUB_Z + HUB_TOP)
gstack = [group([bolt_1420(19)], pos=(0, 0, 4.4)), group([washer(6.4, 3.4, 1.0)], pos=(0, 0, 3.2)), group([ring_terminal(3.4)], pos=(0, 0, 2.4), rot=[[0, 0, 1, 20]]), group([ring_terminal(3.4)], pos=(0, 0, 1.6), rot=[[0, 0, 1, 70]]), group([ring_terminal(3.4)], pos=(0, 0, 0.8), rot=[[0, 0, 1, 120]]), group([ring_terminal(3.4)], pos=(0, 0, 0.0), rot=[[0, 0, 1, 170]]), group([ring_terminal(3.4, color=C["black"])], pos=(0, 0, -0.8), rot=[[0, 0, 1, 230]])]
ps.append(group(gstack, pos=(gp[0], gp[1], gp[2] + 40)))
ps.append(arrow([gp[0], gp[1], gp[2] + 36], [gp[0], gp[1], gp[2] + 4]))
step(24, "Ground bolt: radials and the shield wire", scene("s24", ps, az=60, el=30, fov=8, frame=["hub"]), parts(("gbolt", 1), ("gwasher", 1), ("ring38", 5), ("shield", 1)),
     note="Into one of the three top inserts: ring terminals of the four to eight radials and the shield wire, then the washer, then the bolt head. The shield wire's other end goes under the SO-239 screw you left out on the swivel cap, 300 mm of 18 AWG so the form has room to travel. That ties the coax shield to the radials; without it the shield's only ground is the coax itself. Spread the radials on the ground, then coax onto the SO-239.")

# step 25: coax
ps = tripod_parts() + hs + [collar(pos=(0, 0, COLLAR_Z))] + [group(fa, pos=(0, 0, FORM_Z))] + [group([whip_base(200)], pos=(0, 0, 283.8))]
ps.append(group([pl259()], pos=(0, 0, FORM_Z - 7 - 1.6 - 14 - 60), rot=[[1, 0, 0, 180]]))
ps.append(arrow([0, 0, FORM_Z - 7 - 1.6 - 14 - 54], [0, 0, FORM_Z - 7 - 1.6 - 14 - 4]))
step(25, "Coax", scene("s25", ps, az=-35, el=-6, fov=10, frame=["form", "cap"]), parts(("pl259", 1)),
     note="PL-259 onto the SO-239 under the swivel cap. The coax hangs still while the form turns. Then the electrical checks on the next page, before any power.")

# finished model
ps = tripod_parts() + hs + [collar(pos=(0, 0, COLLAR_Z))] + [group(fa, pos=(0, 0, FORM_Z))] + [group([whip_base(300)], pos=(0, 0, 283.8))]
scene("final", ps, w=900, h=1300, az=-35, el=14, fov=14)

json.dump(dict(scenes=scenes), open(sys.argv[1], "w"), indent=0)
json.dump(dict(steps=steps), open(sys.argv[2], "w"), indent=1)
print(len(scenes), "scenes,", len(steps), "steps")
