const {chromium}=require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();
await pg.goto('file://'+path.join(__dirname,'manual.html'),{waitUntil:'load'});
await pg.pdf({path:path.join(__dirname,'ASSEMBLY-MANUAL.pdf'),width:'11in',height:'8.5in',printBackground:true,preferCSSPageSize:true});
await b.close();})();
