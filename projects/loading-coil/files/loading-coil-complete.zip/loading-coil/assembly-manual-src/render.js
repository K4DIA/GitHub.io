// Step renderer: node render.js scenes.json outdir
// Each scene: {name, w, h, az, el, fov, pad, frame:[names]|null, parts:[...]}
// Part kinds: stl, cyl, hex, sphere, box, helix, torus, arrow, text3d(none)
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const [,, specFile, outDir] = process.argv;
const spec = JSON.parse(fs.readFileSync(specFile, 'utf8'));
fs.mkdirSync(outDir, { recursive: true });
const ROOT = __dirname;
const types = { '.js': 'text/javascript', '.stl': 'application/octet-stream', '.html': 'text/html', '.json': 'application/json' };
const srv = http.createServer((q, r) => {
  const u = decodeURIComponent(q.url.split('?')[0]);
  const f = path.join(ROOT, u);
  fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); r.end(); } else { r.writeHead(200, { 'content-type': types[path.extname(f)] || 'application/octet-stream' }); r.end(d); } });
}).listen(8899);

const PAGE = `<!doctype html><html><body style="margin:0;background:transparent">
<canvas id="c"></canvas>
<script type="importmap">{"imports":{"three":"/node_modules/three/build/three.module.js"}}</script>
<script type="module">
import * as THREE from '/node_modules/three/build/three.module.js';
import { STLLoader } from '/node_modules/three/examples/jsm/loaders/STLLoader.js';
const cache = {};
async function loadSTL(f) {
  if (!cache[f]) cache[f] = await new Promise((res, rej) => new STLLoader().load(f, g => res(g), undefined, rej));
  return cache[f];
}
function mat(color, opts = {}) {
  return new THREE.MeshStandardMaterial({ color, flatShading: false, metalness: opts.metal || 0.05, roughness: opts.rough ?? 0.75, transparent: !!opts.opacity, opacity: opts.opacity ?? 1, side: THREE.DoubleSide });
}
function edges(geom, mesh, color = '#1d1b17', thr = 28) {
  const eg = new THREE.EdgesGeometry(geom, thr);
  const l = new THREE.LineSegments(eg, new THREE.LineBasicMaterial({ color, linewidth: 1 }));
  mesh.add(l);
}
function applyTransform(obj, p) {
  if (p.rot) for (const [ax, ay, az, deg] of p.rot) obj.rotateOnWorldAxis(new THREE.Vector3(ax, ay, az).normalize(), deg * Math.PI / 180);
  if (p.pos) obj.position.set(p.pos[0], p.pos[1], p.pos[2]);
}
function zUp(geom) { return geom; } // our primitives are built along +Z directly
function cyl(r1, r2, h, seg = 48) { const g = new THREE.CylinderGeometry(r1, r2, h, seg, 1, false); g.rotateX(Math.PI / 2); g.translate(0, 0, h / 2); return g; }
function hexp(af, h) { const g = new THREE.CylinderGeometry(af / Math.sqrt(3), af / Math.sqrt(3), h, 6, 1, false); g.rotateX(Math.PI / 2); g.translate(0, 0, h / 2); return g; }
function tube(ro, ri, h, seg = 48) { // hollow tube along z
  const shape = new THREE.Shape(); shape.absarc(0, 0, ro, 0, Math.PI * 2, false);
  const hole = new THREE.Path(); hole.absarc(0, 0, ri, 0, Math.PI * 2, true); shape.holes.push(hole);
  const g = new THREE.ExtrudeGeometry(shape, { depth: h, bevelEnabled: false, curveSegments: seg }); return g;
}
function helix(r, pitch, turns, wr, z0 = 0) {
  const pts = []; const n = Math.max(8, Math.round(turns * 24));
  for (let i = 0; i <= n; i++) { const t = i / n * turns; pts.push(new THREE.Vector3(r * Math.cos(t * 2 * Math.PI), r * Math.sin(t * 2 * Math.PI), z0 + t * pitch)); }
  const curve = new THREE.CatmullRomCurve3(pts);
  return new THREE.TubeGeometry(curve, n, wr, 8, false);
}
function arrow(from, to, color, shaft = 1.2, head = 4) {
  const g = new THREE.Group();
  const a = new THREE.Vector3(...from), b = new THREE.Vector3(...to); const d = b.clone().sub(a); const L = d.length();
  const m = new THREE.MeshBasicMaterial({ color });
  const sh = new THREE.Mesh(cyl(shaft, shaft, Math.max(0.1, L - head), 16), m);
  const hd = new THREE.Mesh(cyl(head * 0.9, 0.01, head, 24), m); hd.position.z = L - head;
  g.add(sh); g.add(hd);
  g.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), d.clone().normalize()); g.position.copy(a);
  return g;
}
async function build(scene, p, frameList) {
  let obj, geom;
  const color = p.color || '#cfd4da';
  switch (p.kind) {
    case 'stl': geom = (await loadSTL(p.file)).clone(); obj = new THREE.Mesh(geom, mat(color, p)); if (p.edges !== false && geom.attributes.position.count < 400000) edges(geom, obj, p.edgeColor, p.thr); break;
    case 'cyl': geom = cyl(p.r, p.r2 ?? p.r, p.h, p.seg || 48); obj = new THREE.Mesh(geom, mat(color, p)); if (p.edges !== false) edges(geom, obj, p.edgeColor, p.thr ?? 40); break;
    case 'tube': geom = tube(p.ro, p.ri, p.h); obj = new THREE.Mesh(geom, mat(color, p)); if (p.edges !== false) edges(geom, obj, p.edgeColor, 40); break;
    case 'hex': geom = hexp(p.af, p.h); obj = new THREE.Mesh(geom, mat(color, p)); edges(geom, obj, p.edgeColor, 20); break;
    case 'sphere': geom = new THREE.SphereGeometry(p.r, 32, 24); obj = new THREE.Mesh(geom, mat(color, { ...p, rough: 0.35, metal: 0.3 })); break;
    case 'box': geom = new THREE.BoxGeometry(p.size[0], p.size[1], p.size[2]); geom.translate(0, 0, p.size[2] / 2); obj = new THREE.Mesh(geom, mat(color, p)); edges(geom, obj, p.edgeColor, 20); break;
    case 'helix': geom = helix(p.r, p.pitch, p.turns, p.wr, 0); obj = new THREE.Mesh(geom, mat(color, { ...p, rough: 0.4, metal: 0.4 })); break;
    case 'torus': geom = new THREE.TorusGeometry(p.r, p.wr, 12, 48); obj = new THREE.Mesh(geom, mat(color, p)); break;
    case 'arrow': obj = arrow(p.from, p.to, color, p.shaft, p.head); break;
    case 'group': obj = new THREE.Group(); for (const c of p.parts) obj.add(await build(scene, c, null)); break;
    default: throw new Error('kind ' + p.kind);
  }
  applyTransform(obj, p);
  if (p.name) obj.name = p.name;
  if (p.noframe) obj.userData.noframe = true;
  return obj;
}
window.renderScene = async function (s) {
  const canvas = document.getElementById('c'); canvas.width = s.w; canvas.height = s.h;
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(1); renderer.setSize(s.w, s.h, false); renderer.setClearColor(0x000000, 0);
  const scene = new THREE.Scene();
  scene.add(new THREE.HemisphereLight(0xffffff, 0x8a8f96, 1.1));
  const dl = new THREE.DirectionalLight(0xffffff, 1.4); dl.position.set(-60, -90, 140); scene.add(dl);
  const dl2 = new THREE.DirectionalLight(0xffffff, 0.45); dl2.position.set(90, 60, 40); scene.add(dl2);
  const root = new THREE.Group(); scene.add(root);
  for (const p of s.parts) root.add(await build(scene, p));
  // frame
  root.updateMatrixWorld(true);
  const box = new THREE.Box3();
  root.traverse(o => { if (o.isMesh && !o.parent?.userData?.noframe && !o.userData.noframe) { const b = new THREE.Box3().setFromObject(o); if (o.parent && o.parent.userData.noframe) return; box.union(b); } });
  if (s.frame) { box.makeEmpty(); root.traverse(o => { if (s.frame.includes(o.name)) box.union(new THREE.Box3().setFromObject(o)); }); }
  const size = box.getSize(new THREE.Vector3()), ctr = box.getCenter(new THREE.Vector3());
  if (s.center) ctr.set(...s.center);
  const az = (s.az ?? -35) * Math.PI / 180, el = (s.el ?? 26) * Math.PI / 180, fov = s.fov ?? 20;
  const dir = new THREE.Vector3(Math.cos(el) * Math.sin(az), -Math.cos(el) * Math.cos(az), Math.sin(el));
  const radius = s.radius ?? (Math.max(size.x, size.y, size.z) * 0.62 * (s.pad ?? 1.15));
  const dist = radius / Math.tan(fov / 2 * Math.PI / 180) / Math.min(1, s.w / s.h);
  const cam = new THREE.PerspectiveCamera(fov, s.w / s.h, 1, 20000); cam.up.set(0, 0, 1);
  cam.position.copy(ctr.clone().add(dir.multiplyScalar(dist))); cam.lookAt(ctr); cam.updateProjectionMatrix();
  renderer.render(scene, cam);
  return canvas.toDataURL('image/png');
};
window.ready = true;
</script></body></html>`;
fs.writeFileSync(path.join(ROOT, 'page.html'), PAGE);

(async () => {
  const b = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist'] });
  const pg = await b.newPage({ viewport: { width: 1200, height: 1200 } });
  pg.on('pageerror', e => console.log('pageerror', e.message));
  await pg.goto('http://localhost:8899/page.html');
  await pg.waitForFunction(() => window.ready);
  for (const s of spec.scenes) {
    const t0 = Date.now();
    const data = await pg.evaluate(async sc => await window.renderScene(sc), s);
    fs.writeFileSync(path.join(outDir, s.name + '.png'), Buffer.from(data.split(',')[1], 'base64'));
    console.log(s.name, (Date.now() - t0) + 'ms');
  }
  await b.close(); srv.close();
})();
