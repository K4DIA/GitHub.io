#!/usr/bin/env python3
"""Lay out the manual as HTML (LEGO-style pages) from steps.json and the renders, then print to PDF."""
import json, base64, sys, os, csv
steps = json.load(open("steps.json"))["steps"]
OUT = "out"
def img(name):
    p = os.path.join(OUT, name + ".png")
    return "data:image/png;base64," + base64.b64encode(open(p, "rb").read()).decode()

CSS = """
@page { size: 11in 8.5in; margin: 0; }
* { box-sizing: border-box; }
body { margin: 0; font-family: Helvetica, Arial, sans-serif; color: #fff; }
.page { width: 11in; height: 8.5in; background: #8d9399; position: relative; overflow: hidden; page-break-after: always; padding: 0.32in 0.38in 0.34in; }
.page:last-child { page-break-after: auto; }
.hdr { position: absolute; top: 0.18in; left: 0.38in; font-size: 9.5px; letter-spacing: .16em; text-transform: uppercase; color: #e6e9ec; }
.pno { position: absolute; bottom: 0.16in; right: 0.38in; font-size: 10px; color: #e6e9ec; }
.brand { position: absolute; bottom: 0.16in; left: 0.38in; font-size: 10px; color: #e6e9ec; letter-spacing: .12em; }
.cols { display: grid; grid-template-columns: 1fr 1fr; gap: 0.3in; height: 100%; }
.cols.one { grid-template-columns: 1fr; }
.panel { position: relative; height: 100%; border: 1px solid rgba(255,255,255,.35); border-radius: 10px; padding: 12px 14px; display: flex; flex-direction: column; }
.pbox { display: inline-flex; gap: 10px; flex-wrap: wrap; border: 2px solid #e9ecef; border-radius: 8px; padding: 6px 10px; background: #969ca2; max-width: 100%; min-height: 60px; align-items: flex-end; }
.pbox .pi { text-align: center; }
.pbox img { height: 54px; display: block; margin: 0 auto; }
.pbox .q { font-size: 12px; font-weight: 700; color: #fff; margin-top: 1px; }
.pbox .l { font-size: 8.5px; color: #eef1f3; max-width: 90px; line-height: 1.15; }
.num { font-size: 34px; font-weight: 700; color: #f5f6f7; margin: 8px 0 0 2px; line-height: 1; }
.title { font-size: 12px; color: #eef1f3; margin: 4px 0 0 3px; }
.main { flex: 1; position: relative; min-height: 0; margin: 6px 0; }
.main img { position: absolute; inset: 0; margin: auto; max-width: 100%; max-height: 100%; }
.top { display: flex; gap: 12px; align-items: flex-start; justify-content: space-between; }
.inset { background: #fff; border: 1px solid #1d1b17; border-radius: 4px; padding: 8px 10px 6px; display: flex; gap: 10px; color: #1d1b17; max-width: 62%; }
.inset .sub { text-align: center; width: 130px; }
.inset .sub img { width: 120px; height: 100px; object-fit: contain; display: block; margin: 0 auto; }
.inset .sub b { display: block; text-align: left; font-size: 12px; margin-bottom: 2px; }
.inset .sub span { font-size: 8.5px; line-height: 1.2; display: block; }
.inset.wide { max-width: 70%; }
.note { font-size: 10.5px; line-height: 1.4; color: #f3f5f6; border-top: 1px solid rgba(255,255,255,.35); padding-top: 6px; margin-top: 2px; }
.check { font-size: 10.5px; line-height: 1.4; color: #1d1b17; background: #e9ecef; border-radius: 6px; padding: 6px 10px; margin-top: 6px; }
.check b { color: #1d1b17; }
h1 { font-size: 30px; margin: 0 0 6px; font-weight: 700; }
h2 { font-size: 18px; margin: 0 0 10px; font-weight: 700; }
p { font-size: 11px; line-height: 1.45; margin: 0 0 8px; max-width: 7.6in; }
table { border-collapse: collapse; font-size: 9.6px; width: 100%; color: #fff; }
th, td { text-align: left; padding: 4px 7px; border-bottom: 1px solid rgba(255,255,255,.3); vertical-align: top; }
th { font-weight: 700; border-bottom: 2px solid #e9ecef; }
.cover { display: grid; grid-template-columns: 1.1fr 1fr; gap: .4in; height: 100%; align-items: center; }
.cover img { max-height: 7.3in; max-width: 100%; display: block; margin: 0 auto; }
.inv { display: grid; grid-template-columns: repeat(8, 1fr); gap: 8px 10px; }
.inv .pi { text-align: center; border: 1px solid rgba(255,255,255,.4); border-radius: 6px; padding: 6px 4px; }
.inv .pi img { height: 62px; display: block; margin: 0 auto; }
.inv .q { font-size: 13px; font-weight: 700; }
.inv .l { font-size: 8.5px; line-height: 1.15; color: #eef1f3; }
.two { display: grid; grid-template-columns: 1fr 1fr; gap: .35in; }
.small { font-size: 9.5px; }
"""
H = ['<!doctype html><html><head><meta charset="utf-8"><style>' + CSS + '</style></head><body>']
pageno = [0]
def page_open(stage=None):
    pageno[0] += 1
    H.append('<div class="page">')
    H.append(f'<div class="hdr">{stage or ""}</div>')
def page_close():
    H.append(f'<div class="brand">K4DIA &middot; REV D TRIPOD-HUB LOADING COIL</div><div class="pno">{pageno[0]}</div></div>')

def partbox(parts):
    if not parts: return '<div class="pbox" style="opacity:.0;min-height:40px"></div>'
    s = '<div class="pbox">'
    for p in parts:
        s += f'<div class="pi"><img src="{img(p["thumb"])}"><div class="q">{p["qty"]}x</div><div class="l">{p["label"]}</div></div>'
    return s + '</div>'
def panel(st):
    s = '<div class="panel"><div class="top">'
    s += partbox(st["parts"])
    for ins in st["insets"]:
        s += '<div class="inset' + (' wide' if len(ins["scenes"]) > 3 else '') + '">'
        for i, (sc, lab) in enumerate(zip(ins["scenes"], ins["labels"])):
            s += f'<div class="sub"><b>{i+1}</b><img src="{img(sc)}"><span>{lab}</span></div>'
        s += '</div>'
    s += '</div>'
    s += f'<div class="num">{st["num"]}</div><div class="title">{st["title"]}</div>'
    s += f'<div class="main"><img src="{img(st["main"])}"></div>'
    if st.get("note"): s += f'<div class="note">{st["note"]}</div>'
    if st.get("checks"): s += f'<div class="check"><b>Check.</b> {st["checks"]}</div>'
    return s + '</div>'

# ---------------- cover ----------------
page_open()
H.append('<div class="cover"><div>')
H.append('<p style="font-size:11px;letter-spacing:.18em;text-transform:uppercase">K4DIA</p>')
H.append('<h1>Rev D tripod-hub loading coil</h1><h2 style="font-weight:400">Assembly manual</h2>')
H.append('<p>Eight printed parts, three aluminium legs and a bag of hardware to a tuned 80 through 30 m antenna on a 17 ft whip. Each step shows the parts it needs in the box, and the picture shows where they go. The short text under a picture is there when a picture cannot say it: a temperature, a torque, a thing to measure.</p>')
H.append('<p>Numbers are millimetres unless marked. Part names match BOM.md in the package. About six hours of bench time plus two overnight epoxy cures. Steps 1 to 17 build the sub-assemblies in any order; 18 to 25 go in sequence.</p>')
H.append('<p>November 2026</p>')
H.append(f'</div><div><img src="{img("final")}"></div></div>')
page_close()

# ---------------- inventory ----------------
INV = [("hub", 1), ("housing", 1), ("collar", 1), ("form", 1), ("cap", 1), ("foot", 3), ("tube", 3), ("stud", 3),
       ("ins3816", 3), ("ins1420", 6), ("insm5", 1), ("m3", 3), ("m3nut", 3), ("bolt1420", 3), ("washer", 45), ("stake", 3),
       ("gbolt", 1), ("gwasher", 2), ("gnut", 1), ("setscrew", 1), ("cnut", 1), ("ibolt", 1), ("ring38", 1), ("lining", 1),
       ("stem", 7), ("stemnut", 7), ("ball", 7), ("spring", 7), ("vcap", 7), ("ring516", 7), ("tap", 1), ("bring", 1),
       ("m3x10", 2), ("so239", 1), ("n4", 4), ("wire", 1), ("buswire", 1), ("shield", 1), ("whip", 1), ("pl259", 1)]
LAB = {k: None for k, _ in INV}
# labels come from steps' part entries; collect
labels = {}
for st in steps:
    for p in st["parts"]: labels[p["thumb"].replace("thumb_", "")] = p["label"]
labels.update({"gwasher": "1/4 washer", "gnut": "1/4-20 nut", "stake": "8 mm tent stake", "wire": "18 AWG bare tinned, 9.5 m", "shield": "shield wire, 300", "ring38": "3/8 ring terminal"})
page_open("Parts")
H.append('<h2>Everything in the box</h2><div class="inv">')
for k, q in INV:
    H.append(f'<div class="pi"><img src="{img("thumb_"+k)}"><div class="q">{q}x</div><div class="l">{labels.get(k, k)}</div></div>')
H.append('</div>')
H.append('<p class="small" style="margin-top:10px">Also: radial wire with ring terminals (four to eight), epoxy, thin CA, copper foil tape, solder, heat-shrink, masking tape, a 1/2 in dowel 300 mm long, and a 150 mm lead slug per leg if you want it. Full sources and prices are in BOM.md.</p>')
page_close()

# ---------------- tools, print settings, fit checks ----------------
page_open("Before you start")
H.append('<div class="two"><div><h2>Tools</h2><table><tr><th>Tool</th><th>For</th></tr>')
for a, b in [("Soldering iron, temperature controlled, with insert tips for 3/8-16, 1/4-20 and M5", "Inserts, steps 1 to 4"), ("60 W iron or gun, chisel tip, 60/40 or SAC solder, flux", "Electrical joints; the brass ring needs the big iron"),
             (".305-32 UNEF tap (tire valve stem tap) and tap wrench", "Seven station bosses, step 8"), ("Drills 3.3, 3.4, 7.0, 9.5, 15/32 in", "Cleaning printed holes, foot pins"), ("Hand drill or drill press", "Foot pins through the tubes"),
             ("Hacksaw or tube cutter, file, deburring tool", "Legs, valve stems, brass ring"), ("Calipers, multimeter with continuity beep", "Every check in this manual"), ("Needle-nose pliers, side cutters, strippers", "Stations, winding"),
             ("Hex keys 2.5 mm; 3/8, 7/16, 9/16 in wrenches", "Set screw, bolts, coupling nut"), ("Valve core removal tool", "Stems, step 11"), ("Bent paper clip, lighter, heat-shrink", "Fishing the bus wire; the center-pin joint"),
             ("Structural epoxy, thin CA", "Leg studs; holding wires in channels"), ("Isopropyl, lint-free rags, 220 grit", "Prep"), ("1/2 in dowel or PVC, 300 mm", "Pushing the coupling nut up the bore"), ("Masking tape, fine permanent marker", "Winding, marking turns")]:
    H.append(f'<tr><td>{a}</td><td>{b}</td></tr>')
H.append('</table></div><div><h2>Print settings</h2><table><tr><th>Part</th><th>File</th><th>Orientation and settings</th></tr>')
for a, b, c in [("Hub", "revD_tripod_hub_PRINT.stl", "Boss up, chamfer on the bed side. PETG or ASA, 0.2 layers, 6 walls, 40 % infill minimum. The chamfer is 50 deg from horizontal: no supports."),
                ("Housing", "revD_sleeve_hub.stl", "Standing, open rim down, threaded end up. 0.16 to 0.2 layers, 4 walls, brim. Station bosses are diamonds and self-support."),
                ("Collar", "revD_collar.stl", "Flat, either face down. 0.16 layers, 4 walls, 40 % infill. The thread flanks are shallow enough to print without support."),
                ("Coil form", "revD_form.stl", "Standing on the journal end. 0.12 to 0.16 layers so the groove is a smooth half-round, 3 walls, 20 % infill, brim."),
                ("Swivel cap", "revD_swivel_cap.stl", "Floor down, open end up. 0.16 to 0.2 layers, 4 walls."),
                ("Leg foot, x3", "revD_leg_foot.stl", "The file is exported in its working orientation, pocket down: rotate it 180 deg in the slicer so the top face is on the bed and the ballast pocket opens upward. 0.2 layers, 6 walls, 40 % infill. The socket is 50 deg from horizontal: no supports.")]:
    H.append(f'<tr><td>{a}</td><td style="font-family:monospace;font-size:8.5px">{b}</td><td>{c}</td></tr>')
H.append('</table><p class="small" style="margin-top:8px">PETG is the minimum; ASA is better outdoors. For MJF PA12 from a print service, upload the six STLs as they are.</p>')
H.append('<h2 style="margin-top:10px">Clean-up</h2><p class="small">Cut the brims off. File the housing rim and the journal end of the form flat; those two faces matter. Run a 3.3 mm drill by hand through the seven lip holes (five at the housing rim, two in the swivel cap): the ball must rattle freely. Run a 7.0 mm drill by hand into each station bore from outside, 10 mm deep only, to clear stringing; the shoulder at the bottom is the stop the stem bottoms on. Push a 9.5 mm drill shank through the ledge hole in the top of the housing; the whip stud passes here. Blow out every hole.</p>')
H.append('</div></div>')
page_close()

page_open("Before you start")
H.append('<h2>Fit checks, before any hardware goes in</h2><table><tr><th>Check</th><th>How</th><th>Pass</th></tr>')
for a, b, c in [("Form in housing", "Slide the form, land first, into the housing bore from the rim", "Slides the full length under its own weight with light finger drag, no rocking"),
                ("Whip in housing", "Push the whip's base section into the bore at the top of the housing", "Goes in 34 mm, slight drag, no wobble"),
                ("Housing in hub", "Push the housing, threaded end first, up through the hub bore from below", "Slides through under hand pressure, can be rotated by hand, the thread stands 14 mm above the boss face"),
                ("Collar on housing", "Thread the collar onto the housing top by hand, housing out of the hub", "Starts within a quarter turn, runs four turns to the bottom of the thread with light drag, no wobble. If it binds, clean both threads with a brass brush and run it on and off a few times"),
                ("Coupling nut in pocket", "Push the 3/8-24 coupling nut up the bore into the hex pocket with the dowel", "Enters, seats against the ledge, does not rotate when you try to turn it with the dowel"),
                ("Swivel cap on journal", "Push the cap over the journal end of the form", "Slides on, spins freely"),
                ("Leg in foot", "Push a leg tube into a foot socket", "Goes in 22 mm, snug"),
                ("Inserts in holes", "Drop each insert into its hole, cold", "Sits in the top of the hole, does not fall through, does not need force")]:
    H.append(f'<tr><td>{a}</td><td>{b}</td><td>{c}</td></tr>')
H.append('</table><p class="small" style="margin-top:10px">If the form drags hard in the housing, stringing in the bore is the usual cause: wrap 220 grit around the form\'s land and run it through the bore a few times. If the housing does not drop into the hub, do the same to the hub bore with the housing. Do not sand the whip bore.</p>')
page_close()

# ---------------- steps ----------------
cur = ""
for st in steps:
    cur = st.get("stage") or cur; st["stage"] = cur
FULL = {11, 13, 14, 18, 19, 22}
i = 0
while i < len(steps):
    st = steps[i]
    full = bool(st["insets"]) or st["num"] in FULL
    nxt = None
    if not full and i + 1 < len(steps):
        n = steps[i + 1]
        if not n["insets"] and n["num"] not in FULL: nxt = n
    page_open(st["stage"])
    if nxt: H.append('<div class="cols">' + panel(st) + panel(nxt) + '</div>'); i += 2
    else: H.append('<div class="cols one">' + panel(st) + '</div>'); i += 1
    page_close()

# ---------------- checks, tune-up, maintenance ----------------
page_open("Stage 9: Checks and first tune-up")
H.append('<div class="two"><div><h2>Electrical checks, before power</h2><table><tr><th>Probe</th><th>Reads</th><th>Means</th></tr>')
for a, b, c in [("Whip (any section) to SO-239 center pin, form fully in", "under 1 ohm", "Whip, nut, bolt, terminal, bus, five balls, one turn, ring, two balls, pin: the whole path"),
                ("Same, form fully out", "still under 1 ohm (9 m of 18 AWG is 0.2 ohm)", "80 turns"), ("Same, while turning the form through ten turns", "steady, no dropouts", "Balls riding the groove"),
                ("Whip to SO-239 shell", "open", "Nothing on the whip side touches ground"), ("SO-239 shell to each radial", "short", "Shield wire and ground bolt"), ("SO-239 shell to a leg", "open", "The hub is plastic; the legs are not in the circuit")]:
    H.append(f'<tr><td>{a}</td><td>{b}</td><td>{c}</td></tr>')
H.append('</table><p class="small" style="margin-top:8px">If whip to center pin is open with the form fully in, turn the form one turn: the balls may be sitting between the land and turn 1.</p>')
H.append('<h2 style="margin-top:12px">First tune-up</h2><p class="small">Full whip, form fully in: 20 m. Check SWR at 5 W; expect under 2:1 somewhere in the band and trim with the top whip section. Unscrew the form 20 turns (count the marks): 40 m. Check SWR, adjust the whip. The operating manual, section 6, has the turn counts for every band and what the whip does on each.</p></div>')
H.append('<div><h2>First-day problems</h2><table><tr><th>Symptom</th><th>Cause</th></tr>')
for a, b in [("SWR jumps as you turn the form", "A ball not riding the groove; open each station and check the ball is in the chamber and the spring is on it"), ("SWR high on every band, whip trim does nothing", "Shield wire missing, or the ground bolt loose"),
             ("Tunes but drifts in wind", "Set screw not in the groove so the housing rotates, or the collar has backed off: check it is seated on the boss"), ("Form hard to turn", "Wire proud of the groove somewhere; find it with a fingernail and press it down"),
             ("Tunes on 40 m but not 80 m", "Lining not connected; the dead turns are resonating. Check cap to lining continuity")]:
    H.append(f'<tr><td>{a}</td><td>{b}</td></tr>')
H.append('</table><h2 style="margin-top:12px">Maintenance</h2><p class="small">Noisy contact: unscrew one valve cap, tip out spring and ball, wipe them and the wire crests with isopropyl, reassemble. Nothing else moves. The form comes out by twisting it down and out of the housing; the swivel cap stays on it. Never coat the winding; if it tarnishes, wipe it with isopropyl and a rag while turning the form. Check the set screw and the leg inserts at the start of each season. Stake the feet through the ears whenever the forecast is over about 12 mph, or whenever you walk away from it.</p></div></div>')
page_close()

H.append('</body></html>')
open("manual.html", "w", encoding="utf-8").write("\n".join(H))
print("pages", pageno[0])
