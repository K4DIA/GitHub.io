#!/usr/bin/env python3
"""
Rev D: tripod-hub tunable loading coil for a 3/8-24 whip (17 ft telescoping).

  revD_sleeve_hub   printed housing: drops into the aluminum hub from above and hangs from a collar on the boss.
                    Whip-base bore and captive 3/8-24 coupling nut at the top, five stations at the bottom rim.
  revD_tripod_hub_PRINT  one-piece printed hub: body with three angled leg holes for 3/8-16 brass heat-set inserts, three
                    1/4-20 insert holes on top (one is the ground bolt for radials and coax shield), boss with an M5 insert
                    for the set screw, 41 mm bore straight through. K4DIA in the top face.
  revD_leg_foot     printed foot for each 1/2 in leg: angled socket, ballast pocket on a 1/4-20 insert, stake ear.
  machined_alt/revD_tripod_hub_ALU  the same hub as a machined 6061 part, kept as an alternative (tap-drill sizes, see drawing).
  Legs are 1/2 in aluminum tube or rod with a 3/8-16 end; purchased.
  revD_form         coil form, 80 turns at 2.0 mm, bearing land on top, fluted grip and swivel journal
                    at the bottom. Screws up into the hub from below.
  revD_swivel_cap   SO-239 feed cap that spins on the form journal; two ball stations contact a brass
                    ring on the journal. Retained by two M3 screw tips in a groove.

All threads are in purchased hardware (3/8-24 coupling nut, .305-32 valve stems, M3/M6 screws).
Outputs STEP (B-rep) and STL (tessellated from the same solids).
"""
import math, os, sys, json
import cadquery as cq

OUT = sys.argv[1] if len(sys.argv) > 1 else "revD"
os.makedirs(OUT, exist_ok=True)

P = dict(
    # coil form
    od=33.40, wall=2.5, pitch=2.0, groove_r=0.60, wire_od=1.02, turns=80, land=30.0, entry_hole=2.2,
    grip_od=44.0, grip_h=15.0, grip_flutes=12, coil_margin=10.0,
    journal_od=25.4, journal_len=22.0, ring_band=(8.0, 16.0), ring_od_recess=24.6,  # K&S 1 in brass tube, 0.014 wall
    retain_groove=(4.0, 6.0), retain_depth=1.5, wire_channel=1.6,
    # hub sleeve
    sleeve_wall=3.0, bore_clear=0.5, hex_af=14.6, nut_len=28.6, nut_ledge=3.0, whip_bore_depth=22.0,
    setscrew_below_top=18.0, collar_od=50.0, collar_t=5.0,
    engrave=dict(text="K4DIA", size=14.0, depth=1.2, angle=180, z_center=120.0),   # housing cylinder, reading down the tube, on the visible band below the hub
    station_z=10.0, n_stations=5, lip=1.0, lip_hole=3.4, chamber_d=4.4, chamber_len=4.0, tap_d=7.0, tap_len=10.0, boss_side=13.0,
    bus_hole=3.0, interior_extra=6.0,
    # one-piece machined tripod hub (6061): body with angled leg holes, radial screws on top, boss with set screw, through bore
    tripod=dict(body_dia=86.0, body_t=23.0, boss_od=50.0, boss_h=36.0, bore_clear=0.3,
                leg_thread="3/8-16 UNC", leg_tap_drill=8.0, leg_angle=40.0, leg_depth=15.0,   # axis 40 deg from vertical, perpendicular to the chamfer
                chamfer_a=13.0,                                                               # radial width of the bottom chamfer; its rise is a*tan(angle)
                radial_tap_drill=5.1, radial_depth=12.0, radial_r=34.0, setscrew_tap_drill=4.2, stock="3-1/2 in round bar",
                engrave=dict(text="K4DIA", size=9.0, depth=0.5, r=34.0, angles=(60, 180, 300)),   # top face, one per sector between the radial screws
                finish="chem film MIL-DTL-5541 Type II Class 3 (conductive), after all machining"),
    # printed alternative to the machined hub: same layout, holes sized for brass heat-set inserts, one ground bolt
    tripod_print=dict(body_dia=98.0, body_t=29.0, boss_od=52.0, boss_h=36.0, bore_clear=0.4,
                leg_thread="3/8-16 heat-set brass insert for plastic (0.469 in OD x 0.625 long)", leg_tap_drill=11.9, leg_angle=40.0, leg_depth=17.0,
                chamfer_a=15.0, radial_tap_drill=7.9, radial_depth=15.0, radial_r=38.0, setscrew_tap_drill=6.4,
                setscrew_rib=dict(w=14.0, out=6.0),            # rib on the boss so the M5 insert (9.5 long) has 11.4 mm of wall
                inserts=dict(leg="3/8-16 x 1/2 in, 0.469 OD (HI-316-WH), 15/32 hole", top="1/4-20 x 1/2 in, 0.315 OD (HI-420-WH), 5/16 hole", setscrew="M5 x 9.5 long, 6.4 OD, 6.4 hole"),
                stock="MJF PA12 or FDM PETG/ASA, 100% infill or 6 walls", finish="none; one 1/4-20 insert carries the radials and the coax shield",
                engrave=dict(text="K4DIA", size=10.0, depth=0.8, r=38.0, angles=(60, 180, 300))),
    # whip: Chameleon CHA SS17 or any 17 ft 3/8-24 stainless telescoping whip. Base 0.63 in (16.0 mm), 0.9 lb.
    whip=dict(model="Chameleon CHA SS17", length_m=5.18, base_od=16.0, mass_kg=0.41, sections=10, collapsed_in=27),
    # legs: 1/2 in tube, 750 mm, 3/8-16 stud with 12.7 showing (hub hole 17 deep). Printed feet below.
    leg=dict(od=12.7, length=750.0, thread="3/8-16 UNC", thread_len=12.7),
    # swivel cap
    cap_bore=26.0, cap_wall=6.0, cap_face_od=40.0, cap_floor=7.0, tail_space=10.0, conn_hole=16.5, conn_pitch=18.24, pilot_d=2.6, pilot_depth=5.5,
    n_cap_stations=2, retain_screw_d=2.5,
    # printed leg foot: flat-bottomed cup, angled socket for the leg, ballast pocket underneath on a 1/4-20 insert, stake ear
    foot=dict(od=46.0, height=70.0, socket_d=12.9, socket_len=22.0, socket_offset=7.0, pin_hole=3.4, pin_from_entry=12.0,
              pocket_d=36.0, pocket_depth=26.0, insert_hole=7.9, insert_depth=14.0,
              ear_w=15.0, ear_out=16.0, stake_hole=9.0),
)


def groove_solid(r_surface, groove_r, z0, turns, pitch):
    helix = cq.Wire.makeHelix(pitch=pitch, height=pitch * turns, radius=r_surface, center=cq.Vector(0, 0, z0))
    return cq.Workplane("XZ", origin=(r_surface, 0, z0)).circle(groove_r).sweep(cq.Workplane().add(helix), isFrenet=True)


def radial_cyl(d, r_from, length, z, ang_deg):
    """cylinder along +x starting at radius r_from, then rotated to ang."""
    return cq.Workplane("YZ", origin=(r_from, 0, z)).circle(d / 2).extrude(length).rotate((0, 0, 0), (0, 0, 1), ang_deg)


def station_cutters(r0, z, ang):
    lip = radial_cyl(P["lip_hole"], r0 - 1, P["lip"] + 1, z, ang)
    ch = radial_cyl(P["chamber_d"], r0 + P["lip"], P["chamber_len"], z, ang)
    tp = radial_cyl(P["tap_d"], r0 + P["lip"] + P["chamber_len"], P["tap_len"] + 2, z, ang)
    return [lip, ch, tp]


def station_boss(r_inner, r_out, z, ang):
    b = (cq.Workplane("YZ", origin=(r_inner, 0, z)).rect(P["boss_side"], P["boss_side"]).extrude(r_out - r_inner)
         .rotate((0, 0, z), (1, 0, z), 45))
    return b.rotate((0, 0, 0), (0, 0, 1), ang)


# ------------------------------------------------------------------ form
def form():
    od = P["od"]; r = od / 2; crest_od = od + 2 * (P["wire_od"] - P["groove_r"])
    coil_len = P["pitch"] * P["turns"] + 2 * P["groove_r"] + 1.0
    # z = 0 at the bottom of the journal; build upward: journal, grip, coil, land
    zj = 0; zg = P["journal_len"]; zc = zg + P["grip_h"]; zl = zc + P["coil_margin"] + coil_len + P["coil_margin"]; ztop = zl + P["land"]
    s = cq.Workplane("XY").circle(P["journal_od"] / 2).extrude(P["journal_len"])
    s = s.union(cq.Workplane("XY").workplane(offset=zg).circle(P["grip_od"] / 2).extrude(P["grip_h"]))
    s = s.union(cq.Workplane("XY").workplane(offset=zc).circle(r).extrude(zl - zc))
    s = s.union(cq.Workplane("XY").workplane(offset=zl).circle(crest_od / 2).extrude(P["land"]))
    # bore from the top down to the coil floor (keeps plastic out of the field; bottom stays solid)
    s = s.cut(cq.Workplane("XY").workplane(offset=zc + 3).circle((od - 2 * P["wall"]) / 2).extrude(ztop - zc))
    # grip flutes
    for k in range(P["grip_flutes"]):
        f = cq.Workplane("XY").workplane(offset=zg - 1).center(P["grip_od"] / 2, 0).circle(2.2).extrude(P["grip_h"] + 2)
        s = s.cut(f.rotate((0, 0, 0), (0, 0, 1), 360 * k / P["grip_flutes"] + 15))
    # helical groove, 80 turns, starting at angle 0 just above the lower margin
    z0 = zc + P["coil_margin"] + P["groove_r"] + 0.5
    s = s.cut(groove_solid(r, P["groove_r"], z0, P["turns"], P["pitch"]))
    # top wire tail: entry hole into the bore at the last turn (dead end, tucked away)
    a_end = 360.0 * P["turns"]
    s = s.cut(radial_cyl(P["entry_hole"], r - P["wall"] - 1.5, P["wall"] + 3, z0 + P["pitch"] * P["turns"], a_end))
    # bottom wire: axial channel from the first turn down the outside of the form, through the grip, to the ring band
    ch_depth = P["wire_channel"]
    chan = (cq.Workplane("XY").workplane(offset=P["ring_band"][1] - 2).center(r - ch_depth / 2 + 0.3, 0)
            .rect(ch_depth + 0.6, P["wire_channel"]).extrude(z0 - (P["ring_band"][1] - 2) + 0.5))
    grip_chan = (cq.Workplane("XY").workplane(offset=zg - 1).center(P["grip_od"] / 2 - 3, 0).rect(8, P["wire_channel"] + 0.4).extrude(P["grip_h"] + 2))
    s = s.cut(chan).cut(grip_chan)
    # ring band recess (brass tube sits flush) and retaining groove on the journal
    s = s.cut(cq.Workplane("XY").workplane(offset=P["ring_band"][0]).circle(P["journal_od"] / 2 + 1).circle(P["ring_od_recess"] / 2).extrude(P["ring_band"][1] - P["ring_band"][0]))
    s = s.cut(cq.Workplane("XY").workplane(offset=P["retain_groove"][0]).circle(P["journal_od"] / 2 + 1).circle(P["journal_od"] / 2 - P["retain_depth"]).extrude(P["retain_groove"][1] - P["retain_groove"][0]))
    # lead-in chamfer at the journal end
    s = s.faces("<Z").chamfer(0.8)
    return s, dict(length=ztop, crest_od=crest_od, coil_len=coil_len, z_first_turn=z0, z_last_turn=z0 + P["pitch"] * P["turns"],
                   z_land=zl, z_grip=(zg, zc), journal=(0, zg))


# ------------------------------------------------------------------ hub sleeve (printed housing; slides up through the aluminum hub)
def hub(fi):
    bore_d = fi["crest_od"] + P["bore_clear"]; r0 = bore_d / 2; sleeve_od = bore_d + 2 * P["sleeve_wall"]
    interior = P["station_z"] + fi["coil_len"] + P["coil_margin"] + P["land"] + P["interior_extra"]
    top_block = P["nut_len"] + P["nut_ledge"] + P["whip_bore_depth"]        # solid top: nut pocket, ledge, whip-base bore
    H = interior + top_block
    s = cq.Workplane("XY").circle(sleeve_od / 2).extrude(H)
    boss_len = P["lip"] + P["chamber_len"] + P["tap_len"]; r_out = r0 + boss_len; inner = r0 + P["sleeve_wall"] - 2.5
    for k in range(P["n_stations"]):
        ang = 360.0 * k / P["n_stations"] + 1.125; z = P["station_z"] + P["pitch"] * k / P["n_stations"]
        s = s.union(station_boss(inner, r_out, z, ang))
    # collar at the top: the housing drops into the hub from above and hangs from this collar on the boss face
    t = P["tripod"]; z_collar = H - P["collar_t"]
    s = s.union(cq.Workplane("XY").workplane(offset=z_collar).circle(P["collar_od"] / 2).extrude(P["collar_t"]))
    # bore (open at the bottom), coupling-nut hex pocket open to the bore, 9.8 hole through the ledge, whip-base bore from the top
    s = s.cut(cq.Workplane("XY").circle(bore_d / 2).extrude(interior))
    s = s.cut(cq.Workplane("XY").workplane(offset=interior - 0.01).polygon(6, P["hex_af"] / math.cos(math.radians(30))).extrude(P["nut_len"] + 0.01))
    s = s.cut(cq.Workplane("XY").workplane(offset=interior + P["nut_len"] - 0.5).circle(9.8 / 2).extrude(P["nut_ledge"] + 1))
    s = s.cut(cq.Workplane("XY").workplane(offset=H - P["whip_bore_depth"]).circle((P["whip"]["base_od"] + 0.25) / 2).extrude(P["whip_bore_depth"] + 1))
    # set-screw groove ring, in the boss region
    s = s.cut(cq.Workplane("XY").workplane(offset=H - P["setscrew_below_top"] - 1.0).circle(sleeve_od / 2 + 1).circle(sleeve_od / 2 - 1.0).extrude(2.0))
    for k in range(P["n_stations"]):
        ang = 360.0 * k / P["n_stations"] + 1.125; z = P["station_z"] + P["pitch"] * k / P["n_stations"]
        for c in station_cutters(r0, z, ang): s = s.cut(c)
    s = s.cut(radial_cyl(P["bus_hole"], r0 - 1, P["sleeve_wall"] + 2, interior - 8, 36 + 1.125))
    # callsign recessed into the outside of the tube, reading down the axis, on the band visible below the hub
    e = P["engrave"]
    txt = (cq.Workplane("XY").text(e["text"], e["size"], 8.0, kind="bold", halign="center", valign="center")   # letters lie in XY, baseline along x, 8 mm thick along +z
           .rotate((0, 0, 0), (0, 1, 0), -90)                     # baseline now along +z (down-to-up), letter height along y, thickness along -x
           .rotate((0, 0, 0), (0, 0, 1), 180)                     # thickness along +x; the word reads up the tube, like a mast marking
           .translate((sleeve_od / 2 - e["depth"] - 2.0, 0, 0))   # letters start 2 mm deeper than the recess, then get trimmed to the cylinder below
           .translate((0, 0, e["z_center"])).rotate((0, 0, 0), (0, 0, 1), e["angle"]))
    # trim the letters to a shell so the recess floor follows the cylinder: uniform depth over the full letter height
    shell = cq.Workplane("XY").workplane(offset=e["z_center"] - 40).circle(sleeve_od / 2 + 6).circle(sleeve_od / 2 - e["depth"]).extrude(80)
    s = s.cut(txt.intersect(shell))
    return s, dict(height=H, interior=interior, bore_d=bore_d, od=sleeve_od, z_stations=P["station_z"], z_collar=z_collar,
                   top_block=top_block, z_hub_top=z_collar, z_hub_bottom=z_collar - t["boss_h"] - t["body_t"])


# ------------------------------------------------------------------ one-piece tripod hub (machined aluminum, 6061-T6)
def tripod_hub(hi, t=None):
    t = t or P["tripod"]; bore = hi["od"] + t["bore_clear"]
    R = t["body_dia"] / 2; T = t["body_t"]; la = math.radians(t["leg_angle"])
    a = t["chamfer_a"]; h = a * math.tan(la)            # chamfer: rises h over radial width a, face normal at leg_angle from vertical
    # body as a revolved profile: bottom face to R-a, chamfer up to (R, h), outer wall to T, boss, bore
    prof = [(bore / 2, 0), (R - a, 0), (R, h), (R, T), (t["boss_od"] / 2, T), (t["boss_od"] / 2, T + t["boss_h"]), (bore / 2, T + t["boss_h"])]
    s = cq.Workplane("XZ").polyline(prof).close().revolve(360, (0, 0, 0), (0, 1, 0))
    # leg holes: start at the chamfer face centre, axis perpendicular to the chamfer (in and up), modeled at tap-drill size
    xc, zc = R - a / 2, h / 2
    u = (-math.sin(la), math.cos(la))     # radial, axial components of the hole axis
    ends = []
    for k in range(3):
        ang = 120 * k + 60
        hole = (cq.Workplane("XY").workplane(offset=-3).circle(t["leg_tap_drill"] / 2).extrude(t["leg_depth"] + 3)
                .rotate((0, 0, 0), (0, 1, 0), -t["leg_angle"]).translate((xc, 0, zc)))   # -angle about y tilts +z toward -x (inward, up)
        s = s.cut(hole.rotate((0, 0, 0), (0, 0, 1), ang))
    r_end = xc + u[0] * t["leg_depth"]; z_end = zc + u[1] * t["leg_depth"]
    # radial screw holes on top, between the legs
    for k in range(3):
        hh = cq.Workplane("XY").workplane(offset=T - t["radial_depth"]).center(t["radial_r"], 0).circle(t["radial_tap_drill"] / 2).extrude(t["radial_depth"] + 1)
        s = s.cut(hh.rotate((0, 0, 0), (0, 0, 1), 120 * k))
    # set screw through the boss at the housing groove height
    z_ss = T + t["boss_h"] - (P["setscrew_below_top"] - P["collar_t"])
    rib = t.get("setscrew_rib")
    if rib:   # printed hub: vertical rib from the body top up past the set-screw hole, so the insert has a full-length wall
        s = s.union(cq.Workplane("XY").workplane(offset=T).center(t["boss_od"] / 2 - 1 + (rib["out"] + 1) / 2, 0)
                    .rect(rib["out"] + 1, rib["w"]).extrude(z_ss + rib["w"] / 2 - T))
    s = s.cut(cq.Workplane("YZ", origin=(bore / 2 - 2, 0, z_ss)).circle(t["setscrew_tap_drill"] / 2).extrude(t["boss_od"]))
    # callsign engraved into the top face, tangent to the bolt circle, in each sector between the radial screws
    e = t["engrave"]
    for ang in e["angles"]:
        txt = (cq.Workplane("XY").workplane(offset=T).text(e["text"], e["size"], -e["depth"], kind="bold", halign="center", valign="center")
               .rotate((0, 0, 0), (0, 0, 1), 90).translate((e["r"], 0, 0)).rotate((0, 0, 0), (0, 0, 1), ang - 90))
        s = s.cut(txt)
    ss_wall = (t["boss_od"] - bore) / 2 + (rib["out"] if rib else 0)
    return s, dict(bore=bore, height=T + t["boss_h"], z_setscrew=z_ss, setscrew_wall=round(ss_wall, 2), radial_depth=t["radial_depth"], chamfer_rise=round(h, 2), chamfer_face_width=round(math.hypot(a, h), 2),
                   seat_r=round(xc, 2), seat_z=round(zc, 2),
                   hole_end_r=round(r_end, 2), hole_end_z=round(z_end, 2),
                   wall_to_bore_at_end=round(r_end - t["leg_tap_drill"] / 2 - bore / 2, 2),
                   wall_to_top_at_end=round(T - z_end - t["leg_tap_drill"] / 2, 2))


# ------------------------------------------------------------------ leg foot
def foot():
    f = P["foot"]; la = math.radians(P["tripod_print"]["leg_angle"]); R = f["od"] / 2; H = f["height"]
    s = cq.Workplane("XY").circle(R).extrude(H)
    # stake ear: full-height rib on the outer side with a vertical hole for a tent stake
    ear_x0 = R - 2.0; ear_len = 2.0 + f["ear_out"]
    s = s.union(cq.Workplane("XY").center(ear_x0 + ear_len / 2, 0).rect(ear_len, f["ear_w"]).extrude(H))
    s = s.cut(cq.Workplane("XY").workplane(offset=-1).center(R + f["ear_out"] / 2, 0).circle(f["stake_hole"] / 2).extrude(H + 2))
    # leg socket: enters the top face inboard of centre and runs down and outward at the leg angle, closed end
    sock = (cq.Workplane("XY").workplane(offset=-5).circle(f["socket_d"] / 2).extrude(f["socket_len"] + 5)
            .rotate((0, 0, 0), (0, 1, 0), 180 - P["tripod_print"]["leg_angle"]).translate((-f["socket_offset"], 0, H)))
    s = s.cut(sock)
    # cross pin hole through the socket, horizontal, for an M3 screw through the tube
    px = -f["socket_offset"] + f["pin_from_entry"] * math.sin(la); pz = H - f["pin_from_entry"] * math.cos(la)
    s = s.cut(cq.Workplane("XZ", origin=(px, R + 2, pz)).circle(f["pin_hole"] / 2).extrude(2 * R + 4))
    # ballast pocket from the bottom, 1/4-20 insert hole in its ceiling
    s = s.cut(cq.Workplane("XY").workplane(offset=-1).circle(f["pocket_d"] / 2).extrude(f["pocket_depth"] + 1))
    s = s.cut(cq.Workplane("XY").workplane(offset=f["pocket_depth"] - 1).circle(f["insert_hole"] / 2).extrude(f["insert_depth"] + 1))
    end_x = -f["socket_offset"] + f["socket_len"] * math.sin(la); end_z = H - f["socket_len"] * math.cos(la)
    # clearance between the socket end and the insert hole (perpendicular distance from the hole's top centre to the socket axis)
    ux, uz = math.sin(la), -math.cos(la); vx, vz = 0 - (-f["socket_offset"]), (f["pocket_depth"] + f["insert_depth"]) - H
    dist = abs(vx * uz - vz * ux) - f["socket_d"] / 2 - f["insert_hole"] / 2
    pocket_cc = math.pi * (f["pocket_d"] / 2) ** 2 * f["pocket_depth"] / 1000
    return s, dict(od=f["od"] + f["ear_out"], height=H, socket_end=(round(end_x, 2), round(end_z, 2)),
                   socket_to_insert_wall=round(dist, 2), socket_inner_wall_at_top=round(R - (f["socket_offset"] + f["socket_d"] / 2 / math.cos(la)), 2),
                   pocket_cc=round(pocket_cc, 1), ballast_lead_g=round(pocket_cc * 11.3), ballast_washers_g=round(pocket_cc * 0.65 * 7.85),
                   tube_slug_150mm_g=round(math.pi * (9.75 / 2) ** 2 * 150 / 1000 * 11.3))


# ------------------------------------------------------------------ swivel cap
def swivel():
    H = P["journal_len"] + P["tail_space"] + P["cap_floor"]
    body_od = P["cap_bore"] + 2 * P["cap_wall"]
    s = cq.Workplane("XY").circle(body_od / 2).extrude(H)
    s = s.union(cq.Workplane("XY").circle(P["cap_face_od"] / 2).extrude(P["cap_floor"]))   # wide foot for the SO-239 flange
    r0 = P["cap_bore"] / 2; boss_len = P["lip"] + P["chamber_len"] + P["tap_len"]; r_out = r0 + boss_len
    z_st = H - (P["journal_len"] - (P["ring_band"][0] + P["ring_band"][1]) / 2)   # ring band is measured from the journal end; rim sits at journal top
    for k in range(P["n_cap_stations"]):
        s = s.union(station_boss(r0 + P["cap_wall"] - 2.5, r_out, z_st, 180 * k))
    s = s.cut(cq.Workplane("XY").workplane(offset=P["cap_floor"]).circle(P["cap_bore"] / 2).extrude(H))
    for k in range(P["n_cap_stations"]):
        for c in station_cutters(r0, z_st, 180 * k): s = s.cut(c)
    z_ret = H - (P["journal_len"] - (P["retain_groove"][0] + P["retain_groove"][1]) / 2)
    for ang in (90, 270):
        s = s.cut(radial_cyl(P["retain_screw_d"], r0 - 2, P["cap_wall"] + 4, z_ret, ang))
    s = s.cut(cq.Workplane("XY").circle(P["conn_hole"] / 2).extrude(P["cap_floor"] + 1))
    off = P["conn_pitch"] / 2
    s = s.cut(cq.Workplane("XY").pushPoints([(sx * off, sy * off) for sx in (-1, 1) for sy in (-1, 1)]).circle(P["pilot_d"] / 2).extrude(P["pilot_depth"]))
    s = s.cut(radial_cyl(P["bus_hole"], r0 - 2, P["cap_wall"] + 4, P["cap_floor"] + P["tail_space"] / 2, 45))
    return s, dict(height=H, od=body_od, z_stations_from_rim=H - z_st)


def check(name, wp):
    sol = wp.val(); assert sol.isValid(), name
    bb = sol.BoundingBox()
    print(f"{name:20s} valid  {bb.xlen:6.2f} x {bb.ylen:6.2f} x {bb.zlen:6.2f} mm  {sol.Volume()/1000:6.1f} cm3  ~{sol.Volume()/1000*1.27:4.0f} g PETG")
    return sol


if __name__ == "__main__":
    fm, fi = form(); hb, hi = hub(fi); sw, si = swivel(); ft, fti = foot(); tp, ti = tripod_hub(hi); tpp, tip = tripod_hub(hi, P["tripod_print"])
    os.makedirs(f"{OUT}/machined_alt", exist_ok=True)
    parts = {"revD_form": fm, "revD_sleeve_hub": hb, "revD_swivel_cap": sw, "revD_tripod_hub_PRINT": tpp, "revD_leg_foot": ft,
             "machined_alt/revD_tripod_hub_ALU": tp}
    vols = {}
    for n, w in parts.items():
        vols[n.split("/")[-1]] = check(n, w).Volume() / 1000
        cq.exporters.export(w, f"{OUT}/{n}.step")
        cq.exporters.export(w, f"{OUT}/{n}.stl", tolerance=0.02, angularTolerance=0.08)
    json.dump(dict(form=fi, hub=hi, swivel=si, foot=fti, tripod=ti, tripod_print=tip, volumes_cc=vols, params=P), open(f"{OUT}/revD_dims.json", "w"), indent=1, default=float)
    print(json.dumps(dict(form=fi, hub=hi, swivel=si, foot=fti, tripod=ti, tripod_print=tip, volumes_cc=vols), indent=1, default=float))
