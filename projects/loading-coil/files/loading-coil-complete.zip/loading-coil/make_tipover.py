#!/usr/bin/env python3
"""Free-standing tip-over wind for rev D (printed hub, tube legs, printed feet) against ballast per foot. Writes revD/tipover.json."""
import json, math
d = json.load(open('revD/revD_dims.json')); P = d['params']; v = d['volumes_cc']; f = d['foot']
rho_petg = 1.27
m_print = (v['revD_sleeve_hub'] + v['revD_form'] + v['revD_swivel_cap'] + v['revD_tripod_hub_PRINT'] + 3 * v['revD_leg_foot']) * rho_petg / 1000
m_legs = 3 * 0.08; m_whip = P['whip']['mass_kg']; m_hw = 0.12
m0 = m_print + m_legs + m_whip + m_hw
L = P['leg']['length'] / 1000; la = math.radians(P['tripod_print']['leg_angle'])
h_hub = L * math.cos(la); r_foot = L * math.sin(la) + 0.038
arm_center = r_foot / 2; arm_far = 1.5 * r_foot      # tipping line through two feet; the third foot is upwind
rho = 1.225; Cd = 1.2
def M_wind(vel):
    q = 0.5 * rho * vel * vel * Cd; z_hub = h_hub + 0.065
    return (q * P['whip']['length_m'] * 0.010 * (z_hub + P['whip']['length_m'] / 2) + q * 0.098 * 0.065 * (h_hub + 0.032)
            + q * 0.041 * 0.21 * (h_hub - 0.105) + q * 0.034 * 0.20 * (h_hub - 0.31))
def tip_mph(ballast):
    M = m0 * 9.81 * arm_center + ballast * 9.81 * arm_far; lo, hi = 0.0, 60.0
    for _ in range(60):
        mid = (lo + hi) / 2
        if M_wind(mid) < M: lo = mid
        else: hi = mid
    return lo * 2.237
wash = f['ballast_washers_g'] / 1000; lead = f['ballast_lead_g'] / 1000; slug = f['tube_slug_150mm_g'] / 1000
rows = [(0, 'no ballast'), (wash, '1-1/4 in fender washers filling the pocket'), (slug, '150 mm lead slug in each tube'),
        (lead, 'lead cast or stacked in the pocket'), (lead + slug, 'pocket and tube both')]
out = dict(m_print_kg=round(m_print, 2), m_total_kg=round(m0, 2), h_hub_m=round(h_hub, 3), r_foot_m=round(r_foot, 3),
           table=[dict(g=round(b * 1000), mph=round(tip_mph(b), 1), what=lab) for b, lab in rows])
json.dump(out, open('revD/tipover.json', 'w'), indent=1); print(json.dumps(out, indent=1))
