#!/usr/bin/env python3
"""
Generate end-cap STLs for the whip-antenna loading coil.
Two variants:
  BNC    : 26.67 mm socket (coilform_BNC, or 3/4" Sch 40 pipe), 4-hole BNC bulkhead (UG-290 style)
  SO-239 : 33.40 mm socket (coilform_SO239 / tuner_form, or 1" Sch 40 pipe), 1" square-flange SO-239

Cap is a SOCKET that slips OVER the tube (not a plug), because the SO-239
flange corners (36 mm diagonal) overhang a 33.4 mm tube and the mounting
screws would otherwise land in the tube wall.
"""
import math, json, sys
import numpy as np
import trimesh
from trimesh.creation import cylinder

SEG = 128  # facets on round features

VARIANTS = {
    "BNC": dict(
        tube_od=26.67,          # 3/4" Sch40 nominal OD (1.050")
        tube_id=20.93,          # 3/4" Sch40 ID (0.824")
        body_hole=9.8,          # UG-290 body 3/8" (9.52) + clearance
        flange_sq=12.7,         # 0.500" square flange
        hole_pitch=9.65,        # 0.380" square mounting pattern
        pilot_dia=2.1,          # self-tap pilot for #2-56 / M2.5 screws
        pilot_depth=5.5,
        face_wire_hole=dict(r=8.5, dia=3.2),   # fits between flange (r 6.35) and bore (r 10.45)
    ),
    "SO239": dict(
        tube_od=33.40,          # 1" Sch40 nominal OD (1.315")
        tube_id=26.64,          # 1" Sch40 ID (1.049")
        body_hole=16.5,         # SO-239 body 5/8" (15.9) + clearance
        flange_sq=25.4,         # 1.000" square flange
        hole_pitch=18.24,       # 0.718" square mounting pattern
        pilot_dia=2.6,          # self-tap pilot for #4 screws (use 4.0 for M3 heat-set inserts)
        pilot_depth=5.5,
        face_wire_hole=None,    # flange covers the whole bore area -> wire enters through tube wall instead
    ),
}

COMMON = dict(
    wall=3.0,            # socket wall thickness
    face=7.0,            # end-face thickness
    socket_depth=12.0,   # how far the tube inserts
    tube_clearance=0.4,  # diametral clearance on the socket bore (tune for your printer)
)


def clean(m):
    """Remove zero-area slivers left by coincident cutter faces, then prove the mesh is a closed volume."""
    m.merge_vertices(); m.update_faces(m.nondegenerate_faces()); m.remove_unreferenced_vertices()
    assert m.is_watertight and m.is_volume and m.is_winding_consistent, "mesh invalid after clean"
    return m


def cyl(d, h, z0=0.0, x=0.0, y=0.0):
    c = cylinder(radius=d / 2, height=h, sections=SEG)
    c.apply_translation([x, y, z0 + h / 2])
    return c


def make_cap(v):
    p = {**COMMON, **v}
    cap_od = p["tube_od"] + 2 * p["wall"]
    H = p["face"] + p["socket_depth"]
    body = cyl(cap_od, H)

    cutters = []
    # socket bore from the bottom (open end), tube slides in here
    cutters.append(cyl(p["tube_od"] + p["tube_clearance"], p["socket_depth"] + 0.01, z0=-0.01))
    # connector body through-hole; starts inside the socket void so it never crosses the z=0 face (avoids sliver faces)
    cutters.append(cyl(p["body_hole"], H - p["socket_depth"] + 3, z0=p["socket_depth"] - 2))
    # 4 blind pilot holes from the outer face (top, z=H)
    off = p["hole_pitch"] / 2
    for sx in (-1, 1):
        for sy in (-1, 1):
            cutters.append(cyl(p["pilot_dia"], p["pilot_depth"] + 0.01,
                               z0=H - p["pilot_depth"], x=sx * off, y=sy * off))
    # optional wire hole through the face (BNC only)
    if p["face_wire_hole"]:
        w = p["face_wire_hole"]
        cutters.append(cyl(w["dia"], H - p["socket_depth"] + 3, z0=p["socket_depth"] - 2, x=w["r"], y=0))

    # cutters go in as separate solids; concatenating overlapping cutters into one mesh makes the
    # overlap read as "outside" and leaves an un-cut slug where the body hole crosses the socket.
    cap = clean(trimesh.boolean.difference([body] + cutters, engine="manifold"))
    return cap, p, cap_od, H


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    report = {}
    for name, v in VARIANTS.items():
        cap, p, cap_od, H = make_cap(v)
        # STL is printed open-end-down; flip so the FACE is on the bed (flat, no supports).
        cap.apply_transform(trimesh.transformations.rotation_matrix(math.pi, [1, 0, 0]))
        cap.apply_translation([0, 0, -cap.bounds[0][2]])
        fn = f"{out}/endcap_{name}_x2.stl"
        cap.export(fn)
        assert trimesh.load(fn).is_watertight, "exported STL not watertight"
        b = cap.bounds
        report[name] = dict(
            file=fn, cap_od_mm=round(cap_od, 2), height_mm=round(H, 2),
            bbox_mm=[round(x, 2) for x in (b[1] - b[0])],
            volume_cm3=round(cap.volume / 1000, 2),
            est_mass_g_PETG_100pct=round(cap.volume / 1000 * 1.27, 1),
            watertight=cap.is_watertight, faces=len(cap.faces),
            socket_bore_mm=round(p["tube_od"] + p["tube_clearance"], 2),
            body_hole_mm=p["body_hole"], pilot_dia_mm=p["pilot_dia"],
            hole_pitch_mm=p["hole_pitch"],
            flange_corner_radius_mm=round(p["flange_sq"] * math.sqrt(2) / 2, 2),
            cap_radius_mm=round(cap_od / 2, 2),
        )
    print(json.dumps(report, indent=2))
