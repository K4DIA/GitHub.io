# Bill of materials, rev D tripod-hub unit

Every part of the antenna except the legs is printed, the collar included; everything else is off-the-shelf hardware. Prices are rough US retail in late 2026. Printed-part prices are given as print service / home filament. `BOM.csv` is the same list for a spreadsheet. The rev B and rev C lists are in `README.md` under their own sections.


## Printed parts

| Item | Qty | Spec / use | Source | Est. USD |
|---|---|---|---|---|
| Tripod hub | 1 | revD_tripod_hub_PRINT.stl, 177 cm3. MJF PA12, or PETG/ASA at home, 6 walls, 40% infill minimum | JLC3DP MJF, or own printer | 40 / 5 |
| Housing | 1 | revD_sleeve_hub.stl, 156 cm3, printed standing, open end down | same | 35 / 4 |
| Collar | 1 | revD_collar.stl, 9 cm3, printed flat, internal thread | same | 5 / 1 |
| Coil form | 1 | revD_form.stl, 82 cm3, standing, 0.12 to 0.16 mm layers | same | 25 / 3 |
| Swivel cap | 1 | revD_swivel_cap.stl, 29 cm3 | same | 10 / 1 |
| Leg foot | 3 | revD_leg_foot.stl, 99 cm3 each, top face on the bed | same | 30 / 8 |


## Heat-set inserts

| Item | Qty | Spec / use | Source | Est. USD |
|---|---|---|---|---|
| 3/8-16 x 1/2 in, 0.469 OD, 15/32 hole | 3 | Brass, HI-316-WH; hub leg holes | Zoro 1GUA1 (25 pk) | 14 |
| 1/4-20 x 1/2 in, 0.315 OD, 5/16 hole | 6 | Brass, HI-420-WH; 3 in the hub top, 3 in the foot pockets | Zoro G3434347 (50 pk) | 12 |
| M5 x 9.5 long, 6.4 OD | 1 | Brass; hub boss rib for the set screw | ruthex / CNC Kitchen M5 pack | 8 |


## Legs

| Item | Qty | Spec / use | Source | Est. USD |
|---|---|---|---|---|
| 1/2 in OD x 0.058 wall 6061-T6 tube | 3 | 750 mm each (one 8 ft length covers it) | McMaster-Carr, OnlineMetals, Speedy Metals | 25 |
| 3/8-16 x 1-1/2 in stud | 3 | Steel or stainless; 1 in epoxied into the tube top, 1/2 in showing. Or a 1-1/2 in bolt with the head cut off | hardware store | 3 |
| Epoxy | 1 | Structural, for the studs and the brass ring | hardware store | 6 |


## Feet

| Item | Qty | Spec / use | Source | Est. USD |
|---|---|---|---|---|
| M3 x 20 screw and nut | 3 | Pin through the foot cross hole and the tube | hardware store | 2 |
| 1/4-20 x 1-1/2 in hex bolt | 3 | Ballast bolt; the head is the foot | hardware store | 2 |
| 1-1/4 in fender washers, 1/4 in hole | 45 | About 15 per foot fill the pocket (135 g). Or lead: cast in the pocket (300 g) or a 150 mm slug in each tube (125 g) | hardware store | 8 |
| 1/4-20 rubber bumper foot | 3 | Optional, in place of the ballast bolt on indoor floors | hardware store | 4 |
| 8 mm tent stake | 3 | Through the foot ears | camping | 6 |


## Hub

| Item | Qty | Spec / use | Source | Est. USD |
|---|---|---|---|---|
| 1/4-20 x 3/4 in stainless bolt, 2 washers, nut | 1 | Ground bolt: radials and coax shield on ring terminals under the head | hardware store | 1 |
| M5 x 16 set screw, nylon tip | 1 | Into the boss rib insert; stops the housing rotating only | McMaster-Carr | 3 |


## Housing

| Item | Qty | Spec / use | Source | Est. USD |
|---|---|---|---|---|
| Brass 3/8-24 coupling nut | 1 | 9/16 in AF, 1-1/8 in long; captive in the hex pocket; whip screws into it | McMaster-Carr, hardware store | 4 |
| Brass 3/8-24 x 1/2 in bolt | 1 | Inside bolt, with a 3/8 in ring terminal for the bus and the lining | hardware store | 2 |
| Copper foil tape, self-adhesive | 1 | Lines the bore above the stations | electronics / stained glass supply | 8 |


## Ball stations (x7)

| Item | Qty | Spec / use | Source | Est. USD |
|---|---|---|---|---|
| 5/32 in (3.97 mm) brass ball | 7 | 5 in the housing rim, 2 in the swivel cap | McMaster-Carr, bearing supply | 5 |
| Phosphor bronze or BeCu compression spring | 7 | 4.0 OD x 0.55 wire x 25 free. Never music wire | Lee Spring, Century Spring, or wound | 15 |
| All-brass Schrader valve stem, .305-32 body thread | 7 | TR416 or TR418 type, cut to 18 to 20 mm, valve core removed; the stem's own knurled nut is the lock nut | tire shop, Amazon | 12 |
| Metal Schrader valve cap | 7 | Brass or nickel plated, not anodized aluminum; sets the preload | auto parts | 5 |
| Ring terminal, 5/16 in stud, 18 to 22 AWG | 7 | Under each lock nut, bused | electronics | 3 |
| .305-32 UNEF tap (tire valve stem tap) | 1 | Taps the seven printed bosses; 5/16-32 also works, slightly loose | Amazon, tool supply | 15 |


## Swivel

| Item | Qty | Spec / use | Source | Est. USD |
|---|---|---|---|---|
| K&S 1 in OD x 0.014 wall brass tube | 1 | Cut 8 mm, onto the journal recess; the ring the two balls ride on | hobby shop | 5 |
| M3 x 10 self-tapping screw | 2 | Retaining screws, tips in the journal groove | hardware store | 1 |
| SO-239 square flange | 1 | On the swivel cap foot | DX Engineering, Amazon | 4 |
| #4 x 3/8 in self-tapping screw | 4 | SO-239 to the cap; one also takes the shield ring terminal | hardware store | 1 |


## Winding

| Item | Qty | Spec / use | Source | Est. USD |
|---|---|---|---|---|
| Bare tinned 18 AWG copper wire | 9.5 m | 80 turns plus tails | Amazon, Remington | 8 |
| Bus wire, 18 AWG insulated | 1.5 m | Five stations to the inside bolt; two stations to the SO-239 tail | on hand | 1 |


## Antenna

| Item | Qty | Spec / use | Source | Est. USD |
|---|---|---|---|---|
| Chameleon CHA SS17 whip | 1 | 17 ft, 3/8-24, 16.0 mm base | Chameleon, DX Engineering | on hand |
| Radial wire | 4 to 8 | Ring terminals on one end for the ground bolt | on hand | on hand |

## Totals, rough

- Printed parts: about $145 at a print service in MJF PA12, or about $22 of filament at home.
- Inserts, legs, feet and hub hardware: about $95.
- Station, swivel and winding hardware (shared with rev C): about $75, of which the tap and the springs are $30 and reusable.
- Whole thing, printed at home: about $190 plus the whip. Printed by a service: about $310.

## Notes

- Hole sizes in the printed parts are cut for the inserts above. Buying a different insert means changing `leg_tap_drill`, `radial_tap_drill` or `setscrew_tap_drill` in `make_revD.py` and reprinting.
- The 2 in stud and the 2 in ballast bolt both bottom in their holes; 1-1/2 in is the length for each.
- Springs are in the RF path. Phosphor bronze or BeCu only; stainless 302 is acceptable at 50 W; music wire never.
- Ballast adds a few miles an hour of free-standing wind margin (13 to 17 mph). The stakes through the foot ears are what hold it above that.
