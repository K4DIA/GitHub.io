#!/usr/bin/env python3
"""Machining drawing for the rev D tripod hub: top, bottom, section, thread callouts, notes. Letter landscape PDF + PNG.
Every number is read from revD_dims.json, the same source as the STEP."""
import json, math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle, Polygon, Arc, Ellipse

d = json.load(open("revD/revD_dims.json")); P = d["params"]; t = P["tripod"]; hi = d["hub"]; ti = d["tripod"]
bore = ti["bore"]; R = t["body_dia"] / 2; T = t["body_t"]; RB = t["boss_od"] / 2; HB = t["boss_h"]; H = T + HB
la = math.radians(t["leg_angle"]); a = t["chamfer_a"]; h = ti["chamfer_rise"]
xc, zc = ti["seat_r"], ti["seat_z"]; z_ss = ti["z_setscrew"]; mass = 106.0 * 2.70

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 7.5})
fig = plt.figure(figsize=(11, 8.5)); fig.patch.set_facecolor("white")
LW = 0.9; DIM = "#1a4fa0"; HID = (0, (3, 2))

def dimh(ax, x1, x2, y, text, off=2.5):
    ax.annotate("", xy=(x1, y), xytext=(x2, y), arrowprops=dict(arrowstyle="<->", lw=0.7, color=DIM))
    ax.text((x1 + x2) / 2, y + off, text, ha="center", va="bottom", color=DIM, fontsize=7)
def dimv(ax, x, y1, y2, text, off=2.5, ha="left"):
    ax.annotate("", xy=(x, y1), xytext=(x, y2), arrowprops=dict(arrowstyle="<->", lw=0.7, color=DIM))
    ax.text(x + (off if ha == "left" else -off), (y1 + y2) / 2, text, ha=ha, va="center", color=DIM, fontsize=7, rotation=90)
def leader(ax, x0, y0, x1, y1, text, ha="left"):
    ax.annotate(text, xy=(x0, y0), xytext=(x1, y1), ha=ha, va="center", fontsize=7.2,
                arrowprops=dict(arrowstyle="-|>", lw=0.7, color="#222"), color="#222")
def centerlines(ax, r):
    ax.plot([-r, r], [0, 0], lw=0.4, color="#666", ls=(0, (6, 2, 1, 2))); ax.plot([0, 0], [-r, r], lw=0.4, color="#666", ls=(0, (6, 2, 1, 2)))

# ---------------- TOP VIEW ----------------
ax = fig.add_axes([0.02, 0.40, 0.30, 0.54]); ax.set_aspect("equal"); ax.axis("off")
for rr in (R, R - a, RB, bore / 2): ax.add_patch(Circle((0, 0), rr, fill=False, lw=LW if rr != R - a else 0.5))
for k in range(3):
    an = math.radians(120 * k); x, y = t["radial_r"] * math.cos(an), t["radial_r"] * math.sin(an)
    ax.add_patch(Circle((x, y), t["radial_tap_drill"] / 2, fill=False, lw=LW)); ax.add_patch(Circle((x, y), t["radial_tap_drill"] / 2 + 1.2, fill=False, lw=0.5, ls=(0, (2, 2))))
centerlines(ax, R + 6)
ax.text(-R - 4, R + 4, "A", fontsize=9, fontweight="bold"); ax.text(R + 1, -R - 8, "A", fontsize=9, fontweight="bold")
ax.plot([-R - 2, -R - 6], [0, 0], lw=1.6, color="#222"); ax.plot([R + 2, R + 6], [0, 0], lw=1.6, color="#222")
dimh(ax, -R, R, -R - 8, f"⌀{t['body_dia']:.0f}"); dimh(ax, -RB, RB, R + 10, f"⌀{t['boss_od']:.0f} boss")
leader(ax, bore / 2 * math.cos(0.8), bore / 2 * math.sin(0.8), R + 8, R - 6, f"⌀{bore:.2f} +0.05/-0 THRU\nbore or ream\n(printed housing OD {hi['od']:.2f})")
x, y = t["radial_r"] * math.cos(math.radians(120)), t["radial_r"] * math.sin(math.radians(120))
leader(ax, x, y, -R - 6, R + 6, f"3x 1/4-20 UNC ▼12\ntap drill ⌀{t['radial_tap_drill']}\n⌀{2*t['radial_r']:.0f} B.C., 120° apart", ha="right")
leader(ax, (R - a) * math.cos(-0.9), (R - a) * math.sin(-0.9), R + 2, -R + 4, f"chamfer edge, ⌀{2*(R-a):.0f} at the bottom face")
eg = t["engrave"]
for angd in eg["angles"]:
    ax.text(eg["r"] * math.cos(math.radians(angd)), eg["r"] * math.sin(math.radians(angd)), eg["text"], fontsize=5.2, fontweight="bold", ha="center", va="center", rotation=angd - 90, color="#333")
leader(ax, eg["r"] * math.cos(math.radians(300)) - 4, eg["r"] * math.sin(math.radians(300)) - 2, 0, -R - 24, f"ENGRAVE \"{eg['text']}\" x3, {eg['depth']} deep, bold sans {eg['size']:.0f} mm,\ntangent on R{eg['r']:.0f}, centred in each sector between\nthe 1/4-20 holes. Per the STEP.", ha="center")
ax.set_xlim(-R - 48, R + 48); ax.set_ylim(-R - 44, R + 22); ax.set_title("TOP VIEW", fontsize=9, loc="left")

# ---------------- BOTTOM VIEW ----------------
ax = fig.add_axes([0.32, 0.40, 0.30, 0.54]); ax.set_aspect("equal"); ax.axis("off")
for rr in (R, R - a, bore / 2): ax.add_patch(Circle((0, 0), rr, fill=False, lw=LW))
for k in range(3):
    an = math.radians(120 * k + 60); x, y = xc * math.cos(an), xc * math.sin(an)
    ax.add_patch(Ellipse((x, y), t["leg_tap_drill"] / math.cos(la), t["leg_tap_drill"], angle=math.degrees(an), fill=False, lw=LW))
    ax.add_patch(Ellipse((x, y), t["leg_tap_drill"] / math.cos(la) + 2.4, t["leg_tap_drill"] + 2.4, angle=math.degrees(an), fill=False, lw=0.5, ls=(0, (2, 2))))
for k in range(3):
    an = math.radians(120 * k); x, y = t["radial_r"] * math.cos(an), t["radial_r"] * math.sin(an)
    ax.add_patch(Circle((x, y), t["radial_tap_drill"] / 2, fill=False, lw=0.6, ls=HID))
centerlines(ax, R + 6)
x, y = xc * math.cos(math.radians(60)), xc * math.sin(math.radians(60))
leader(ax, x, y, -14, -R - 16, f"3x {t['leg_thread']} ▼{t['leg_depth']:.0f}, tap drill ⌀{t['leg_tap_drill']} (5/16)\non the chamfer face, centred R{xc:.1f}, 120° apart\naxis square to the chamfer ({t['leg_angle']:.0f}° from the hub axis), see A-A", ha="center")
ax.set_xlim(-R - 30, R + 30); ax.set_ylim(-R - 40, R + 22); ax.set_title("BOTTOM VIEW", fontsize=9, loc="left")

# ---------------- SECTION A-A (true section: the 180° leg hole and the 0° radial hole lie in the plane) ----------------
ax = fig.add_axes([0.62, 0.40, 0.37, 0.54]); ax.set_aspect("equal"); ax.axis("off")
prof = [(bore / 2, 0), (R - a, 0), (R, h), (R, T), (RB, T), (RB, H), (bore / 2, H)]
for sgn in (1, -1):
    ax.add_patch(Polygon([(sgn * x, z) for x, z in prof], closed=True, facecolor="white", edgecolor="#222", lw=LW, hatch="////"))
# leg hole, left side (180 deg leg), axis in and up
u = (-math.sin(la), math.cos(la)); n = (math.cos(la), math.sin(la)); r = t["leg_tap_drill"] / 2; L = t["leg_depth"]
x0 = -xc; z0 = zc; ux, uz = -u[0] * -1, u[1]   # on the left half the inward direction is +x
ux = math.sin(la); uz = math.cos(la); nx, nz = math.cos(la), -math.sin(la)
hole = [(x0 - r * nx, z0 - r * nz), (x0 + r * nx, z0 + r * nz), (x0 + r * nx + ux * L, z0 + r * nz + uz * L), (x0 - r * nx + ux * L, z0 - r * nz + uz * L)]
ax.add_patch(Polygon(hole, closed=True, facecolor="white", edgecolor="#222", lw=0.8))
ax.plot([x0 - ux * 10, x0 + ux * (L + 4)], [z0 - uz * 10, z0 + uz * (L + 4)], lw=0.4, color="#666", ls=(0, (6, 2, 1, 2)))
ax.add_patch(Arc((x0, z0), 18, 18, angle=0, theta1=90, theta2=90 + t["leg_angle"], lw=0.6, color=DIM)); ax.text(x0 + 2, z0 + 11, f"{t['leg_angle']:.0f}°", color=DIM, fontsize=7)
ax.plot([x0, x0], [z0, z0 + 12], lw=0.4, color=DIM)
# radial hole, right side (0 deg), and set screw
rx = t["radial_r"]; rr = t["radial_tap_drill"] / 2
ax.add_patch(Rectangle((rx - rr, T - 12), 2 * rr, 12, facecolor="white", edgecolor="#222", lw=0.8))
ax.add_patch(Rectangle((bore / 2 - 0.01, z_ss - t["setscrew_tap_drill"] / 2), RB - bore / 2 + 0.02, t["setscrew_tap_drill"], facecolor="white", edgecolor="#222", lw=0.8))
dimv(ax, R + 4, 0, T, f"{T:.0f}"); dimv(ax, R + 4, T, H, f"{HB:.0f}"); dimv(ax, R + 13, 0, H, f"{H:.0f}")
dimh(ax, -bore / 2, bore / 2, H + 6, f"⌀{bore:.2f} THRU")
dimh(ax, -R, -R + a, -6, f"{a:.0f}", off=-6); dimv(ax, -R - 8, 0, h, f"{h:.1f}", ha="right")
leader(ax, RB, z_ss, RB + 22, H + 10, f"M5 x 0.8 thru wall, 1x\ntap drill ⌀{t['setscrew_tap_drill']}\n{H - z_ss:.0f} below boss top")
leader(ax, rx, T - 6, rx + 6, -14, "1/4-20 UNC ▼12\n(3x, top face)")
leader(ax, x0 + ux * L * 0.5, z0 + uz * L * 0.5, -R - 4, -16, f"{t['leg_thread']} ▼{t['leg_depth']:.0f}\nsquare to the chamfer\n(3x)", ha="right")
ax.set_xlim(-R - 34, R + 50); ax.set_ylim(-28, H + 26); ax.set_title("SECTION A-A", fontsize=9, loc="left")

# ---------------- NOTES + TITLE BLOCK ----------------
ax = fig.add_axes([0.02, 0.02, 0.63, 0.35]); ax.axis("off")
notes = [
    "NOTES",
    f"1. Material: 6061-T6 aluminum, one piece from {t['stock']}.",
    f"2. Bottom edge chamfer: {a:.0f} mm radial x {h:.1f} mm rise, {t['leg_angle']:.0f}° from the bottom face, full circumference. It is the seat for the legs.",
    f"3. The STEP file revD_tripod_hub_ALU.step shows every threaded hole at TAP-DRILL size. Thread per this drawing:",
    f"      3x {t['leg_thread']}, {t['leg_depth']:.0f} mm deep, on the chamfer face at 120°, each axis square to the chamfer",
    f"         ({t['leg_angle']:.0f}° from the hub axis). Tap drill ⌀{t['leg_tap_drill']} = 5/16 in.",
    f"      3x 1/4-20 UNC, 12 mm deep, top face, ⌀{2*t['radial_r']:.0f} bolt circle, 120° apart, midway between the leg holes. Tap drill ⌀{t['radial_tap_drill']} = #7.",
    f"      1x M5 x 0.8 through the boss wall, radial, {H - z_ss:.0f} mm below the boss top. Tap drill ⌀{t['setscrew_tap_drill']}.",
    f"4. Through bore ⌀{bore:.2f} +0.05/-0.00, bored or reamed, 1.6 µm or better. A 40.74 mm printed part slides in it.",
    "5. Optional: spot-face ⌀13 x 1 mm square to each leg-hole axis for a full-contact seat. Break all edges 0.5 mm. Deburr threads.",
    f"6. Finish: {t['finish']}.",
    "      Not anodize: anodize insulates and builds thread size. Chem film is conductive and adds no thickness,",
    "      so it goes on after tapping, no masking. JLCCNC calls it \"Conductive anodizing - Natural\". No bead blast in the bore.",
    f"7. Engraving: \"{t['engrave']['text']}\" three times on the top face as modeled in the STEP, {t['engrave']['depth']} mm deep, engrave or 3-axis mill. Do not fill.",
    "8. Tolerances unless noted: ±0.2 mm linear, ±0.5° angular. Thread class 2B. Qty 1.",
]
for i, nn in enumerate(notes):
    ax.text(0, 1 - i * 0.068, nn, fontsize=7.0 if i else 8.5, fontweight="bold" if i == 0 else "normal", va="top")
ax.set_xlim(0, 1); ax.set_ylim(0, 1)
ax = fig.add_axes([0.70, 0.03, 0.28, 0.22]); ax.axis("off"); ax.add_patch(Rectangle((0, 0), 1, 1, fill=False, lw=1))
rows = [("PART", "Tripod hub, rev D"), ("FILE", "revD_tripod_hub_ALU.step"), ("MATERIAL", "6061-T6"), ("FINISH", "chem film, Class 3"),
        ("UNITS", "mm, third angle"), ("MASS", f"{mass:.0f} g approx."), ("REV", "D"), ("DATE", "2026-11-04")]
for i, (k, v) in enumerate(rows):
    y = 1 - (i + 1) / (len(rows) + 1)
    ax.text(0.04, y, k, fontsize=7, fontweight="bold", va="center"); ax.text(0.36, y, v, fontsize=7.4, va="center")
    ax.plot([0, 1], [y - 0.5 / (len(rows) + 1)] * 2, lw=0.3, color="#999")
ax.set_xlim(0, 1); ax.set_ylim(0, 1)
fig.text(0.03, 0.975, "TRIPOD HUB, REV D: MACHINING DRAWING", fontsize=12, fontweight="bold", va="top")
fig.text(0.03, 0.952, "Attach to the STEP when quoting. The STEP is geometry only; threads and finish are specified here.", fontsize=8, va="top", color="#444")
fig.savefig("revD/machined_alt/revD_tripod_hub_DRAWING.pdf"); fig.savefig("revD/machined_alt/revD_tripod_hub_DRAWING.png", dpi=150)
print("drawing written")
